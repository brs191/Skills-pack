# Master Skill Router

Use this router first. Select the smallest set of skills needed for the user's request.

## 1. MCP Server Implementation

Use `skills/mcp/` when the user asks to design, implement, review, test, secure, deploy, or integrate a Go-based MCP server.

Recommended combinations:

| User intent | Primary skills |
|---|---|
| Create a basic mcp-go server | `mcp/01-mcp-go-server-basics.md`, `mcp/17-mcp-go-code-generation.md` |
| Design MCP tools | `mcp/02-mcp-go-tool-design.md`, `mcp/18-mcp-go-anti-patterns.md` |
| Add resources/prompts | `mcp/03-mcp-go-resources.md`, `mcp/04-mcp-go-prompts.md` |
| Select transport | `mcp/05-mcp-go-transport-selection.md` |
| Create production project structure | `mcp/06-mcp-go-project-structure.md`, `mcp/10-mcp-go-deployment.md` |
| Secure MCP server | `mcp/07-mcp-go-enterprise-security.md`, `mcp/20-mcp-go-threat-modeling.md` |
| Add observability | `mcp/08-mcp-go-observability.md` |
| Add tests/security tests | `mcp/09-mcp-go-testing.md`, `mcp/25-mcp-go-security-test-generation.md` |
| Review production readiness | `mcp/16-mcp-go-production-review.md` |
| Client or agent integration | `mcp/11-mcp-go-agent-integration.md`, `mcp/21-mcp-go-client-integration.md` |
| CI/CD quality gates | `mcp/22-mcp-go-ci-cd-quality-gates.md` |

## 2. Domain MCP Starters

Use `skills/domain/` when the MCP server is for a specific enterprise domain.

| Domain | Primary skills | Example repo |
|---|---|---|
| Azure FinOps | `domain/12-mcp-go-azure-finops.md` | `examples/azure-finops-mcp-server/` |
| DevOps automation | `domain/13-mcp-go-devops-automation.md` | `examples/devops-mcp-server/` |
| Observability / Grafana | `domain/14-mcp-go-observability-grafana.md` | `examples/observability-mcp-server/` |
| Azure network review | `domain/15-mcp-go-network-reviewer.md` | `examples/network-reviewer-mcp-server/` |
| Create a new domain skeleton | `domain/23-mcp-go-domain-skeletons.md` | Use `templates/go/` plus nearest example repo |

## 3. Microservices System Design

Use `skills/microservices/` when the user asks about cloud-hosted microservices, Azure system design, service boundaries, distributed systems, data consistency, event-driven architecture, or platform modernization.

Recommended combinations:

| User intent | Primary skills |
|---|---|
| Choose patterns | `microservices/28-microservices-pattern-selection.md` |
| Map patterns to Azure | `microservices/29-azure-cloud-native-patterns.md` |
| Data ownership / consistency | `microservices/30-microservices-data-patterns.md` |
| Sync vs async communication | `microservices/31-microservices-communication-patterns.md` |
| Resilience design | `microservices/32-microservices-resilience-patterns.md` |
| Observability | `microservices/33-microservices-observability-patterns.md` |
| Security | `microservices/34-microservices-security-patterns.md` |
| Deployment topology | `microservices/35-microservices-deployment-patterns.md` |
| Full design review | `microservices/36-microservices-system-design-review.md` |
| Generate architecture | `microservices/37-microservices-architecture-generation.md` |

## 4. Architecture Accelerator

Use `skills/accelerator/` when the user wants board-ready outputs, case studies, diagrams, scorecards, demo validation, or executive-to-engineering translation.

| User intent | Primary skills |
|---|---|
| Generate case study | `accelerator/38-microservices-case-study-generation.md` |
| Create diagrams | `accelerator/39-diagram-ready-architecture-output.md` |
| Score Azure Well-Architected readiness | `accelerator/40-azure-well-architected-scoring.md` |
| Execute architecture MCP tools | `accelerator/41-mcp-architecture-tool-execution.md` |
| Run demo workflow | `accelerator/42-one-command-demo-workflow.md` |
| Validate golden outputs | `accelerator/43-golden-output-validation.md` |
| Create architecture-board pack | `accelerator/44-architecture-board-presentation-pack.md` |
| Package/adopt the agent | `accelerator/45-agent-packaging-and-adoption.md` |
| Translate executive to engineering | `accelerator/46-executive-to-engineering-translation.md` |
| Apply acceptance gates | `accelerator/47-architecture-acceptance-gates.md` |

## Default output discipline

Always identify whether the user needs:

1. MCP implementation output,
2. microservices architecture output,
3. architecture-board communication output,
4. or a runnable/example artifact.

Avoid loading every skill. Route narrowly and cite the relevant folders in your own reasoning output only when useful to the user.
