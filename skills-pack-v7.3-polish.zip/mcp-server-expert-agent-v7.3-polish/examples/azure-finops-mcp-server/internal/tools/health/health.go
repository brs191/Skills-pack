package health

import (
	"context"

	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func Register(s *server.MCPServer) {
	s.AddTool(mcp.NewTool("health_check", mcp.WithDescription("Check whether the MCP server is healthy")), handler)
}

func handler(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	return mcp.NewToolResultText(`{"status":"healthy","service":"azure-finops-mcp-server"}`), nil
}
