package policy

import "testing"

func TestPolicyAllowsLowRisk(t *testing.T) {
	e := NewEngine()
	d := e.Authorize(Request{Tool: "get_cost_summary", SubscriptionID: "sub-1", Risk: RiskLow})
	if !d.Allowed {
		t.Fatalf("expected allowed, got %s", d.Reason)
	}
}

func TestPolicyBlocksHighRisk(t *testing.T) {
	e := NewEngine()
	d := e.Authorize(Request{Tool: "delete_resource", SubscriptionID: "sub-1", Risk: RiskHigh})
	if d.Allowed {
		t.Fatal("expected high-risk request to be blocked")
	}
}
