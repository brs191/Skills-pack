# Skill — Executive to Engineering Translation

## Purpose

Convert architecture decisions into both leadership-facing and engineering-facing outputs.

## Use When

The user wants business and technical versions of the same architecture.

## Executive View

Focus on:

- business outcome
- risk reduction
- cost discipline
- delivery confidence
- operational readiness
- decision required

## Engineering View

Focus on:

- service boundaries
- APIs and events
- Azure services
- failure modes
- deployment topology
- observability
- security controls
- backlog-ready implementation tasks

## Required Behavior

Never use the same language for both audiences. Preserve the same architecture truth, but change the abstraction level.
