package cost

import (
	"context"
	"encoding/json"

	"github.com/example/azure-finops-mcp-server/internal/audit"
	"github.com/example/azure-finops-mcp-server/internal/policy"
	costservice "github.com/example/azure-finops-mcp-server/internal/services/cost"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerGenerateFinOpsReport(s *server.MCPServer, svc *costservice.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	tool := mcp.NewTool("generate_finops_report",
		mcp.WithDescription("Generate a concise FinOps report using available cost and idle resource signals"),
		mcp.WithString("subscription_id", mcp.Required(), mcp.Description("Azure subscription ID")),
		mcp.WithString("from_date", mcp.Required(), mcp.Description("Start date in YYYY-MM-DD format")),
		mcp.WithString("to_date", mcp.Required(), mcp.Description("End date in YYYY-MM-DD format")),
	)

	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		subscriptionID, err := req.RequireString("subscription_id")
		if err != nil {
			return mcp.NewToolResultError("subscription_id is required"), nil
		}
		fromDate, err := req.RequireString("from_date")
		if err != nil {
			return mcp.NewToolResultError("from_date is required"), nil
		}
		toDate, err := req.RequireString("to_date")
		if err != nil {
			return mcp.NewToolResultError("to_date is required"), nil
		}

		decision := policyEngine.Authorize(policy.Request{Tool: "generate_finops_report", SubscriptionID: subscriptionID, Risk: policy.RiskMedium})
		if !decision.Allowed {
			return mcp.NewToolResultError(decision.Reason), nil
		}

		out, err := svc.GenerateFinOpsReport(ctx, subscriptionID, fromDate, toDate)
		if err != nil {
			return mcp.NewToolResultError(err.Error()), nil
		}
		auditor.Record(ctx, audit.Event{Tool: "generate_finops_report", SubscriptionID: subscriptionID, Status: "success", Risk: "medium"})
		b, _ := json.MarshalIndent(out, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})
}
