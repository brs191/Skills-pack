---
skill: skills/microservices/08-api-design.md
exercises_section: Intent-based design and API evolution
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: API design

## Prompt

Critique this API endpoint: `POST /api/v1/services/order/db/orders` that takes a row-shaped JSON body matching the underlying `orders` table. What's wrong with it and how would you redesign it?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Leaks implementation** — flags that the URL exposes internal structure (`services/order/db`) that has no business meaning
- [ ] **Not intent-based** — names that "create an order" is the intent; the API should look like `POST /orders`, not `POST /...db/orders`
- [ ] **Row-shaped body is wrong** — names that the body should be a domain command, not a DB row dump (no `created_at`, no `updated_by`, no internal foreign keys)
- [ ] **Versioning at the right level** — `/v1/` is fine; suggests how to version (URI or header) and warns against versioning everywhere
- [ ] **Idempotency on create** — proposes an `Idempotency-Key` header for safe retries on a state-changing POST
- [ ] **Error responses** — names that error shape (e.g., RFC 7807 problem-details) matters as much as success shape

## Reference output

> The URL and the body both leak implementation. Five distinct issues:
>
> **1. URL exposes internals.** `services/order/db/orders` is structured around the codebase, not the client. The client doesn't care that there's a service called `order` and a database called `db`. The right URL is `POST /orders`. Behind the scenes, the request can route to whatever service/database it wants; the URL is the contract, and the contract should be domain language.
>
> **2. Not intent-based.** The client's intent is "place an order." The API should look like `POST /orders` taking an order *command* (`{customer_id, items, shipping_address, ...}`), not a table row. Intent-based APIs are stable across implementation changes; row-shaped APIs break every time you migrate the database.
>
> **3. Row-shaped body.** Internal fields (`created_at`, `updated_at`, `internal_status`, `created_by_user_id`, FK ids referencing other tables) leak the storage. Server-generated fields shouldn't be in the request at all; reference fields should be expressed in the domain language (`shipping_address: {...}`), not as raw IDs into other tables.
>
> **4. Versioning.** `/v1/` is fine for major versions. The skill recommends URI versioning for major breakage and headers for finer-grained compatibility. Avoid versioning at the resource level (`/orders/v2`) — it leaks the implementation. One version per API surface; bump it deliberately and rarely.
>
> **5. Idempotency on a state-changing POST.** Without an idempotency key, retries (network blips, client retries) can place duplicate orders. The API should accept an `Idempotency-Key` header; the server stores a record of processed keys for some window (24 hours) and returns the same response for the same key.
>
> **6. Error shape.** Success has a shape; errors need one too. RFC 7807 (`application/problem+json` with `type`, `title`, `status`, `detail`, `instance`) is the standard. Don't return `{ "error": "something went wrong" }` — give the client a stable, parseable error type.
>
> **Redesign**
>
> ```
> POST /orders
> Headers:
>   Content-Type: application/json
>   Idempotency-Key: <client-generated UUID>
>   Authorization: Bearer <token>
> Body:
>   {
>     "customer_id": "...",
>     "items": [{"sku": "...", "quantity": 1, "unit_price_cents": 1999}],
>     "shipping_address": {...},
>     "payment_method_id": "..."
>   }
> Response: 202 Accepted, body: { "order_id": "...", "status": "processing" }
> ```
>
> Domain-shaped, idempotent, versioned at the API surface (`/v1/orders` if needed), with a clean error contract.

## Notes

Catches LLMs that nod at "REST best practices" without engaging with the specific anti-pattern (URL leaking internals, body matching a table).
