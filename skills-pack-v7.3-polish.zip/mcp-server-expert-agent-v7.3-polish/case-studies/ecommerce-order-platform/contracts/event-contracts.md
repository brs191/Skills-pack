# Event Contracts

## Event: OrderCreated

```json
{
  "eventId": "evt-001",
  "eventType": "OrderCreated",
  "version": "1.0",
  "occurredAt": "2026-05-12T09:00:00Z",
  "orderId": "ord-1001",
  "customerId": "cust-123",
  "items": [{"sku":"SKU-1","quantity":2}],
  "totalAmount": 2500.00,
  "currency": "INR"
}
```

## Event: InventoryReserved

```json
{
  "eventId": "evt-002",
  "eventType": "InventoryReserved",
  "version": "1.0",
  "orderId": "ord-1001",
  "reservationId": "res-1001"
}
```

## Event: PaymentAuthorized

```json
{
  "eventId": "evt-003",
  "eventType": "PaymentAuthorized",
  "version": "1.0",
  "orderId": "ord-1001",
  "paymentId": "pay-1001",
  "amount": 2500.00,
  "currency": "INR"
}
```
