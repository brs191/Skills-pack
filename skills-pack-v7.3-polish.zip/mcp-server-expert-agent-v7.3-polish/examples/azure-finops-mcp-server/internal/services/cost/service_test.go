package cost

import (
	"context"
	"testing"
)

type fakeClient struct{}

func (f fakeClient) GetCostSummary(ctx context.Context, req CostSummaryRequest) (CostSummary, error) {
	return CostSummary{SubscriptionID: req.SubscriptionID, Currency: "USD", TotalCost: 100, Granularity: req.Granularity}, nil
}
func (f fakeClient) FindIdleResources(ctx context.Context, subscriptionID string, lookbackDays string) ([]IdleResource, error) {
	return []IdleResource{{ResourceID: "vm1", EstimatedMonthlyRun: 10}}, nil
}
func (f fakeClient) DetectCostAnomalies(ctx context.Context, subscriptionID, fromDate, toDate string) ([]CostAnomaly, error) {
	return []CostAnomaly{{Service: "Compute", DeltaPercent: 25}}, nil
}

func TestGetCostSummaryDefaultsGranularity(t *testing.T) {
	svc := NewService(fakeClient{})
	out, err := svc.GetCostSummary(context.Background(), CostSummaryRequest{SubscriptionID: "sub-1"})
	if err != nil {
		t.Fatal(err)
	}
	if out.Granularity != "daily" {
		t.Fatalf("expected daily granularity, got %s", out.Granularity)
	}
}

func TestGetCostSummaryRequiresSubscription(t *testing.T) {
	svc := NewService(fakeClient{})
	_, err := svc.GetCostSummary(context.Background(), CostSummaryRequest{})
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestGenerateFinOpsReport(t *testing.T) {
	svc := NewService(fakeClient{})
	out, err := svc.GenerateFinOpsReport(context.Background(), "sub-1", "2026-05-01", "2026-05-31")
	if err != nil {
		t.Fatal(err)
	}
	if out.TotalCost != 100 {
		t.Fatalf("expected total cost 100, got %v", out.TotalCost)
	}
	if len(out.RecommendedActions) == 0 {
		t.Fatal("expected recommendations")
	}
}
