# Skill — Microservices Case Study Generation

## Purpose

Generate complete end-to-end microservices case studies for Azure-hosted systems.

## Use When

The user asks for a real example, case study, enterprise architecture scenario, implementation roadmap, or leadership-ready system design.

## Required Output

1. Problem statement
2. Business capabilities
3. Service boundaries
4. Data ownership
5. API contracts
6. Event contracts
7. Azure deployment topology
8. Resilience model
9. Security model
10. Observability model
11. ADRs
12. MCP tool execution examples
13. Well-Architected score
14. MVP-to-production roadmap

## Rule

Do not create microservices by technical layers. Start from business capabilities.
