# MCP Production Checklist

## MCP Contracts
- [ ] Every tool has a contract file
- [ ] Tool names are intent-based
- [ ] Input schemas are explicit
- [ ] Output schemas are bounded

## Security
- [ ] Auth for remote transport
- [ ] Per-tool authorization
- [ ] Tenant context enforced
- [ ] Secrets never returned
- [ ] Output redaction exists
- [ ] High-risk tools require approval

## Operations
- [ ] Structured logs
- [ ] Metrics
- [ ] Tracing
- [ ] Audit logs
- [ ] Timeouts
- [ ] Graceful shutdown

## Delivery
- [ ] Dockerfile
- [ ] Makefile
- [ ] README
- [ ] Kubernetes/Azure deployment sample
- [ ] CI commands documented

## Testing
- [ ] Unit tests
- [ ] Handler tests
- [ ] Contract tests
- [ ] Security tests
