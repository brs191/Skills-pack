---
skill: skills/mcp/11-mcp-go-agent-integration.md
exercises_section: Tool descriptions, schemas, and the data-not-instructions rule
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go agent integration

## Prompt

A team ships an MCP server with tool descriptions like "does the thing for the system" and "review stuff." Agents using the server consistently pick wrong tools or fail to call any. What's the actual problem and how do you fix it?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Descriptions are the agent's docs** — names that tool descriptions and JSON schemas are the only documentation the agent has
- [ ] **Trigger condition** — recommends descriptions include *when* to use the tool, not just what it does
- [ ] **Verb-led naming and prose** — names should be action verbs; descriptions should describe action precisely
- [ ] **What it doesn't do** — descriptions should include boundaries (what the tool will *not* do) to prevent misuse
- [ ] **JSON schema balance** — required vs. optional fields, constrained vs. permissive; both extremes are bad
- [ ] **Worked rewrite** — provides a before/after example of one tool with materially better description

## Reference output

> The actual problem is that the team treats descriptions as branding ("does the thing for the system") instead of agent-facing documentation. From the agent's perspective:
>
> - The description is the only signal of when to use this tool.
> - The JSON schema is the only signal of what input is valid.
> - There is no other documentation the agent will read.
>
> If the description is vague, the agent guesses. Guesses are wrong often enough to look like the server is broken.
>
> **What good descriptions look like**
>
> Verb-led, with four elements:
>
> 1. *What*: a precise statement of the action.
> 2. *When*: the trigger condition — what user intent calls this tool.
> 3. *Input* shape: brief, with link to the contract.
> 4. *Output* shape and what it does *not* do — boundaries prevent the agent from over-applying it.
>
> **Before/after**
>
> Bad:
> ```
> "review_stuff": "Reviews stuff"
> ```
>
> Good:
> ```
> "detect_architecture_risks":
>   "Identify architecture risks in a proposed microservices system.
>    Use when the user describes a microservices design and asks for
>    a risk assessment, gap analysis, or pre-launch review.
>    Takes the system topology (services, dependencies, data stores,
>    constraints) as input_json matching the documented schema.
>    Returns a list of risks with severity (high/medium/low), category,
>    description, and recommended mitigation.
>    Does not check code; does not call Azure APIs; does not modify state."
> ```
>
> **JSON schema balance**
>
> - Required fields actually required (no "everything optional" goo).
> - Identifier patterns where appropriate (`^[a-z][a-z0-9-]{1,62}$`).
> - Enums listed (`severity: high | medium | low`).
> - Optional fields with sensible defaults.
> - But not so hostile that the agent can't construct valid input — every required field should be something the user clearly provides.
>
> **Fix order**
>
> 1. Rewrite every tool description following the four-element rule.
> 2. Audit every schema for permissive-versus-hostile balance.
> 3. Verify with an actual agent run: does the agent pick the right tool now?
> 4. Add a contract file per tool that the description can reference for full input/output specification.

## Notes

The "tool description as agent documentation" point is the load-bearing insight.
