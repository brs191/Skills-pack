---
skill: skills/microservices/04-service-boundaries.md
exercises_section: Data ownership, consistency boundaries
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: service boundaries

## Prompt

A team proposes: "service A and service B both write to the `orders` table; we'll coordinate with row-level locks." What's wrong with this proposal, and how do you fix it without giving up the workflow they're trying to support?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Shared writeable table = no boundary** — flags that two services writing to one table means they aren't actually separate services
- [ ] **Schema coupling** — names that a schema change in the table now requires coordinating both services' deploys
- [ ] **Row-level locks across services are fragile** — DB locks don't compose with retries, timeouts, or process restarts cleanly
- [ ] **One service owns the table** — proposes that exactly one service owns `orders`; the other calls its API or subscribes to its events
- [ ] **Saga or event-driven for the workflow** — names the workflow shape that supports cross-service coordination without shared writes (saga + outbox + idempotent consumer)
- [ ] **Detection signal** — names how you'd notice this anti-pattern in code review (cross-service DB connections, shared migration repo, schema PR that touches two service codebases)

## Reference output

> Two services writing to one table means they aren't separate services — they're one service split across two repos. Specifically:
>
> **What's wrong**
> - **No real boundary.** Adding a column to `orders` requires coordinating both services' deploys; the schema is now a shared dependency. The very thing service boundaries are supposed to give you (independent deployability, independent evolution) is gone.
> - **Row locks across services are fragile.** A lock held by service A while it processes a transaction can block service B indefinitely if service A crashes before commit. Lock timeouts trade availability for consistency in ways that surface as user-visible latency spikes. Retries on top of locks compound the problem.
> - **Hidden coupling will sneak in.** When two teams have direct DB access to the same table, "just this one query" sneaks across boundaries weekly. The boundary erodes.
>
> **Fix without giving up the workflow**
>
> Pick one service as the *owner* of `orders`. The other interacts only through:
> 1. **Sync calls to the owner's API** if it needs to read or write *right now* and the result feeds the response.
> 2. **Events emitted by the owner** if it needs to react to changes — subscribe and project into its own local view.
> 3. **Saga participation** if a multi-step workflow involves writing across services. The saga coordinates via events with explicit compensations; no DB-level locking required.
>
> Concretely, if the workflow is "order placement requires both services to do something": (a) the owner creates the order in pending state with an outbox event, (b) the second service consumes the event, performs its local transaction, emits its own event, (c) the owner consumes that event and moves the order to confirmed. Eventual consistency, no shared locks, both services genuinely independent.
>
> **Detection in code review**
> - Two service codebases referencing the same connection string or DB credential.
> - A schema migration repo that affects both services.
> - A PR that updates ORM models in two services.
> - Network audit showing both services connecting to the same DB.
>
> Block any PR that fails these checks at the boundary stage; once the shared write is in production it becomes much harder to extract.

## Notes

Catches the most common boundary anti-pattern. The "fix without giving up the workflow" framing prevents the LLM from punting ("don't share databases") without proposing the actual alternative.
