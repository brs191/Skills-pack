package audit

import (
	"context"
	"log/slog"
	"time"
)

type Event struct {
	Name      string
	Tool      string
	UserID    string
	TenantID  string
	Status    string
	RiskLevel string
	Duration  time.Duration
}

type Recorder interface {
	Record(ctx context.Context, event Event)
}

type StdoutRecorder struct{}

func (StdoutRecorder) Record(ctx context.Context, e Event) {
	slog.InfoContext(ctx, e.Name,
		"tool", e.Tool,
		"user_id", e.UserID,
		"tenant_id", e.TenantID,
		"status", e.Status,
		"risk_level", e.RiskLevel,
		"duration_ms", e.Duration.Milliseconds(),
	)
}
