# Demo Flow — Observability Incident Analysis

## User request

"Summarize the incident affecting checkout latency."

## Agent flow

```text
1. Classify intent: incident investigation.
2. Call MCP tool: query_metrics.
3. Call MCP tool: detect_error_spike.
4. Call MCP tool: summarize_incident.
5. Call MCP tool: generate_runbook_recommendation.
```

## Guardrails

- Query window is bounded.
- Logs are redacted.
- Large result sets are summarized.
- Remediation remains recommendation-only unless approved.
