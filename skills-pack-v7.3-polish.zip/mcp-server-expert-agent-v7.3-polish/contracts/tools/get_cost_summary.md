# Tool Contract — get_cost_summary

## Version
v1

## Purpose
Return Azure cost summary for a subscription and date range.

## Input Schema

| Field | Type | Required | Validation | Description |
|---|---|---:|---|---|
| subscription_id | string | yes | non-empty | Azure subscription ID |
| from_date | string | yes | YYYY-MM-DD | Start date |
| to_date | string | yes | YYYY-MM-DD | End date |
| granularity | string | no | daily/monthly | Aggregation level |

## Risk Level
Low

## Approval Required
No

## Output
JSON summary with total cost, currency, period, and top services.

## Audit Event
`mcp.tool.get_cost_summary.called`
