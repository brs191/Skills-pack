---
skill: skills/mcp/06-mcp-go-project-structure.md
exercises_section: Package layering with enforced rules
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go project structure

## Prompt

Where do the following pieces of an MCP server's codebase live, and why does the separation matter?

1. The rule logic that decides what a tool returns.
2. The MCP-aware code that registers the tool.
3. The contract document describing the tool's input/output shape.
4. Table-driven tests for the rule logic.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Rule logic in `internal/services/<name>/`** — names the service package as the home for business logic
- [ ] **MCP wiring in `internal/tools/<name>/register.go`** — names the tools package and the register file naming
- [ ] **Contract in `contracts/architecture-tools/implemented/<name>.md`** — names the contracts tree, separate from code
- [ ] **Tests next to code** — names `service_test.go` co-located with the service code, not in a top-level tests/ directory
- [ ] **Why the split** — the service package can be unit-tested without the MCP plumbing; the registration package stays thin and replaceable
- [ ] **What goes in main** — `cmd/server/main.go` only does composition (wiring, transport choice, shutdown); no business logic, no tool definitions

## Reference output

> The layering separates concerns so each package can change without affecting the others.
>
> **1. Rule logic → `internal/services/<name>/service.go`** (with types co-located: `Input`, `Output`, `Validate`, `Generate`). The package depends on nothing MCP-specific. It's the "what this tool actually computes" code, and it's unit-testable on its own. The skill calls this out as the most important split — business logic that escapes into the MCP wiring is the single biggest source of complexity in MCP servers.
>
> **2. MCP wiring → `internal/tools/<name>/register.go`.** This package depends on `github.com/mark3labs/mcp-go` and on the matching service package. It declares the tool (`mcp.NewTool(...)`), parses `input_json`, calls the service, formats the result. The handler is thin — ten to thirty lines. If a `register.go` grows past ~50 lines, something is leaking that belongs in the service.
>
> **3. Contract → `contracts/architecture-tools/implemented/<name>.md`.** Markdown document describing the tool's purpose, the JSON schema for input and output, error semantics, and examples. Lives outside `internal/` because it's consumed by humans (reviewers, integrators) and possibly by other code (schema-driven validation in future). Moving it from `planned/` to `implemented/` is how the pack tracks scope progress.
>
> **4. Tests → `internal/services/<name>/service_test.go`** next to the service code. Table-driven; tests exercise validation paths, edge cases, and golden outputs for the rule logic. Located next to code so they move together. No tests in a top-level `tests/` directory; Go's convention is co-located tests.
>
> **Why the split matters**
>
> - **Service can be unit-tested without MCP.** No need to spin up a server, send JSON-RPC, or mock the MCP transport. `go test ./internal/services/<name>` runs in milliseconds and tests the actual business logic.
> - **The tool registration is replaceable.** If you wanted to expose the same logic over HTTP or a CLI, the service package is reusable; only `register.go` changes (or has parallels in different packages).
> - **The contract is reviewable as a document.** Reviewers can read `<name>.md` to understand what the tool does without reading Go code. The contract is the schema-of-record for clients.
> - **`main.go` stays tiny.** `cmd/server/main.go` builds the dependency graph (logger, services, tool registrations) and starts the transport. No business logic, no tool definitions. If `main.go` grows, push pieces into `internal/mcpserver/server.go`.
>
> The skill ties this to the broader anti-pattern: putting tool logic in handlers (or worse, in `main.go`) is the path to a server nobody can maintain after the original author leaves.

## Notes

Catches LLMs that produce monolithic file layouts where everything is in `main.go` or in a single tools package.
