# MCP Resource Contract Template

## Resource URI
`resource://path/{id}`

## Purpose
What context this resource exposes.

## MIME Type
`application/json` / `text/markdown` / `text/plain`

## Source System
Where the data comes from.

## Access Control
Required roles, tenant scope, environment constraints.

## Refresh Strategy
Live / cached / scheduled / static.

## Redaction Rules
Fields that must never be returned.

## Example Output

```json
{}
```
