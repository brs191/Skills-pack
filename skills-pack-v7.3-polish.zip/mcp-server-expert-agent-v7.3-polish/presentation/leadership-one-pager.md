# Leadership One-Pager

## Decision Needed

Approve the proposed Azure-hosted microservices architecture direction for the platform MVP, with defined guardrails for service boundaries, API governance, event-driven workflows, security, observability, and readiness gates.

## Business Context

The platform must support faster feature delivery without creating uncontrolled technical fragmentation. The architecture should improve delivery speed, operational visibility, and resilience while avoiding premature complexity.

## Recommended Direction

Use a pragmatic cloud-native architecture:

- Azure API Management for external API governance.
- Azure Container Apps for MVP service hosting.
- AKS only where platform scale or advanced controls justify it.
- Azure Service Bus for reliable business workflows.
- Database ownership per service.
- Transactional Outbox for critical domain events.
- OpenTelemetry and Azure Monitor from the start.

## Why This Matters

| Outcome | Impact |
|---|---|
| Clear service ownership | Faster engineering decisions and fewer cross-team conflicts |
| API governance | Safer external integrations and better lifecycle control |
| Event-driven workflow | Better resilience across order, inventory, payment, and fulfillment |
| Observability by design | Faster incident diagnosis and better production confidence |
| Architecture gates | Reduced risk before production rollout |

## Key Risks

- Over-splitting services before team maturity supports it.
- Weak event governance causing inconsistent workflows.
- Under-investing in observability and support tooling.
- Moving to AKS too early and increasing operating complexity.

## Mitigations

- Start with capability-based service boundaries.
- Require ADRs for major platform decisions.
- Keep destructive MCP tools behind approval gates.
- Use Green / Amber / Red architecture acceptance gates.
- Review architecture against Well-Architected pillars before production.

## Proposed Next Step

Approve MVP architecture with an Amber readiness status, subject to closing the top production-readiness gaps in security, observability, and operational runbooks.
