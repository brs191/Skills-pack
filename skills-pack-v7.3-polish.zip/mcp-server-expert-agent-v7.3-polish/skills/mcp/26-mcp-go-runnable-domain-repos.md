# Skill — MCP-Go Runnable Domain Repos

## Purpose

Generate runnable starter repos for common MCP server domains.

## Supported Domains

- Azure FinOps MCP Server
- DevOps MCP Server
- Observability MCP Server
- Azure Network Reviewer MCP Server

## Minimum Repo Contents

```text
cmd/server/main.go
internal/mcpserver/server.go
internal/tools/<domain>/*.go
internal/services/<domain>/*.go
internal/connectors/mock/*.go
internal/policy/policy.go
internal/policy/policy_test.go
internal/security/redaction.go
internal/security/redaction_test.go
contracts/*.json
docs/tools.md
clients/stdio-config.json
deployments/k8s/deployment.yaml
.github/workflows/ci.yml
Dockerfile
Makefile
go.mod
README.md
```

## Rule

Start with read-only tools. Add write tools only after explicit policy, approval, audit, and rollback paths are included.
