# ADR-004 — Use Azure Container Apps for MVP and AKS for Scale-Required Domains

## Status

Accepted

## Context

The platform needs a practical deployment model for microservices. The team needs to move quickly for the MVP while keeping a path to more advanced networking, scaling, service mesh, and platform engineering capabilities if the system grows.

The architecture should avoid choosing Kubernetes only because it is popular. Operational complexity must match team maturity and platform needs.

## Decision

Use **Azure Container Apps** for the MVP deployment of most services.

Move selected domains to **AKS** only when requirements justify it, such as advanced networking, custom controllers, service mesh, high-volume workload specialization, or strict platform standardization.

## Options Considered

| Option | Pros | Cons |
|---|---|---|
| Azure Container Apps only | Faster MVP, lower operational burden, built-in scaling | Less control than AKS for advanced platform scenarios |
| AKS only | Maximum control, mature Kubernetes ecosystem | Higher operational complexity and platform engineering burden |
| App Service | Simple HTTP hosting | Less natural fit for many containerized event-driven workers |
| Hybrid Container Apps + AKS | Practical MVP with scale path | Requires clear placement rules to avoid fragmentation |

## Decision Drivers

- Speed to MVP
- Team operational capacity
- Cost and complexity control
- Future scale path
- Support for event-driven services
- Avoid premature platform complexity

## Consequences

### Positive

- Faster initial delivery
- Less Kubernetes operational overhead
- Good fit for API and worker services
- Clear path to AKS for advanced workloads

### Negative

- Platform may become split if migration rules are unclear
- Some advanced traffic/security patterns may need AKS later
- Teams must understand both Container Apps and AKS if hybrid becomes real

## Failure Modes

- Moving to AKS too early increases delivery friction
- Staying on Container Apps too long may limit advanced requirements
- Inconsistent deployment standards across services
- Hidden networking constraints discovered late

## Operational Impact

- Define service placement rules.
- Use consistent CI/CD, observability, identity, and secret patterns across both platforms.
- Keep container images, health probes, and environment configuration portable.
- Review platform choice at each scale or compliance milestone.

## Cost Impact

Container Apps is generally more efficient for MVP and variable workloads. AKS may be justified when high utilization, advanced platform features, or organizational standardization offset operational costs.

## Azure Services Involved

- Azure Container Apps
- Azure Kubernetes Service
- Azure Container Registry
- Azure API Management
- Azure Monitor / Application Insights
- Azure Key Vault
- Managed Identity

## MCP Tools / Resources Impacted

- `review_microservice_design`
- `score_well_architected_readiness`
- `map_patterns_to_azure_services` planned
- `generate_deployment_topology` planned

## Review Date

Review before production launch, major traffic growth, service mesh adoption, or platform standardization decisions.
