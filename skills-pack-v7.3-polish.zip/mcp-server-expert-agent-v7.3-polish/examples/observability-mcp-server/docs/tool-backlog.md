# Observability MCP Tool Backlog

| Tool | Purpose | Risk | Approval | Status | Test cases |
|---|---|---|---|---|---|
| `query_logs` | Query bounded log windows | Medium | No | Implemented starter | invalid time range, too many rows, redaction |
| `detect_error_spike` | Identify abnormal error increase | Low | No | Implemented starter | no baseline, noisy baseline, spike detected |
| `summarize_incident` | Summarize logs/metrics into incident context | Medium | No | Planned | missing telemetry, partial data, high cardinality |
| `correlate_logs_metrics` | Correlate logs and metrics by time window | Medium | No | Planned | clock skew, empty metrics, multiple services |
| `generate_runbook_recommendation` | Recommend next operational steps | Medium | Optional | Planned | known incident, unknown incident, confidence low |

## Implementation rules

- Bound all time ranges and result sizes.
- Redact secrets, headers, tokens, customer identifiers, and PII.
- Preserve query references for audit.
- Do not allow arbitrary unbounded query execution.
