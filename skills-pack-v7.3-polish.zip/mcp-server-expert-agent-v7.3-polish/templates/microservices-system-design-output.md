# Microservices System Design Output Template

## 1. Problem Statement

## 2. Business Capabilities

## 3. Service Boundaries
| Service | Responsibility | Owns Data? | APIs | Events |
|---|---|---:|---|---|

## 4. Recommended Patterns
| Pattern | Why Needed | Azure Mapping | Risk |
|---|---|---|---|

## 5. Architecture
```text
Client
  ↓
Azure Front Door / APIM
  ↓
AKS / Container Apps
  ↓
Services
  ↓
Databases / Events / Cache
```

## 6. Data Ownership

## 7. Communication Model

## 8. Resilience Design

## 9. Security Design

## 10. Observability Design

## 11. Deployment Topology

## 12. Cost Considerations

## 13. Risks and Mitigations

## 14. ADRs Needed

## 15. MVP Implementation Roadmap
