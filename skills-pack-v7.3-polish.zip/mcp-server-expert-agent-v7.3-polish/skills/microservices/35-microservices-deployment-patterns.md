# Skill — Microservices Deployment Patterns

## Purpose
Select cloud deployment topology and release patterns for microservices.

## Deployment Options
| Option | Use When |
|---|---|
| AKS | complex platform, service mesh, advanced networking, high control |
| Azure Container Apps | managed microservices, event-driven scaling, simpler ops |
| App Service | simple HTTP service, low ops complexity |
| Functions | event-driven functions, glue workflows, small scoped tasks |

## Release Patterns
- Blue-green for fast rollback with parallel environments
- Canary for controlled exposure
- Rolling deployment for standard stateless services
- Feature flags for behavior rollout
- Shadow traffic for validation where safe

## Required Deployment Assets
- Dockerfile
- health endpoint
- readiness/liveness probes
- resource limits
- environment-specific config
- secrets from Key Vault
- CI pipeline
- rollback plan
