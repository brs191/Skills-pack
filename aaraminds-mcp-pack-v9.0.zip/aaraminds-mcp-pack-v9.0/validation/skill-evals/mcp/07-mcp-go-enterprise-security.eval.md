---
skill: skills/mcp/07-mcp-go-enterprise-security.md
exercises_section: 8-layer defense-in-depth framework
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go enterprise security

## Prompt

An MCP server exposes tools that read and modify production state (deploy services, run database migrations, kill pods). What security posture do you require before deploying it in an enterprise environment?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Risk-tier per tool** — state-changing tools (deploy, migrate, kill) are high-risk; segregate their handlers and policies from read-only ones
- [ ] **Authentication at the MCP transport** — only authorized clients can talk to the server; not "anyone with stdio access"
- [ ] **Audit every call** — every tool invocation logged with identity, tool, arguments (sanitized), result; immutable retention
- [ ] **Dry-run / confirmation for destructive ops** — high-risk tools support a dry-run mode and may require explicit confirmation (a separate confirm-action tool)
- [ ] **Output untrusted by definition** — clarifies that tool output may include attacker-controlled text; the *consuming LLM* must treat it as data
- [ ] **Secrets via Key Vault / Managed Identity** — the server pulls credentials at runtime, never from env vars or config files; rotation is automatic

## Reference output

> A "deploy + migrate + kill" MCP server is squarely in the highest risk tier. The bar should be:
>
> **1. Risk-tier policy per tool.** Tag each tool: `deploy_service` and `run_migration` and `kill_pod` are state-changing, irreversible-or-expensive-to-reverse — high tier. Reads (`get_deployment_status`, `list_pods`) are informational — low tier. The high-tier policy includes stronger auth, mandatory audit, dry-run support, and possibly a separate confirmation step. Don't apply one policy to all tools.
>
> **2. Authentication at the transport.** The MCP transport must require authentication: who is calling the server? Stdio transport in an enterprise context implies the calling process (Claude Code, a workflow runner) has been authorized to invoke the server; verify at process boundary or via per-tool token claims. HTTP transport adds OAuth/JWT validation. "Anyone with stdio access" is not authentication.
>
> **3. Audit every call.** Structured audit log per invocation: `{timestamp, identity, tool, arguments_hash, result, decision, latency}`. Sanitize arguments (don't log secrets, don't log full PII). Pipe to an immutable store (Log Analytics with retention, or a write-once audit sink). Retention according to compliance regime; 1 year minimum for any operation that touches production state.
>
> **4. Dry-run + confirmation for destructive ops.** Every high-risk tool supports a `dry_run: true` argument that returns what *would* happen without doing it. For irreversible ops (`kill_pod`, `delete_resource`), require a two-step pattern: a planning tool returns a plan ID + summary; a confirmation tool executes the plan by ID. This prevents one bad LLM step from causing destruction.
>
> **5. Output is data, not instructions.** Tool outputs can contain attacker-controlled text (e.g., a deployed service's log content). The consuming LLM must be prompted to treat tool output as data, not as further instructions. The MCP server cannot defend against prompt injection in its output content; the consuming agent's prompt design must. The skill makes this explicit: don't try to "sanitize for prompt injection" in the server — wrong layer, brittle.
>
> **6. Secrets via Managed Identity + Key Vault.** The server's process has a Managed Identity. It fetches credentials at runtime from Key Vault (or environment-injected via the CSI driver). No long-lived credentials in env vars, no `kubeconfig.yaml` files in the container, no API keys in source. Rotation happens in Key Vault; the server picks up new values on the next request.
>
> **7. Per-tool authorization.** Authentication answers "who"; authorization answers "what they can do." Per-tool allow-lists: this identity can call `deploy_service` but not `run_migration`. Enforced before the handler executes; failures return a tool-result-error, logged at Info/Warn.
>
> **8. Network egress restrictions.** The server pod has minimum egress: only the Azure APIs it needs to call (Container Apps, ARM, AKS) plus Key Vault. Default-deny on everything else. Limits the blast radius if the server is compromised.
>
> **Don't ship without**
> Risk tiers (1), authentication (2), audit (3), dry-run for destructive ops (4), Key Vault for secrets (6). Items 5, 7, 8 are best-practice; the first five are merge-blockers.

## Notes

Catches LLMs that treat MCP servers as "trusted tooling" by default. The destructive-operations framing forces an enterprise-grade answer.
