# Skill — MCP Architecture Tool Execution

## Purpose

Show how architecture-focused MCP tools are executed in a realistic agent workflow.

## Use When

The user asks how an MCP-based architect agent would actually review, generate, or score a design.

## Default Flow

1. `review_microservice_design`
2. `recommend_microservice_patterns`
3. `map_patterns_to_azure_services`
4. `detect_architecture_risks`
5. `generate_service_boundary_canvas`
6. `generate_architecture_decision_record`
7. `score_well_architected_readiness`

## Output Rule

Show the tool call intent, sample input, sample output, and how the agent uses the result.
