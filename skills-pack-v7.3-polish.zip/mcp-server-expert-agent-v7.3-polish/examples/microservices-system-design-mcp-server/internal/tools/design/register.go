package design

import (
	"context"
	"encoding/json"
	"strings"

	designsvc "github.com/example/microservices-system-design-mcp-server/internal/services/design"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func Register(s *server.MCPServer, svc *designsvc.Service) {
	review := mcp.NewTool("review_microservice_design",
		mcp.WithDescription("Review a microservices system design for Azure cloud readiness"),
		mcp.WithString("system_name", mcp.Required(), mcp.Description("Name of the system")),
		mcp.WithString("business_capability", mcp.Description("Business capability being designed")),
		mcp.WithString("deployment_target", mcp.Description("AKS, Container Apps, App Service, or hybrid")),
		mcp.WithString("services", mcp.Description("Comma-separated proposed services")),
	)
	s.AddTool(review, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		name, err := req.RequireString("system_name")
		if err != nil { return mcp.NewToolResultError("system_name is required"), nil }
		capability := req.GetString("business_capability", "")
		deployment := req.GetString("deployment_target", "")
		servicesRaw := req.GetString("services", "")
		services := []string{}
		if servicesRaw != "" { services = strings.Split(servicesRaw, ",") }
		res := svc.Review(designsvc.ReviewInput{SystemName:name, BusinessCapability:capability, DeploymentTarget:deployment, Services:services})
		b, _ := json.MarshalIndent(res, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})

	recommend := mcp.NewTool("recommend_microservice_patterns",
		mcp.WithDescription("Recommend microservices patterns based on a problem statement"),
		mcp.WithString("problem", mcp.Required(), mcp.Description("Problem statement or design challenge")),
	)
	s.AddTool(recommend, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		problem, err := req.RequireString("problem")
		if err != nil { return mcp.NewToolResultError("problem is required"), nil }
		b, _ := json.MarshalIndent(map[string]any{"patterns": svc.RecommendPatterns(problem)}, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})

	score := mcp.NewTool("score_well_architected_readiness",
		mcp.WithDescription("Score a microservices design against Azure Well-Architected style pillars"),
		mcp.WithString("system_name", mcp.Required(), mcp.Description("System name")),
	)
	s.AddTool(score, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		_, err := req.RequireString("system_name")
		if err != nil { return mcp.NewToolResultError("system_name is required"), nil }
		b, _ := json.MarshalIndent(svc.ScoreWellArchitected(), "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})

}
