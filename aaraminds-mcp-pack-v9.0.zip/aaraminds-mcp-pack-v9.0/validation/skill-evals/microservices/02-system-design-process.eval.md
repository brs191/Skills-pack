---
skill: skills/microservices/02-system-design-process.md
exercises_section: 11-stage design methodology
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: system design process

## Prompt

We're about to start designing a new microservices system. The team wants to jump into "what services do we build?" Name three stages of the design process that should come *before* listing services, and explain what each stage closes off.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Capability modeling stage** — names defining business capabilities as a precondition to service identification
- [ ] **Domain decomposition stage** — names identifying bounded contexts (DDD) as the antecedent to services
- [ ] **Boundary validation stage** — names checking that proposed boundaries have clean data ownership and team ownership before committing
- [ ] **Each stage has an exit criterion** — for at least two stages, names what "done" looks like (e.g., "every context has named owner and data set")
- [ ] **Skipping leads to specific failure** — for at least one stage, names the failure mode when teams skip it (distributed monolith, hot aggregate, service-with-no-owner)
- [ ] **Verification gate before next stage** — frames each stage as ending in a verification, not just a deliverable

## Reference output

> Three stages, in order, that close off questions before service-listing is appropriate:
>
> **1. Capability modeling.** List the business capabilities the system delivers — what value does it produce? For an e-commerce platform: order capture, inventory management, payment processing, fulfillment, notification. Exit criterion: every capability has a one-sentence description of the value it produces. Skipping leads to services like "data-service" or "utility-service" — services without a defensible reason to exist.
>
> **2. Domain decomposition.** Map capabilities to bounded contexts. A bounded context is the scope within which a domain term has a single, agreed meaning. "Order" in the ordering context vs. "order" in the fulfillment context may refer to overlapping but distinct things; the decomposition makes that explicit. Exit criterion: every concept has exactly one canonical home; ambiguous concepts (an "order" that lives in three places) are resolved before moving on. Skipping leads to schema-coupled services that have to deploy together.
>
> **3. Boundary validation.** For each candidate service derived from the contexts: does it own its data cleanly? Does it have a single owning team? Are dependencies acyclic? Is the dependency graph not chatty? Exit criterion: a service-boundary canvas (or equivalent) is signed off by the owning teams. Skipping leads to distributed monoliths, shared databases, services nobody admits to owning.
>
> Each stage ends with a verification, not just a deliverable. "We have a list of bounded contexts" is not enough; "we have a list of bounded contexts where every concept has one canonical home" is.

## Notes

Catches LLMs that produce a generic SDLC answer (requirements → design → build) without engaging with the microservices-specific staging.
