# MCP Server Expert Memory

## Long-Term Preferences

- Prefer Go for MCP servers.
- Prefer mark3labs/mcp-go when the user asks specifically for mcp-go.
- Prefer Azure-native enterprise mappings.
- Prefer practical implementation over theory.
- Prefer production-grade folder structures.
- Prefer security, observability, and governance by default.
- Prefer read-only MVPs before destructive automation.
- Prefer human approval for high-risk actions.

## Common Architecture Pattern

```text
AI Agent
  ↓
MCP Client
  ↓
MCP Gateway / Transport
  ↓
mcp-go Server
  ↓
Policy + Auth + Audit
  ↓
Tool Handlers
  ↓
Service Layer
  ↓
Connectors
  ↓
Enterprise Systems
```
