# Diagram Output Template

## Diagram Name

## Audience

Business / Technical / Executive / Engineering

## Purpose

## Diagram Type

C4 Context / Container / Deployment / Sequence / Event Flow / MCP Tool Flow

## Mermaid

```mermaid

```

## PlantUML

```plantuml

```

## draw.io Prompt

Describe the diagram clearly, including layers, components, labels, and arrows.
