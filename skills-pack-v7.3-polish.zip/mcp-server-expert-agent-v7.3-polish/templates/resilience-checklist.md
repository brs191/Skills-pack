# Resilience Checklist

## Failure Mode Inventory

| Failure mode | Impact | Detection | Mitigation | Owner |
|---|---|---|---|---|

## Required Controls

- [ ] Timeouts are defined for every remote call.
- [ ] Retries are bounded and use backoff.
- [ ] Circuit breakers exist for unstable dependencies.
- [ ] Bulkheads isolate critical workflows.
- [ ] Async workflows have DLQs.
- [ ] Consumers are idempotent.
- [ ] Saga compensation is defined where needed.
- [ ] Outbox/inbox is used where event consistency matters.
- [ ] Degraded mode is defined.
- [ ] RTO/RPO is documented.
- [ ] DR runbook exists.
- [ ] Alerts are tied to user/business impact.

## Azure Notes

- Service Bus DLQ:
- Availability zones:
- Multi-region strategy:
- Backup and restore:
- Azure Monitor alerts:
