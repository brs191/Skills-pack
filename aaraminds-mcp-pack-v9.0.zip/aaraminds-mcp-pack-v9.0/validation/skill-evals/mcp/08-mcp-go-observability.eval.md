---
skill: skills/mcp/08-mcp-go-observability.md
exercises_section: Three pillars adapted for MCP servers
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go observability

## Prompt

What does observability look like specifically for an MCP server (as opposed to a generic HTTP service)? Name three things that change in the design.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Stderr for logs on stdio** — names that stdio transport forces logs to stderr; stdout is the protocol wire
- [ ] **Per-tool structured fields** — every log line includes `tool=<name>` so per-tool metrics, dashboards, and alerts work
- [ ] **Tool-call as the unit of observation** — events: tool call started, tool call completed, tool call rejected (validation), tool call errored (internal); each with a clear level
- [ ] **Audit emitter separate from app log** — for state-changing tools, audit logs are a separate stream with stronger retention and immutability than operational logs
- [ ] **Avoid logging full input/output** — input may be large or contain PII; log derived fields and counts
- [ ] **Correlation across MCP → downstream calls** — trace context propagates from the MCP request into any downstream HTTP/DB calls the tool makes; one trace covers the whole request

## Reference output

> Three core things change because MCP servers are not generic HTTP services:
>
> **1. Stdout is sacred; logs go to stderr.** On stdio transport (the default), every byte to stdout is part of the protocol wire. A misconfigured logger that writes to stdout corrupts the MCP messages and the server appears broken to clients. Set `slog.NewJSONHandler(os.Stderr, ...)` and never call `fmt.Println` from the handler path. This is observability infrastructure choice #1.
>
> **2. The unit of observation is the tool call, not the HTTP request.** Every handler emits a structured log on entry (`tool_call_started`), one on completion (`tool_call_completed` with derived fields like `services_analyzed`, `risks_identified`, `latency_ms`), and one per failure mode (`tool_call_rejected` for validation failures at Warn; `tool_call_errored` for internal failures at Error). Every line includes the tool name as a structured field so per-tool dashboards and alerts are queries, not greps.
>
> **3. Audit is its own stream for state-changing tools.** Operational logs (start, complete, error) and audit logs (who called what state-changing operation when, what was the decision) have different retention, immutability, and access requirements. For tools that change state, emit an audit event in addition to the operational log. Different sink (audit table, write-once blob, separate Log Analytics workspace), different retention (compliance-driven), different access (auditors, not on-call).
>
> **Other MCP-specific concerns**
>
> - **Don't log full input/output.** `input_json` can be large or contain PII. Log derived fields (`system=foo`, `services_count=12`) instead of the full payload. The skill is explicit about this.
> - **Correlation across downstream calls.** When the tool calls Azure APIs or databases, propagate trace context (`traceparent` header) so the entire tool call surfaces as one trace, not as fragmented spans.
> - **Resource saturation as a tool signal.** If the tool's processing time exceeds a threshold, alert; if rejection rate climbs, alert. The tool's own behavior is the operational telemetry, not just the host's CPU.
> - **Metrics worth emitting**: tool call count per tool, latency histogram per tool, rejection count per tool with reason, error count per tool with class. From these, dashboards and SLOs follow directly.

## Notes

Catches LLMs that recite generic observability without engaging with MCP's specific shape (stdio transport, tool-call unit of work, audit-vs-app log separation).
