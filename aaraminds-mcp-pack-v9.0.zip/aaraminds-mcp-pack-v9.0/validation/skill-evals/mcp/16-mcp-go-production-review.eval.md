---
skill: skills/mcp/16-mcp-go-production-review.md
exercises_section: Review sections and report structure
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go production review

## Prompt

I'm asked to do a production-readiness review for a new MCP server. Name the categories I should check, give one example finding per category that would be a deploy-blocker, and describe the report format.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Multi-category framework** — names at least 6 review areas (skeleton, tool design, structure, security, observability, testing, deployment, docs, freshness, evidence)
- [ ] **Deploy-blocker examples per area** — concrete blocker per category, not vague concerns
- [ ] **Verdict structure** — report has ready / conditionally ready / not ready with named conditions
- [ ] **Blockers vs. follow-ups** — distinguishes must-fix-before-deploy from must-fix-after
- [ ] **Re-review trigger** — names the cadence for next review (major version, quarterly, etc.)
- [ ] **Specificity over abstraction** — findings stated specifically, not "improve security"

## Reference output

> **Categories (minimum)**
>
> 1. Server skeleton (main.go, transport, logging, shutdown)
> 2. Tool design (intent-based, typed inputs, descriptions, risk tiers)
> 3. Project structure (service vs. wiring, no globals)
> 4. Security (auth, authz, secrets, input bounds, audit)
> 5. Observability (tool-call events, metrics, alerts, SLOs)
> 6. Testing (unit, handler, service, contract, security, smoke)
> 7. Deployment (image, manifest, health, rollback)
> 8. Documentation (README, contracts, runbook)
> 9. Freshness (ecosystem facts current, no TODOs in docs)
> 10. Validation evidence (per-skill evals run, demo passes)
>
> **One blocker example per area**
>
> - *Skeleton:* logs going to stdout under stdio transport. Wire is corrupted.
> - *Tool design:* one kitchen-sink tool dispatched on a string action.
> - *Structure:* business logic in `register.go`; service package is empty.
> - *Security:* no authentication on the HTTP transport; anyone on the network can call any tool.
> - *Observability:* no logs on tool calls; on-call has no signal during incidents.
> - *Testing:* no service-layer tests; only one integration test claiming 95% line coverage.
> - *Deployment:* health probe returns 200 from a static handler; the server can be unhealthy and look fine.
> - *Documentation:* no runbook; on-call doesn't know how to rollback.
> - *Freshness:* ecosystem facts dated 14 months ago; SDK version drifted.
> - *Validation evidence:* per-skill evals haven't been run since the last skill change.
>
> **Report format**
>
> ```
> ## Verdict
> [Ready to ship | Conditionally ready (with named conditions) | Not ready (with blockers)]
>
> ## Findings (per category)
> ### Security
> - [pass] Authentication: OAuth/JWT middleware in place.
> - [hard-fail] No per-tool authorisation; any authenticated caller can invoke any tool.
> - [soft-fail] Audit logs lack retention configuration; default is 30 days.
> ...
>
> ## Blockers (must fix before deploy)
> - Per-tool authorisation (Security)
> - Health probe exercises actual readiness (Deployment)
> - Service-layer tests for boundary rules (Testing)
>
> ## Follow-ups (post-deploy)
> - Audit log retention extension to 1 year (Security)
> - SLOs documented in code (Observability)
>
> ## Re-review trigger
> Next major version, or by [date], whichever comes first.
> ```
>
> **Specificity bar**
>
> If a reviewer can't articulate a finding in one line, the review is too abstract. "Improve security" is not a finding; "no per-tool authorisation, anyone authenticated can invoke `deploy_service`" is. Push back on vague reviews and require specifics.

## Notes

Catches LLMs that produce a checklist without examples or that elide the verdict structure.
