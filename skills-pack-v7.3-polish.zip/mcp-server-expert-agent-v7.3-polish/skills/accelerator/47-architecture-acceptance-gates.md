# Skill — Architecture Acceptance Gates

## Purpose

Define clear acceptance gates before a microservices or MCP architecture is considered implementation-ready.

## Use When

The user asks whether a design is ready, production-grade, or fit for architecture board approval.

## Required Gates

1. Business capability boundaries are clear.
2. Service ownership is assigned.
3. Data ownership is explicit.
4. Sync/async communication choices are justified.
5. Consistency model is documented.
6. Security model is defined.
7. Observability is included from day one.
8. Resilience patterns are selected.
9. Deployment topology is practical.
10. Cost drivers are understood.
11. ADRs exist for major decisions.
12. Rollback and operational runbooks exist.
13. MCP tools have contracts, auth, audit, and approval logic where needed.

## Rating

- Green: ready for implementation
- Amber: proceed with targeted fixes
- Red: not ready
