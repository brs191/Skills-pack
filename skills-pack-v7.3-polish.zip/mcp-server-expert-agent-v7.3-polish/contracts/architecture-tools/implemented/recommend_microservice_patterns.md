## Status

implemented

# Tool Contract: recommend_microservice_patterns

## Purpose
Recommend Microservice Patterns for Azure-hosted microservices architecture.

## Inputs
- `system_name`: string, required
- `business_capability`: string, required when applicable
- `services`: array, optional
- `data_stores`: array, optional
- `communication`: array, optional
- `deployment_target`: string, optional
- `constraints`: array, optional
- `non_functional_requirements`: object, optional

## Output
- summary
- recommendations
- azure_service_mapping
- risks
- missing_decisions
- next_steps

## Risk Level
Low

## Approval Required
No. This is a read-only architecture assessment/generation tool.
