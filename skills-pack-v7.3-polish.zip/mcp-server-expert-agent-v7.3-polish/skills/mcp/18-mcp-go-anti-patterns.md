# Skill — MCP-Go Anti-Patterns

## Purpose
Identify and correct common MCP server design mistakes.

## Use When
The user asks for a review, design critique, or production hardening.

## Anti-Patterns

### 1. Raw API Wrapper MCP Server

Bad:
- One MCP tool per REST endpoint
- Internal API names exposed to agents
- No business intent

Better:
- Tools represent safe user intents: `get_cost_summary`, `summarize_failed_pipeline`, `detect_nsg_risks`.

### 2. One Mega Tool

Bad:
- `execute_action(action, payload)`
- `run_query(query)`
- `call_backend(method, path, body)`

Better:
- Small explicit tools with clear input schemas and risk levels.

### 3. Shell Execution Tool

Bad:
- Letting an LLM run arbitrary shell commands.

Better:
- Predefined tools with explicit parameters, allowlists, dry-run mode, and approval.

### 4. Unbounded Query Tool

Bad:
- Query all logs for 30 days with no limit.

Better:
- Enforce time windows, result limits, and summarization.

### 5. No Per-Tool Authorization

Bad:
- User is authenticated once and can call every tool.

Better:
- Check role, tenant, environment, and tool risk for every call.

### 6. No Approval Boundary

Bad:
- Agent can deploy, restart, delete, or change firewall rules directly.

Better:
- Dry-run, policy decision, human approval, audit, rollback.

### 7. Secrets in Tool Results

Bad:
- Returning connection strings, tokens, headers, or secret names unnecessarily.

Better:
- Redact secrets before sending output to the model.

### 8. Business Logic Inside MCP Handler

Bad:
- Tool handler contains Azure SDK calls, policy logic, formatting, and persistence.

Better:
- Handler parses input → service layer → connector layer → result formatter.

### 9. No Contract Discipline

Bad:
- Tool schemas change silently.

Better:
- Keep tool contracts in `contracts/tools/`, version breaking changes, and add tests.

### 10. No Observability

Bad:
- Only print errors to stdout.

Better:
- Structured logs, tool metrics, traces, audit events, dependency latency.
