# Skill — Microservices Data Patterns

## Purpose
Guide database ownership, consistency, and event-driven data design.

## Rules
1. A service should own its data.
2. Avoid shared databases across services.
3. Avoid distributed transactions unless there is no realistic alternative.
4. Use Saga when business workflows cross service boundaries.
5. Use Transactional Outbox when events must be reliably published after a local transaction.
6. Use CQRS when read and write workloads differ materially.
7. Use Event Sourcing only when auditability and state reconstruction justify complexity.
8. Use projections/read models for cross-service query needs.

## Azure Mapping
| Pattern | Azure Implementation |
|---|---|
| Database per service | Cosmos DB, Azure SQL, PostgreSQL Flexible Server |
| Outbox | SQL/Cosmos outbox table/container + worker |
| CQRS | Write store + projection store + Service Bus/Event Grid |
| Event Sourcing | Event store on Cosmos/SQL/Event Hubs depending requirements |
| Cache Aside | Redis + service cache policy |
| Read model | Cosmos DB, Azure SQL, Azure Cognitive Search |

## Anti-Patterns
- Shared database as integration layer
- Direct cross-service joins
- Synchronous calls for reporting queries
- Unversioned events
- No idempotency key
- No dead-letter handling
