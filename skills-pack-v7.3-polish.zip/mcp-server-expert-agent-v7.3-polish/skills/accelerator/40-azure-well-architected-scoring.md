# Skill — Azure Well-Architected Scoring

## Purpose

Score cloud-native microservices designs against Azure Well-Architected style pillars.

## Pillars

- Reliability
- Security
- Cost Optimization
- Operational Excellence
- Performance Efficiency

## Scoring Output

Return:

- pillar score
- evidence
- top risks
- recommended remediations
- priority actions
- overall score

## Scoring Rule

Do not give a high score unless the design includes implementation evidence: deployment topology, security model, observability, failure handling, data consistency, and operational ownership.
