# MCP Production Readiness Review Template

## Overall Rating
`/10`

## Readiness Summary
One paragraph.

## Architecture
- [ ] Clear MCP primitive separation
- [ ] Tool/service/connector boundaries
- [ ] Versioned contracts

## Security
- [ ] AuthN
- [ ] AuthZ
- [ ] Tenant isolation
- [ ] Approval for high-risk tools
- [ ] Output redaction

## Reliability
- [ ] Timeouts
- [ ] Retries
- [ ] Circuit breaker where required
- [ ] Graceful shutdown

## Observability
- [ ] Structured logs
- [ ] Metrics
- [ ] Traces
- [ ] Audit logs

## Deployment
- [ ] Dockerfile
- [ ] Config model
- [ ] Health/readiness endpoints for HTTP deployment
- [ ] Kubernetes/Azure deployment plan

## Testing
- [ ] Unit tests
- [ ] Handler tests
- [ ] Contract tests
- [ ] Security tests

## Priority Fixes
1. 
2. 
3.
