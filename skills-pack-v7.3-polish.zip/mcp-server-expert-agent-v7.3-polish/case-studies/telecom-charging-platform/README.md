# Case Study — Telecom Charging Platform on Azure

## Scenario

A telecom provider needs a usage-based charging platform that processes high-volume events from network systems, rates usage, applies customer plan rules, detects anomalies, and publishes billing-ready records.

## Candidate Services

| Service | Responsibility |
|---|---|
| Usage Ingestion | Ingests network usage events |
| Rating Service | Applies pricing and plan rules |
| Balance Service | Tracks prepaid/postpaid balance impacts |
| Policy Service | Applies throttling, roaming, and entitlement rules |
| Billing Export Service | Produces billing-ready records |
| Anomaly Detection Service | Detects unusual usage or fraud indicators |

## Recommended Patterns

- Event-driven architecture
- Event Hubs for high-volume ingestion
- Service Bus for business commands
- CQRS for read/write separation
- Idempotent consumers
- Transactional outbox
- Distributed tracing
- Partitioning by customer/subscriber/account

## Azure Mapping

| Concern | Azure Service |
|---|---|
| High-volume event ingestion | Event Hubs |
| Business workflow | Service Bus |
| Rules engine data | Cosmos DB / Azure SQL |
| Stream processing | Azure Functions / AKS workers / Stream Analytics |
| Observability | Azure Monitor + OpenTelemetry |
| Secrets | Key Vault |

## Key Risk

Do not use synchronous request chains for high-volume usage processing. Use event-driven ingestion and bounded async processing.
