---
skill: skills/mcp/09-mcp-go-testing.md
exercises_section: Layered test pyramid for MCP servers
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go testing

## Prompt

A team's MCP server has 95% line coverage from a single integration test that drives the server over stdio and asserts the tool returns successfully for one known input. They're proud of the coverage number. Critique this test strategy.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Coverage is a vanity metric** — 95% from one happy-path test isn't useful coverage; the rule logic isn't exercised
- [ ] **Layered pyramid is missing** — names the layers absent (unit, handler, service, contract, transport, security, smoke)
- [ ] **Negative cases absent** — no tests for missing input, invalid JSON, schema-bypass, oversized input
- [ ] **Service-layer tests are the gap** — service rules aren't exercised in isolation; bugs in rule logic surface only as integration failures
- [ ] **Slow feedback** — one integration test is slow; team can't iterate at unit-test speed
- [ ] **Specific remedies** — names table-driven service tests, handler tests for validation paths, a small security test suite as the missing artifacts

## Reference output

> 95% line coverage from one happy-path integration test is the textbook case of coverage as a vanity metric. The number is high; the actual confidence is low.
>
> **What's wrong**
>
> - **One test = one path.** A single end-to-end call with a known-good input exercises the lines but not the conditions. Every branch except the happy one is uncovered in the behavioural sense, even if the lines registered as "covered" because the import paths were touched.
> - **No layered coverage.** The MCP testing pyramid has eight layers (unit, tool-handler, service, connector, contract, transport, security, deployment-smoke). This team has one — the slowest, most expensive layer. Bugs caught at unit or handler level cost milliseconds to find; the same bugs found at integration cost minutes to investigate.
> - **No negative tests.** What happens when `input_json` is missing? Malformed? Schema-bypass? Oversized? The team can't answer; the test doesn't try. These are exactly the regressions the pyramid catches at the handler and security layers.
> - **Service rule logic isn't tested in isolation.** The service package has named rules (capability cohesion, dependency hygiene, etc.). Each should have positive and negative cases as table-driven tests. Right now, all rules pass or all rules fail — there's no granularity for diagnosis.
> - **Slow feedback ruins the dev loop.** One integration test taking 5–10 seconds is fine; ten of them taking 60 seconds discourages iteration. Unit tests run in milliseconds; teams that rely on integration-only become test-averse.
>
> **What to add**
>
> 1. **Service-layer tests, table-driven.** `internal/services/<name>/service_test.go` covers every named rule. 10–30 cases per rule, positive and negative. Runs in <1 second.
> 2. **Tool handler tests.** Cases for: missing input, invalid JSON, service returning an error, valid input passing through. One test function per handler.
> 3. **Contract test.** One test that calls `tools/list` and asserts the expected catalog. Catches accidentally-unregistered tools.
> 4. **Security test suite.** Five to ten attack-shaped inputs (oversized, malformed, path-traversal, schema-bypass). One file, run in CI.
> 5. **Keep the integration test.** It's not wrong; it's just not sufficient. As a smoke test post-deploy it earns its place.
>
> **Stop celebrating the number.** Discuss what the tests actually demonstrate. Coverage is a leading indicator only when the tests are meaningful; otherwise it's a way to feel safe while shipping bugs.

## Notes

Catches the coverage-as-quality fallacy. The pyramid framing is the value-add of the skill.
