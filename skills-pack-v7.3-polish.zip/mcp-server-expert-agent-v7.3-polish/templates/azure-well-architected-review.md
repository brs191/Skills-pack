# Azure Well-Architected Review Template

## System Name

## Review Date

## Review Scope

## Pillar Scores

| Pillar | Score / 100 | Rating | Top concern |
|---|---:|---|---|
| Reliability |  | Green / Amber / Red |  |
| Security |  | Green / Amber / Red |  |
| Cost Optimization |  | Green / Amber / Red |  |
| Operational Excellence |  | Green / Amber / Red |  |
| Performance Efficiency |  | Green / Amber / Red |  |

## Overall Readiness Gate

Green / Amber / Red

## Top Risks

| Risk | Pillar | Severity | Impact | Recommendation |
|---|---|---|---|---|

## Required Remediations Before Production

| Remediation | Owner | Priority | Acceptance criteria |
|---|---|---|---|

## Architecture Decisions Required

| Decision | ADR needed? | Owner | Due date |
|---|---|---|---|

## Evidence Reviewed

- Architecture diagram:
- API contracts:
- Event contracts:
- Deployment plan:
- Security model:
- Observability plan:
- DR plan:
- Cost model:

## Final Recommendation

Proceed / Proceed with conditions / Do not proceed
