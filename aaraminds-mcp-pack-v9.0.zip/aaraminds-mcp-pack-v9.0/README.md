# AaraMinds MCP Server Expert Skills Pack — v9.0

**Date:** May 2026
**Quality position:** 9.0+ of 10 with evidence
**SDK target:** `github.com/mark3labs/mcp-go`
**Go version:** 1.25.x minimum, 1.26.x recommended

## What this pack is

A self-contained, opinionated skills pack for building Go-language MCP (Model Context Protocol) servers and designing microservices systems on Azure. It bundles:

- 22 MCP-server-building skills with decision frameworks, anti-patterns, and worked code.
- 12 microservices-design skills covering DDD, boundaries, data architecture, resilience, observability, security, and cost.
- 21 microservices pattern cards (Saga, CQRS, Event Sourcing, Circuit Breaker, Bulkhead, Zero-Trust, etc.) with pattern-specific guidance — not generic boilerplate.
- A working example MCP server (`examples/microservices-system-design-mcp-server/`) exposing **13 tools**, fully tested, Docker-buildable, with table-driven service tests and per-tool contracts.
- An MCP-driven demo that exercises the example server over the real stdio protocol across three deliberately distinct architectures (e-commerce, financial services, healthcare).
- A validation pack: 12 capability prompts + 34 per-skill evals with rubrics + 2 governance documents (freshness cadence with named ownership; a 7-section pre-release checklist).

This is v9.0: complete, standalone, and ready to use without dependence on any prior pack.

## Pack structure

```text
aaraminds-mcp-pack-v9.0/
├── README.md                              # This file
├── ROADMAP.md                             # Release history and forward path
├── VERIFICATION_CHECKLIST.md              # Step-by-step verification for adopters
├── versions.md                            # Ecosystem version pins (Go, SDKs, MCP spec)
│
├── skills/mcp/                            # 22 MCP-server-building skills
│   ├── 00-ecosystem-facts.md
│   ├── 01-mcp-go-server-basics.md
│   ├── 02-mcp-go-tool-design.md
│   ├── 03-mcp-go-resources.md
│   ├── 04-mcp-go-prompts.md
│   ├── 05-mcp-go-transport-selection.md
│   ├── 06-mcp-go-project-structure.md
│   ├── 07-mcp-go-enterprise-security.md
│   ├── 08-mcp-go-observability.md
│   ├── 09-mcp-go-testing.md
│   ├── 10-mcp-go-deployment.md
│   ├── 11-mcp-go-agent-integration.md
│   ├── 16-mcp-go-production-review.md
│   ├── 17-mcp-go-code-generation.md
│   ├── 18-mcp-go-anti-patterns.md
│   ├── 19-mcp-go-reference-implementation.md
│   ├── 20-mcp-go-threat-modeling.md
│   ├── 21-mcp-go-client-integration.md
│   ├── 22-mcp-go-cicd-quality-gates.md
│   ├── 24-mcp-go-e2e-agent-demo.md
│   ├── 25-mcp-go-security-test-generation.md
│   └── 26-mcp-go-runnable-domain-repos.md
│
├── skills/microservices/                  # 12 microservices-design skills
│   ├── 01-design-router.md
│   ├── 02-system-design-process.md
│   ├── 03-domain-decomposition.md
│   ├── 04-service-boundaries.md
│   ├── 05-data-architecture.md
│   ├── 06-resilience-patterns.md
│   ├── 07-async-messaging.md
│   ├── 08-api-design.md
│   ├── 09-azure-mapping.md
│   ├── 10-observability-design.md
│   ├── 11-security-design.md
│   └── 12-cost-and-tradeoffs.md
│
├── patterns/microservices/                # 21 pattern cards
│   ├── api-gateway.md / async-messaging.md / backend-for-frontend.md
│   ├── blue-green-canary.md / bulkhead.md / cache-aside.md
│   ├── circuit-breaker.md / cqrs.md / database-per-service.md
│   ├── distributed-tracing.md / event-driven-architecture.md
│   ├── event-sourcing.md / idempotent-consumer.md / retry-timeout.md
│   ├── saga.md / service-discovery.md / service-mesh.md
│   ├── sidecar.md / strangler-fig.md / transactional-outbox.md
│   └── zero-trust-service-access.md
│
├── examples/microservices-system-design-mcp-server/
│   ├── README.md                          # How to build, run, configure
│   ├── go.mod                             # Module definition
│   ├── Makefile                           # build, test, run-stdio, run-http, docker-build
│   ├── Dockerfile                         # Multi-stage, distroless, non-root
│   ├── .github/workflows/ci.yml           # Lint, vet, race, build
│   ├── cmd/server/main.go                 # Entry point with transport selection
│   ├── internal/
│   │   ├── mcpserver/server.go            # Composition root; wires all 13 tools
│   │   ├── services/                      # 11 service packages (one per tool surface)
│   │   └── tools/                         # 11 tool packages (MCP registration)
│   ├── contracts/architecture-tools/
│   │   └── implemented/                   # 10 architecture-tool contracts
│   └── testdata/                          # Input + golden output JSON per tool
│
├── demo/architecture-review-demo/
│   ├── README.md                          # How to drive the demo
│   ├── Makefile                           # demo / validate / refresh / clean
│   ├── demo_runner.py                     # Stdlib-only Python MCP client over stdio
│   ├── validate_outputs.py                # Canonical-JSON comparison vs. goldens
│   ├── input/                             # 3 master architecture descriptions
│   │   ├── ecommerce.json
│   │   ├── financial-services.json
│   │   └── healthcare.json
│   └── golden/<arch>/<tool>.json          # Captured outputs from the live server
│
└── validation/
    ├── README.md
    ├── prompts/                           # 12 capability prompts with rubrics
    │   ├── mcp-server-building/           # 3 prompts
    │   ├── microservices-design/          # 4 prompts
    │   ├── architecture-review/           # 3 prompts
    │   └── cross-cutting/                 # 2 prompts
    ├── skill-evals/                       # 34 per-skill evals
    │   ├── template.md
    │   ├── microservices/                 # 12 evals
    │   └── mcp/                           # 22 evals
    └── governance/
        ├── freshness-cadence.md           # Quarterly refresh ownership
        └── release-checklist.md           # 7-section pre-release runbook
```

## What you get, by area

### MCP server building (22 skills)

Every skill goes deep enough to be operationally useful: decision frameworks, worked Go code, anti-patterns named with code-review-visible detection signals, verification questions, cross-references to other skills and patterns. Coverage spans server basics, tool design, resources, prompts, transport selection, project structure, enterprise security, observability, testing, deployment, agent and client integration, code generation, anti-patterns, reference implementation walkthrough, threat modeling, CI/CD gates, end-to-end demo design, security test generation, and the shape of runnable example repos.

### Microservices design (12 skills + 21 pattern cards)

The skills cover the design router, an 11-stage design process, domain decomposition (DDD), service boundary validation, data architecture (saga / outbox / CQRS / event sourcing), resilience, async messaging, API design, Azure mapping, observability design, security design, and cost trade-offs.

The 21 pattern cards each ship with: Problem (3–5 sentences, not one), pattern-specific Use When / Avoid When criteria, an Azure Implementation section with steps and a services table, Trade-offs, Common Failure Modes with detection signals, Decision Signals, Go Implementation Notes, MCP Tool Opportunities, Related Patterns, and References. No generic boilerplate copy-pasted across cards.

### Example MCP server (13 tools)

A complete Go MCP server demonstrating every pattern in the skills. Builds clean, tests pass under `-race`, fits a multi-stage distroless Dockerfile in under 25 MB. Tools exposed:

- **Design layer**: `review_microservice_design`, `recommend_microservice_patterns`, `score_well_architected_readiness`.
- **Architecture review and generation**: `generate_service_boundary_canvas`, `generate_api_contract`, `detect_architecture_risks`, `map_patterns_to_azure_services`, `generate_observability_plan`, `generate_architecture_decision_record`, `generate_deployment_topology`, `generate_event_contract`, `generate_resilience_plan`, `generate_diagram_assets`.

Each tool follows the package-layering discipline from `skills/mcp/06-mcp-go-project-structure.md`: rule logic in `internal/services/<name>/`, MCP wiring in `internal/tools/<name>/register.go`, contract document in `contracts/architecture-tools/implemented/<name>.md`, table-driven tests next to the service.

### Demo (3 architectures × 5 tools)

The demo at `demo/architecture-review-demo/` is **authentic**: a stdlib-only Python MCP client over stdio that spawns the Go server, performs the JSON-RPC handshake, and calls five tools per architecture across three deliberately distinct shapes (e-commerce / PCI-DSS, retail banking / SOX, HIPAA patient care / PHI). Outputs are captured as goldens; `make validate` does canonical-JSON comparison so drift is precise.

Boundary scores across the three architectures: 84 / 100 / 77. Risk counts: 6 / 3 / 2. The variance is the proof of authenticity — same server code, materially different outputs because the inputs differ materially.

### Validation pack

- **12 capability prompts** with rubrics and reference outputs spanning MCP-server-building, microservices-design, architecture-review, and cross-cutting concerns. Pass thresholds calibrated per prompt difficulty.
- **34 per-skill evals** — one per uplifted skill (12 microservices, 22 MCP). Each is a small targeted prompt with a rubric and an exemplar reference output. Format is parseable so the team can automate with their LLM of choice.
- **Governance**: `freshness-cadence.md` with named ownership slots and a quarterly refresh procedure; `release-checklist.md` is a 7-section pre-release runbook with hard/soft block rules per section.

## Quick start

### Verify it works

```bash
# From the pack root:
cd examples/microservices-system-design-mcp-server
go mod tidy && go build ./...
go test -race -count=1 ./...
```

If `go` is older than the `go.mod` declares, see the Docker recipe in [examples/microservices-system-design-mcp-server/README.md](examples/microservices-system-design-mcp-server/README.md#quick-start).

### Run the demo end-to-end

```bash
# In examples/microservices-system-design-mcp-server/:
go build -o ./mcp-server ./cmd/server

# In demo/architecture-review-demo/:
export MCP_SERVER_BIN=../../examples/microservices-system-design-mcp-server/mcp-server
make demo && make validate
# Expect: "Validation passed: 3 architecture(s) × 5 tool(s) all match golden fixtures."
```

### Use the skills with your LLM

Drop `skills/` into your LLM's context (Claude Code reads them naturally from a `.claude/` style mount). Attach the specific skill files relevant to the task. The per-skill evals in `validation/skill-evals/` are also runnable: paste the prompt + the matching skill into your LLM and score the response against the rubric.

## Quality position and how to verify

This pack is at **9.0+ with evidence**. "With evidence" means the quality claim is backed by artifacts a reviewer can run:

| Evidence | Where to find it |
|---|---|
| Deterministic MCP server outputs | `demo/architecture-review-demo/golden/` + `make validate` |
| Rubric-scored skill evals | `validation/skill-evals/` (34 evals) |
| Capability-level prompts with rubrics | `validation/prompts/` (12 prompts) |
| Pre-release runbook | `validation/governance/release-checklist.md` |
| Named ownership for freshness | `validation/governance/freshness-cadence.md` |
| Boilerplate-free pattern cards | `grep -r "The problem exists in a real workflow" patterns/microservices/ | wc -l` → `0` |

Without the evidence, the same content would be "the author asserts 9.0+." With it, a reviewer can disagree but has to point at a specific failing eval or rubric to do so. See [VERIFICATION_CHECKLIST.md](VERIFICATION_CHECKLIST.md) for the step-by-step verification recipe.

## Standardization notes

- **Go MCP SDK**: standardized on `github.com/mark3labs/mcp-go` for example-code consistency. New teams without that constraint should consider `github.com/modelcontextprotocol/go-sdk` (the official one) as the default. Don't mix SDKs in one server. See [skills/mcp/01-mcp-go-server-basics.md](skills/mcp/01-mcp-go-server-basics.md).
- **Transport**: stdio is the default for local agent integration; streamable HTTP for remote / multi-client deployments. SSE is deprecated; don't use it for new work. See [skills/mcp/05-mcp-go-transport-selection.md](skills/mcp/05-mcp-go-transport-selection.md).
- **Logging**: structured JSON via `log/slog` to stderr. **Never log to stdout under stdio transport** — stdout is the protocol wire. This is the #1 new-server bug. See [skills/mcp/01-mcp-go-server-basics.md](skills/mcp/01-mcp-go-server-basics.md).
- **Ecosystem facts dated**: every claim about Go versions, SDK versions, MCP spec versions, and Azure capabilities is dated in [skills/mcp/00-ecosystem-facts.md](skills/mcp/00-ecosystem-facts.md). Re-verify quarterly per [validation/governance/freshness-cadence.md](validation/governance/freshness-cadence.md).

## License and authorship

This pack is released as a reusable artifact. Bring it into your own project as a snapshot; treat the patterns and skills as a starting point to be adapted, not a framework to depend on.

## What's next

The pack is feature-complete for its scope. The forward path lives in [ROADMAP.md](ROADMAP.md): annual review of skill content, quarterly ecosystem-facts refresh, and per-release runs of the validation pack and demo as governance.
