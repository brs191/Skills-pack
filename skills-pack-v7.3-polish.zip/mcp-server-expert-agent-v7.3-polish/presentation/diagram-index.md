# Diagram Index

## Mermaid

- `diagram-prompts/mermaid/ecommerce-container-view.mmd`
- `demo/architecture-review-demo/out/ecommerce-diagram-output.mmd`
- `testdata/golden/ecommerce-diagram-output.mmd`

## PlantUML

- `diagram-prompts/plantuml/order-saga-sequence.puml`

## draw.io Prompts

- `diagram-prompts/drawio-prompts/ecommerce-order-platform-drawio.md`

## Recommended Usage

- Use Mermaid for fast documentation and GitHub rendering.
- Use PlantUML for sequence and interaction flows.
- Use draw.io prompts for polished architecture-board diagrams.
