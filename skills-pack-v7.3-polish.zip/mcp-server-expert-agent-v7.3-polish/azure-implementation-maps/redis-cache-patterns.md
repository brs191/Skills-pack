# Azure Implementation Map — Redis Cache Patterns

## Purpose
Azure Cache for Redis supports cache-aside, session caching, hot read models, and rate-limit stores.

## Use When
- The architectural concern is present in the system.
- Azure-native implementation reduces operational burden.
- Security, reliability, cost, and observability are explicitly addressed.

## Implementation Checklist
- [ ] Identity model defined
- [ ] Network boundary defined
- [ ] Data ownership clear
- [ ] Failure handling defined
- [ ] Observability enabled
- [ ] Cost and scaling model defined
- [ ] CI/CD and rollback defined

## MCP Review Guidance
Use this map when generating Azure service recommendations, ADRs, risk reviews, and deployment topology.
