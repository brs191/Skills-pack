# Skill — Microservices Observability Patterns

## Purpose
Design observability for distributed microservices on Azure.

## Required Signals
- Logs
- Metrics
- Traces
- Audit events
- Dependency telemetry
- Business KPIs

## Required Correlation
Every request/event should carry:
- trace_id
- span_id
- correlation_id
- tenant_id where applicable
- user/session when allowed

## Azure Mapping
| Need | Azure Service |
|---|---|
| Logs | Log Analytics |
| App telemetry | Application Insights |
| Metrics | Azure Monitor Metrics |
| Tracing | OpenTelemetry + App Insights |
| Dashboards | Azure Monitor Workbooks / Grafana |
| Alerts | Azure Monitor Alerts |

## Review Checklist
- Are service-to-service calls traced?
- Are queue processing spans connected to request traces?
- Are domain events auditable?
- Are SLOs defined?
- Are dashboards role-specific?
