# Skill — Microservices System Design Router

## Purpose

Route system design requests to the appropriate microservices skill based on the problem stage and domain. This router encodes the reasoning sequence that moves from business capability to deployed architecture. Use it when the request is about system design, distributed systems, Azure-hosted microservices, service boundaries, patterns, resilience, observability, security, or architecture review.

## The Design Sequence

System design is a directed workflow. Following this sequence prevents the most common failure mode — jumping to technology choices before the business problem is clear. Skipping steps couples architecture to wrong assumptions and forces rework.

**The required reasoning sequence:**

1. **Define business capabilities** — What is the user trying to accomplish? What business capability must be decomposed? Start here, not with "let's use microservices."

2. **Domain decomposition and bounded contexts** — Map the business domain to service-shaped boundaries using DDD principles. Identify what belongs together and what must be separate. (Skill: `03-domain-decomposition.md`)

3. **Define service boundaries and data ownership** — For each proposed service, establish what data it owns, what it must share, and what remains shared-domain state. (Skill: `04-service-boundaries.md`)

4. **Choose communication patterns** — Now that workflow shape is clear, decide synchronous vs. async, event-driven vs. request-reply. (Skill: `07-async-messaging.md`)

5. **Add data architecture** — CQRS, saga, outbox, event sourcing — only add these after communication patterns are chosen. (Skill: `05-data-architecture.md`)

6. **Design resilience** — Circuit breakers, retries, bulkheads, DLQ — these prevent cascading failure once service count grows. (Skill: `06-resilience-patterns.md`)

7. **Design API contracts** — REST, gRPC, versioning, gateway — codify the service boundary once the service shape is stable. (Skill: `08-api-design.md`)

8. **Map to Azure services** — Now identify the Azure host for each service and its data. (Skill: `09-azure-mapping.md`)

9. **Design observability** — Distributed tracing, metrics, logs — instrument for the failure modes you chose in step 6. (Skill: `10-observability-design.md`)

10. **Design security and compliance** — Zero trust, managed identity, network segmentation, audit trails — apply last, after the service shape is known. (Skill: `11-security-design.md`)

11. **Analyze cost and trade-offs** — Understand the total-cost-of-ownership and non-functional trade-offs baked into the design. (Skill: `12-cost-and-tradeoffs.md`)

## Critical decision rule

**Never recommend microservices blindly.** A monolith, modular monolith, or small set of services may be architecturally superior to ten services if:
- Team size is <20 engineers (coordination overhead outweighs isolation)
- The business domain is not yet decomposed (you'll refactor the service boundaries multiple times)
- Deployment frequency and cycle time are not organizational constraints (monolith deploys fast)
- Strong consistency is required across all business operations (microservices introduce distributed transaction complexity)

The decision to decompose is a business decision, not a technology one. Encode the reasoning in an ADR.

## When to use this router

**Use the microservices path when:**
- The request explicitly mentions system design, distributed systems, Azure architecture, or service-oriented design
- The user is asking "how should I decompose this domain?" or "what patterns fit this workflow?"
- The request is an architecture review of an existing microservices system
- The user is designing for specific operational constraints (deployment frequency, team autonomy, geographic distribution)

**Use a different path when:**
- The request is about a single service (not system design) — use domain skills (Azure DevOps, observability, etc.)
- The request is about pattern implementation details (use the pattern card, not the skill)
- The request is about code structure or testing — use MCP skill `06-mcp-go-project-structure.md` and related

## Pattern selection fast path

If the user already knows the architectural shape and is asking "which patterns fit," use this decision table:

| Situation | Patterns to consider | Skill |
|---|---|---|
| Read and write workloads differ significantly | CQRS, read models, caching | `05-data-architecture.md` |
| Cross-service business transactions | Saga, transactional outbox | `05-data-architecture.md`, `07-async-messaging.md` |
| Unpredictable load spikes | Autoscaling, queue-based load leveling, bulkhead | `06-resilience-patterns.md` |
| Service-to-service calls can fail | Circuit breaker, timeout, retry with jitter | `06-resilience-patterns.md` |
| Events must be emitted reliably | Transactional outbox, event sourcing | `05-data-architecture.md` |
| Services must discover each other | Service discovery, service mesh | `08-api-design.md` |
| Need to roll out changes safely | Blue-green, canary, strangler-fig | `06-resilience-patterns.md` |
| Cross-tenant data isolation is required | Database per tenant, multi-tenant schema | `04-service-boundaries.md` |

## What to read next

- For the first detailed step (domain decomposition): `03-domain-decomposition.md`
- For full reasoning and decision criteria on all 11 steps: read the skills in the sequence listed above
- For pattern definitions and Azure mappings: `patterns/microservices/` (21 pattern cards)
- For the MCP tools that automate design: `skills/mcp/01-mcp-go-server-basics.md` (tool contract approach)
