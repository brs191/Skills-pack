---
skill: skills/mcp/03-mcp-go-resources.md
exercises_section: Resource vs. tool distinction; URI design
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go resources

## Prompt

I want to expose "the current Azure cost breakdown by service for the last month" to my agent. Should this be an MCP resource or an MCP tool? Justify, then sketch the design.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Calls out the read-vs-action axis** — frames the choice on whether this is read-only context or an action with side effects
- [ ] **Resource if generated periodically and reused** — recommends a resource (e.g., `report://cost/monthly/2026-04`) when the data is a slow-changing snapshot
- [ ] **Tool if parameterised per call** — names that if the agent needs to specify a date range or filter per call, that's a tool, not a resource
- [ ] **URI design is namespaced and human-readable** — example URI looks like `cost://reports/monthly/{period}` rather than opaque IDs or filesystem paths
- [ ] **Caching / refresh strategy declared** — names that the resource has a refresh strategy (e.g., scheduled, daily) rather than caching forever
- [ ] **Security: no raw cost-share secrets** — flags that the resource must not expose credentials, account IDs, or unredacted billing PII

## Reference output

> **It's a resource if the agent reads the latest monthly snapshot; it's a tool if the agent specifies the period or filters per call.** The decision turns on whether the data is reused across sessions (resource) or generated for each request (tool).
>
> Assuming the typical case — a periodic cost report the agent reads to reason about spend — model it as a resource:
>
> **URI template:** `cost://reports/monthly/{period}` where `{period}` is `YYYY-MM`. Specific URI: `cost://reports/monthly/2026-04`.
>
> **Contract:**
> - Purpose: monthly cost breakdown by Azure service for the named period.
> - Data source: Azure Cost Management API, snapshotted nightly into a blob.
> - MIME type: `application/json`.
> - Refresh: scheduled, nightly. Today's data lags by ~24 hours.
> - Access control: authenticated callers only; the resource is gated on the calling identity's read-cost-data permission.
> - Security: redact subscription IDs and account names; expose service names and totals, not per-account splits.
>
> If the agent's usage pattern is "give me cost between these two dates filtered by these resource groups", switch to a tool (`generate_cost_report`) — the parameters are caller-specific, and an audit log per call is more appropriate than a cacheable resource.

## Notes

Catches the most common resource-design mistake: making a parameterised report a resource. The "per-call parameters = tool" rule is the test.
