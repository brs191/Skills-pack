# Skill — MCP-Go CI/CD and Quality Gates

## Purpose

Create CI/CD quality gates for mcp-go server repositories.

## Use When

The user asks for:

- GitHub Actions
- CI pipeline
- Quality gates
- Build and test automation
- Production readiness automation

## Required quality gates

```text
go fmt check
  ↓
go vet
  ↓
go test ./...
  ↓
go test -race ./...
  ↓
Docker build
  ↓
Security review checklist
  ↓
Contract review for changed tools
```

## Pull request rule

Any pull request that changes MCP tool contracts must update:

- `docs/tools.md`
- `contracts/*.json`
- tests
- risk classification
- approval rules if required

## Release rule

Every release must include:

- version tag
- changelog
- changed tool list
- compatibility notes
- security impact note
