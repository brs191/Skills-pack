# Skills Index

Skills are grouped by operating mode to reduce routing noise.

## Top-level router

- `00-skill-router.md` — master router across all capability areas.

## MCP implementation skills

Use `skills/mcp/` for Go/mcp-go server design, tool design, resources, prompts, transports, security, testing, deployment, CI/CD, client integration, production reviews, and code generation.

## Domain MCP starter skills

Use `skills/domain/` for Azure FinOps, DevOps, Observability/Grafana, Network Reviewer, and domain skeleton generation.

## Microservices system design skills

Use `skills/microservices/` for service boundaries, cloud-native Azure patterns, data consistency, communication, resilience, security, observability, deployment, review, and architecture generation.

## Architecture accelerator skills

Use `skills/accelerator/` for case-study generation, diagram output, Well-Architected scoring, architecture tool execution, one-command demo workflow, golden validation, architecture-board packs, adoption guidance, executive-to-engineering translation, and acceptance gates.
