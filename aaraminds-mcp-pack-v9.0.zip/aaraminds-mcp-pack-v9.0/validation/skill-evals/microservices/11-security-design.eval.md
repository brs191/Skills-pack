---
skill: skills/microservices/11-security-design.md
exercises_section: Defense-in-depth layers
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: security design

## Prompt

Name the six layers of defense-in-depth you would apply to a typical Azure microservices system, and for each, name the Azure-native mechanism that implements it. The goal is to fail an attacker at multiple layers, not at one.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Ingress authentication** — user-facing OAuth/OIDC via Azure AD or B2C; tokens validated at the gateway
- [ ] **Authorization (fine-grained)** — RBAC or ABAC enforced per endpoint; not just "is the user logged in"
- [ ] **Service-to-service authn** — Managed Identity per service; no shared API keys; mTLS via mesh (Dapr / Istio) where applicable
- [ ] **Data access / row-level controls** — encryption at rest (TDE / Customer-Managed Keys), row-level security for multi-tenant or sensitive data
- [ ] **Encryption in transit** — TLS everywhere, mTLS internally; secrets in Key Vault, never in env vars or config maps
- [ ] **Audit logging** — every state-changing or sensitive-read action logged with identity, resource, decision, retention sufficient for the regulatory regime

## Reference output

> Six layers. The key property: each layer is meaningful on its own, and an attacker has to bypass all of them to win.
>
> **1. Ingress authentication.** Azure AD or B2C for user-facing OAuth/OIDC. The API Management gateway or Application Gateway terminates and validates the access token against the IDP's JWKs. Unauthenticated requests die here.
>
> **2. Authorization (fine-grained).** Even an authenticated user can only do what their role and attributes permit. RBAC for simple "manager can approve" rules; ABAC for "user can read records in their department" rules. Enforced per endpoint, not just per service. The most common failure here is "user logged in → can access anything" — that's authentication without authorization.
>
> **3. Service-to-service authentication.** Each service has its own Azure Managed Identity in Azure AD. Service A authenticates to Service B with its identity token, not a shared API key. mTLS via Dapr or Istio sidecars adds transport-level identity in addition to application-level. No shared credentials anywhere; rotation is automatic.
>
> **4. Data access control.** Inside the service, before reading or writing, check that the requester is allowed. Row-level security in SQL Server / PostgreSQL for multi-tenant data ("user can only see rows where tenant_id = their tenant"). Field-level encryption for the most sensitive columns. Encryption at rest with Customer-Managed Keys (Key Vault-managed) so even a stolen backup is unreadable without the key.
>
> **5. Encryption in transit + secrets management.** TLS 1.2+ for every external API; mTLS via service mesh for internal traffic. Secrets in Azure Key Vault, mounted via the CSI driver or fetched at runtime via the service's Managed Identity. Nothing in config maps, env vars, or source. Rotation happens in Key Vault; pods pick up new values without redeploy.
>
> **6. Audit logging.** Every state-changing action (create, update, delete) and every sensitive-data read logs `{timestamp, identity, action, resource, decision, ip}`. Pipe to Log Analytics with retention set to the regulatory regime (HIPAA: ≥7 years; PCI: typically 1 year; SOX: 7 years). Immutable archive for the long tail. Audit is separate from operational logs; on-call doesn't need to see audit, and audit can't be tampered by on-call.
>
> **Why the layering matters**
>
> If the gateway is misconfigured and lets through a request without a valid token, layer 2 still blocks it because the request has no claims. If an attacker compromises a service's identity, layer 3 limits which downstream services it can call (allow-list per identity), and layer 4 limits which data those services expose. Layer 6 ensures the attacker leaves a trail. Defense-in-depth turns a single failure from catastrophic into containable.

## Notes

Catches the "we use TLS" answer where security is reduced to one layer. The six-layer framing is in the skill.
