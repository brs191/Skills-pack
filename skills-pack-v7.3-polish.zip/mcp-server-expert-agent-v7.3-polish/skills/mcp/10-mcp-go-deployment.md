# Skill — MCP-Go Deployment

## Purpose

Deploy mcp-go servers locally, in Docker, Kubernetes, and Azure.

## Local Deployment

```bash
go run ./cmd/server
```

## Dockerfile

```dockerfile
FROM golang:1.23-alpine AS builder
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN go build -o /out/mcp-server ./cmd/server

FROM alpine:3.20
RUN adduser -D -H appuser
USER appuser
COPY --from=builder /out/mcp-server /usr/local/bin/mcp-server
ENV MCP_TRANSPORT=streamablehttp
ENV PORT=8080
EXPOSE 8080
ENTRYPOINT ["/usr/local/bin/mcp-server"]
```

## Azure Deployment Options

| Option | Best For |
|---|---|
| Azure Container Apps | Fast managed deployment |
| AKS | Enterprise scale, advanced networking |
| App Service | Simple HTTP deployment |
| VM | Legacy or custom runtime needs |

## Production Requirements

Health endpoint, readiness probe, liveness probe, auth middleware, secret management, OpenTelemetry, structured logs, rate limits, resource limits, horizontal scaling, safe shutdown, versioned releases.
