package observability

import (
	"context"
	"encoding/json"

	"github.com/example/observability-mcp-server/internal/audit"
	"github.com/example/observability-mcp-server/internal/policy"
	observabilitysvc "github.com/example/observability-mcp-server/internal/services/observability"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerSummarizeIncident(s *server.MCPServer, svc *observabilitysvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	tool := mcp.NewTool("summarize_incident",
		mcp.WithDescription("Execute read-only summarize_incident capability"),
		mcp.WithString("tenant_id", mcp.Description("Tenant ID; defaults to tenant-example")),
	)
	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		tenantID := req.GetString("tenant_id", "tenant-example")
		decision := policyEngine.Authorize(policy.Request{Tool: "summarize_incident", TenantID: tenantID, Risk: policy.RiskLow})
		if !decision.Allowed {
			return mcp.NewToolResultError(decision.Reason), nil
		}
		out, err := svc.Execute(ctx, "summarize_incident")
		if err != nil {
			return mcp.NewToolResultError(err.Error()), nil
		}
		auditor.Record(ctx, audit.Event{Tool: "summarize_incident", Status: "success", Risk: "low", TenantID: tenantID})
		b, _ := json.MarshalIndent(out, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})
}
