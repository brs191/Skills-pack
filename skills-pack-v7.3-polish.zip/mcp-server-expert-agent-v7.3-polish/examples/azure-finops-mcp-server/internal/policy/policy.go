package policy

const (
	RiskLow      = "low"
	RiskMedium   = "medium"
	RiskHigh     = "high"
	RiskCritical = "critical"
)

type Request struct {
	Tool           string
	SubscriptionID string
	Risk           string
}

type Decision struct {
	Allowed bool
	Reason  string
}

type Engine struct{}

func NewEngine() *Engine { return &Engine{} }

func (e *Engine) Authorize(req Request) Decision {
	if req.SubscriptionID == "" {
		return Decision{Allowed: false, Reason: "subscription_id is required for policy evaluation"}
	}
	if req.Risk == RiskHigh || req.Risk == RiskCritical {
		return Decision{Allowed: false, Reason: "high-risk tools require explicit approval workflow"}
	}
	return Decision{Allowed: true, Reason: "allowed"}
}
