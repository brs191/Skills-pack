# Resilience Model

## Patterns Used

| Concern | Pattern |
|---|---|
| Cross-service order workflow | Saga |
| Reliable event publishing | Transactional Outbox |
| Duplicate event handling | Idempotent Consumer |
| External PSP instability | Circuit Breaker + Retry with Timeout |
| High checkout traffic | Bulkhead + Autoscaling |
| Message failures | Dead Letter Queue |
| Cache pressure | Cache Aside with graceful fallback |

## Critical Failure Handling

- Payment succeeds but inventory fails → issue compensation/refund.
- Inventory reserved but payment fails → release reservation.
- Notification fails → retry async, do not fail order.
- Shipping provider unavailable → mark order as awaiting shipment and retry.
