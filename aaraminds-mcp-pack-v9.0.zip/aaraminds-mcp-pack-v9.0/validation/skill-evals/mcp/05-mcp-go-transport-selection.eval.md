---
skill: skills/mcp/05-mcp-go-transport-selection.md
exercises_section: Transport choice matrix and operational implications
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go transport selection

## Prompt

We have an MCP server that today runs locally via stdio for our team's Claude Code sessions. Product wants to expose it as a hosted service for external customers. What transport do you pick, what new operational concerns appear, and what stays the same?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Streamable HTTP for the new shape** — picks streamable HTTP, not SSE; explains SSE is deprecated
- [ ] **TLS becomes mandatory** — names that the HTTP transport over the public internet requires TLS
- [ ] **Authentication is new and required** — anonymous MCP over the network is a security hole; OAuth/JWT or equivalent
- [ ] **Rate limiting + multi-tenancy** — per-customer quotas, fairness, abuse protection
- [ ] **Service-layer code is unchanged** — names that the transport switch shouldn't require touching the rule logic or tool implementations
- [ ] **Health and observability shift** — HTTP-layer health endpoint (`/healthz`), per-request latency metrics, possibly distributed tracing across HTTP boundaries

## Reference output

> **Transport: streamable HTTP.** Not SSE (deprecated in the current spec); not stdio (you can't serve external customers by spawning the server per-session over the internet).
>
> **New operational concerns**
>
> 1. **TLS, mandatory.** All traffic over the public internet must be TLS 1.2+. Terminate at Azure Front Door, Container Apps ingress, or Application Gateway. App-level TLS termination is acceptable if the deployment topology requires it.
> 2. **Authentication, mandatory.** Anonymous MCP over the network lets anyone invoke your tools and consume your resources. Implement OAuth/JWT middleware that validates tokens before they reach the MCP handler. Customers get per-tenant credentials.
> 3. **Authorisation per tool.** Different customers may have different tool entitlements. A tool-call-time authorisation check based on the authenticated identity is the simplest model; richer ABAC if needed.
> 4. **Rate limiting.** Per-tenant quotas (calls per minute, calls per day). Without this, one noisy customer can degrade everyone else and you have no story for abuse.
> 5. **Multi-tenancy concerns.** If tool calls touch shared state, isolate per-tenant. If tools cache, key by tenant. Data leakage across tenants is a service-killing incident.
> 6. **Health endpoint.** `/healthz` for liveness/readiness probes; don't conflate with MCP. The HTTP layer is its own concern.
> 7. **Observability.** HTTP-level metrics (status code, latency, request rate) plus MCP-level metrics (tool call count, error rate, per-tenant usage). Distributed tracing across the HTTP boundary; the trace ID should propagate from caller into tool invocations and outbound calls.
> 8. **Deployment shape.** Blue-green or canary on Container Apps (revisions), App Service slots, or Kubernetes Deployments. The MCP server is now a long-running service, not a subprocess.
>
> **What stays the same**
>
> The service layer (`internal/services/<tool>/`) and tool registration (`internal/tools/<tool>/register.go`) don't change. The transport is a `main.go` choice; everything below `main.go` is transport-agnostic by design. If your codebase couples service code to stdio (e.g., reading from `os.Stdin`, writing structured logs to stdout), that's a layering bug to fix first.
>
> The contracts (under `contracts/architecture-tools/implemented/`) don't change. The tools, their inputs and outputs, their semantics — all identical across transports. The only thing that changes is who talks to the server and how.
>
> **Order of work**
>
> 1. Add `MCP_TRANSPORT` env var; branch in `main.go`. Default still stdio for local dev.
> 2. Add auth middleware and rate-limiting middleware.
> 3. Add health endpoint.
> 4. Add HTTP-layer metrics and tracing.
> 5. Deploy to a staging environment behind TLS; test from an external client.
> 6. Migrate customers in waves.
>
> The migration is mostly operational, not architectural — because the underlying code respects the transport boundary.

## Notes

Catches LLMs that recommend SSE (deprecated) or that propose rewriting service code. The "service layer is transport-agnostic" point is the value-add.
