# MVP to Production Roadmap

## Phase 1 — Modularization

- Identify order, inventory, payment, shipping, catalog boundaries.
- Create ADRs.
- Define API and event contracts.

## Phase 2 — Read-only Extraction

- Extract Catalog and Order Query APIs.
- Add API Management.
- Add OpenTelemetry.

## Phase 3 — Order Workflow MVP

- Implement Order Service.
- Add Service Bus events.
- Add Transactional Outbox.
- Add Inventory and Payment mocks.

## Phase 4 — Production Hardening

- Add retry, circuit breaker, DLQ monitoring.
- Add security review.
- Add canary deployments.
- Add load testing.

## Phase 5 — Platform Scaling

- Add multi-region read models if needed.
- Add advanced autoscaling.
- Add architecture review MCP tools into SDLC.
