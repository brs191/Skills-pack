# Skill — MCP-Go Tool Design

## Purpose

Design safe, useful, agent-ready MCP tools using mark3labs/mcp-go.

## Principle

An MCP tool should expose an intent-safe capability, not a raw backend API.

## Good Tool Names

- `get_cost_summary`
- `detect_cost_anomalies`
- `query_logs`
- `review_network_topology`
- `summarize_failed_pipeline`
- `create_incident_ticket`

## Poor Tool Names

- `call_api`
- `run_command`
- `execute_query`
- `do_action`

## Tool Template

```markdown
## Tool Name
`tool_name`

## Purpose
One clear sentence.

## Input Schema
Fields, types, required/optional, allowed values.

## Output Schema
Expected response.

## Permissions Required
Read-only / write / admin / tenant-scoped.

## Risk Level
Low / Medium / High / Critical.

## Human Approval
Required / Not required / Conditional.

## Failure Modes
Expected errors and fallbacks.

## Observability
Log event name, metrics, trace fields.
```

## mcp-go Tool Pattern

```go
tool := mcp.NewTool("get_cost_summary",
	mcp.WithDescription("Get Azure cost summary for a subscription and date range"),
	mcp.WithString("subscription_id", mcp.Required(), mcp.Description("Azure subscription ID")),
	mcp.WithString("from_date", mcp.Required(), mcp.Description("Start date in YYYY-MM-DD format")),
	mcp.WithString("to_date", mcp.Required(), mcp.Description("End date in YYYY-MM-DD format")),
)

s.AddTool(tool, handleGetCostSummary)
```

## Safety Checklist

- Intent-based tool name
- Strong input validation
- Bounded output
- No secret leakage
- Tenant context enforced
- Scoped backend permissions
- Human approval for high-risk actions
- Audit record
