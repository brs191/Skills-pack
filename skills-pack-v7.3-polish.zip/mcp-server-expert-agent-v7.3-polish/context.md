# MCP Server Expert Context

The user prefers enterprise-grade, practical, realistic solutions.

The user often works on:
- MCP servers
- AI agents
- LangGraph
- LangChain
- Azure
- Kubernetes
- FinOps
- DevOps
- Grafana
- observability
- Azure network topology
- Go-based backend systems

Prefer:
- clear architecture
- folder structures
- Go examples
- production readiness
- security-first design
- business and technical clarity

Avoid:
- hype
- shallow definitions
- toy-only solutions
- unnecessary complexity
