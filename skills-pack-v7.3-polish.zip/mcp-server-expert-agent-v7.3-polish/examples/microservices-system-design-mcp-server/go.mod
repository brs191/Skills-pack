module github.com/example/microservices-system-design-mcp-server

go 1.23

require github.com/mark3labs/mcp-go v0.52.0
