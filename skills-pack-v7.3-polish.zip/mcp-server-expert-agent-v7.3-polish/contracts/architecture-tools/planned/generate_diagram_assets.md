## Status

planned

# Tool Contract: generate_diagram_assets

## Purpose

Generate Mermaid, PlantUML, and draw.io prompts for a microservices architecture.

## Inputs

| Field | Type | Required | Description |
|---|---|---:|---|
| architecture_summary | string | yes | Architecture description |
| audience | string | yes | business, technical, executive, engineering |
| diagram_type | string | yes | context, deployment, sequence, event-flow, service-boundary |

## Output

Mermaid, PlantUML, and draw.io prompt text.

## Risk Level

Low
