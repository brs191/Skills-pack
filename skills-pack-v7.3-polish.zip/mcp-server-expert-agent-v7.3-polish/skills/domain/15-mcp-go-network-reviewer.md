# Skill — Azure Network Reviewer MCP Server Using mcp-go

## Purpose

Design MCP tools for Azure network topology review.

## MCP Tools

```text
get_network_topology
review_network_topology
detect_nsg_risks
analyze_route_tables
review_firewall_policy
estimate_network_cost_impact
recommend_network_improvements
```

## MCP Resources

```text
network://topology/{subscription_id}
network://nsg/{subscription_id}/{resource_group}
network://routes/{subscription_id}/{resource_group}
network://firewall-policy/{policy_id}
```

## Risk Classification

| Tool | Risk | Approval |
|---|---|---|
| get_network_topology | Low | No |
| detect_nsg_risks | Low | No |
| estimate_network_cost_impact | Low | No |
| recommend_network_improvements | Medium | No |
| update_nsg_rule | Critical | Mandatory |
| update_route_table | Critical | Mandatory |

## MVP Scope

Read-only review: fetch topology, detect risks, estimate cost impact, recommend changes. Do not implement network modification tools in MVP.
