# Skill — MCP-Go Reference Implementation Builder

## Purpose
Generate a complete repo-ready MCP server skeleton using `mark3labs/mcp-go`.

## Use When
The user asks to create a repository, scaffold, runnable server, or MVP implementation.

## Required Output

Always generate:

1. `cmd/server/main.go`
2. `internal/mcpserver/server.go`
3. tool registration files
4. service interface
5. connector interface
6. policy layer stub
7. audit logger stub
8. telemetry stub
9. Dockerfile
10. Makefile
11. Kubernetes manifest
12. README
13. contracts for every MCP tool

## Default Architecture

```text
MCP Client
  ↓
Transport: stdio / Streamable HTTP / SSE
  ↓
mcp-go server
  ↓
Tool handler
  ↓
Policy check
  ↓
Service layer
  ↓
Connector layer
  ↓
Enterprise API
  ↓
Structured result + audit + telemetry
```

## Code Rules

- Keep compile-oriented code.
- Use interfaces for services and connectors.
- Keep mock implementations in the example skeleton when real cloud SDK calls are not included.
- Prefer read-only tools first.
- Add comments where real Azure SDK integration should be added.
