---
skill: skills/mcp/19-mcp-go-reference-implementation.md
exercises_section: Walking the reference; what it demonstrates
pass_threshold: 3/5
last_run: never
last_result: never run
---

# Eval: MCP Go reference implementation

## Prompt

I want to add a new tool to my MCP server. Walk me through how the reference implementation guides me from `main.go` to a working tool call.

## Rubric

A response passes if it covers at least 3 of the following 5 points:

- [ ] **Service package first** — recommends starting with the service package (`internal/services/<name>/service.go`) with Input/Output structs, Validate, and the rule logic
- [ ] **Table-driven tests next** — proposes writing service tests before wiring MCP, since the service is unit-testable in isolation
- [ ] **Thin registration** — recommends `register.go` stays under ~30 lines: parse-validate-call-format, no business logic
- [ ] **One line in the composition root** — adding the tool means one new `Register(s, svc, logger)` call in `internal/mcpserver/server.go`
- [ ] **Contract file separately** — the JSON contract for the tool lives in `contracts/architecture-tools/implemented/`, not inline in code

## Reference output

> The reference implementation is structured so that adding a tool is a five-step recipe:
>
> **1. Service package.** Create `internal/services/<name>/service.go`. Declare `Input` and `Output` structs and a `Service` type with a constructor `NewService(logger)`. Implement `Validate(input) error` and the main entry point (e.g., `Generate(input) (*Output, error)`). The package depends on the standard library and your business needs — no MCP imports.
>
> **2. Tests for the service.** Write `internal/services/<name>/service_test.go` as a table-driven test. One positive case for each rule plus negative cases for validation failures. The service is now testable in isolation; `go test ./internal/services/<name>` runs in milliseconds.
>
> **3. MCP registration.** Create `internal/tools/<name>/register.go` and copy the existing `boundary` or `archrisks` registration. Replace the tool name, description, and the service call. The handler is parse `input_json` → unmarshal into `Input` → call `service.Generate` → marshal result → return. Twenty-five lines.
>
> **4. Wire into the composition root.** Add one line to `internal/mcpserver/server.go`:
> ```go
> <name>tool.Register(s, <name>svc.NewService(logger), logger)
> ```
> The MCP server now exposes the new tool.
>
> **5. Contract.** Write `contracts/architecture-tools/implemented/<name>.md`. Schema for input, semantics, examples, error responses. The contract is the human-facing specification that clients and tests reference.
>
> **Optional but recommended**
> - Add testdata fixtures (`testdata/<name>-input-*.json`, `testdata/<name>-output-*.json`) for goldens that exercise the tool end-to-end.
> - Add the tool to the demo runner if it makes sense to drive it across architectures.
>
> The reference's load-bearing property is the layer separation: the service is unit-testable without MCP, the registration is replaceable without touching business logic, the contract is reviewable as a document. Follow the layout; you get all three.

## Notes

Catches LLMs that jump to MCP code first instead of starting from the testable service layer.
