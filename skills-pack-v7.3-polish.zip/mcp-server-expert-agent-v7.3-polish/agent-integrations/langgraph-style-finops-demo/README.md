# LangGraph-Style FinOps Agent Demo

This demo shows the intended orchestration pattern for consuming the Azure FinOps MCP server.

It is written as a lightweight Python example so the flow is easy to understand. In a real implementation, replace the `MockMCPClient` with a real MCP client transport.

## Flow

```text
User question
  ↓
classify_intent
  ↓
get_cost_summary
  ↓
detect_cost_anomalies
  ↓
find_idle_resources
  ↓
generate_answer
  ↓
approval_required?
```

## Run

```bash
python app.py
```

## Safety model

The demo performs read-only investigation. It never executes cost-changing actions.
