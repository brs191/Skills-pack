---
skill: skills/mcp/18-mcp-go-anti-patterns.md
exercises_section: Named anti-patterns with detection signals
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go anti-patterns

## Prompt

Name four anti-patterns specific to building MCP servers in Go, and for each, give a one-sentence detection signal — how would a code reviewer spot it?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Kitchen-sink tool** — one tool doing many unrelated things; signal: input `action` argument switches on a string
- [ ] **Untyped input via `map[string]any`** — handler receives a polymorphic map and dispatches; signal: large switch/case on field presence in the handler
- [ ] **Business logic in `register.go`** — the tool registration file contains rule logic; signal: register.go grows past ~50 lines or has its own helpers
- [ ] **Logging to stdout on stdio transport** — corrupts the MCP wire; signal: any `fmt.Print`, `log.Print`, or stdout-bound logger in code; tests fail mysteriously, server hangs on init
- [ ] **Silently swallowed errors** — `_, _ := svc.Do(...)`; signal: any `_` capturing an `error` return; no `if err != nil` block
- [ ] **Global state / package-globals** — package-level `var logger`, `var db`, `var client`; signal: any non-const package-level mutable variable; tests can't isolate
- [ ] **No risk tier on state-changing tools** — destructive tools have the same audit/logging as read-only ones; signal: identical log shape across reads and writes; no dry-run support
- [ ] **Output trusted as instructions** — agent code uses tool output without treating it as data; signal: tool output flowing back into prompts without sanitization or framing

## Reference output

> Four MCP-server anti-patterns with code-review signals:
>
> **1. Kitchen-sink tool.** One tool that does several unrelated operations dispatched by an action argument.
> *Signal:* The tool's input schema has a `type` or `action` field that switches behavior. The handler has a large switch/case in the first 20 lines. Different `action` values need different fields, but the schema can't express that.
> *Fix:* Split into one tool per intent.
>
> **2. Untyped input via `map[string]any`.** The handler receives a polymorphic map and reaches into it field by field.
> *Signal:* The handler doesn't declare an input struct; it does `args["customer_id"].(string)`. Validation lives in the handler in a long sequence of conditionals.
> *Fix:* Define `Input` and `Output` structs in the service package; unmarshal into them; let Go's type system enforce the contract.
>
> **3. Business logic in `register.go`.** Rule code creeps into the MCP wiring.
> *Signal:* `register.go` grows past 50 lines. It has its own helper functions. The same logic in the service package looks redundant. The wiring "happens to also" do some computation.
> *Fix:* Move logic into `internal/services/<name>/service.go`. The handler stays thin: parse, validate, call service, format.
>
> **4. Logging to stdout on stdio transport.** Any write to stdout corrupts the MCP message wire.
> *Signal:* Any `fmt.Println`, `log.Print`, `os.Stdout`, or default logger initialization not pointing to stderr. The symptom in production: clients can't decode messages, the server appears unresponsive.
> *Fix:* `slog.New(slog.NewJSONHandler(os.Stderr, ...))`. Grep the codebase for `Println`, `Stdout`, and `log.Print` and remove all of them.
>
> **Two more worth knowing**
>
> **5. Silently swallowed errors.** `_, _ := svc.Do(...)` discards both the result and the error.
> *Signal:* Any `_` capturing an `error` return. Pull-request lint should flag this; code review must.
>
> **6. No risk-tier discipline.** Destructive tools (delete, deploy, migrate) have the same audit and logging as read-only tools.
> *Signal:* Identical log shape across reads and writes; no dry-run support on mutations; no separate audit emitter for state changes.

## Notes

Catches LLMs that describe anti-patterns abstractly without naming the code-review-visible signals. The signal-per-anti-pattern is the value-add of the skill.
