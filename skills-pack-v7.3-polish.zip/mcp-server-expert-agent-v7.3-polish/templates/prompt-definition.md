# MCP Prompt Contract Template

## Prompt Name
`<prompt_name>`

## Purpose
What reasoning workflow this prompt supports.

## Required Inputs
- `<input>`

## Optional Inputs
- `<input>`

## Prompt Template

```text
You are reviewing <domain>. Use only the supplied facts. Separate facts, assumptions, risks, and recommendations.
```

## Expected Output
1. Summary
2. Facts
3. Assumptions
4. Risks
5. Recommendations
6. Human review items

## Safety Rules
- Do not invent missing facts.
- Mark assumptions explicitly.
- Do not recommend destructive actions without approval.
