---
skill: skills/mcp/01-mcp-go-server-basics.md
exercises_section: Transport choice and server skeleton
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go server basics

## Prompt

Set up the minimal Go MCP server skeleton: which transport do you default to, where do you put logging output, what's the shutdown story, and what's the smallest correct `main.go`?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Stdio is the default transport** — names stdio as the right default for local / agent integration
- [ ] **HTTP for service contexts** — names streamable HTTP for remote / multi-client scenarios; warns that SSE is deprecated in the current spec
- [ ] **Stdout is the MCP wire** — calls out that logs must go to stderr, never stdout, on stdio transport
- [ ] **Structured logging via slog** — uses `log/slog` JSON handler, not `log.Print` or fmt
- [ ] **Bounded shutdown** — uses `signal.NotifyContext` (or equivalent) with SIGINT/SIGTERM so the process exits cleanly
- [ ] **Composition not customization** — `main.go` builds the server via dependency injection (`mcpserver.NewServer(logger)`), doesn't register tools inline

## Reference output

> **Default transport: stdio.** It's the MCP standard for local execution, the assumed transport for tool clients like Claude Code, and what every example in this pack uses. HTTP-based transports (streamable HTTP, formerly SSE) are for service contexts where the MCP server runs as a long-running service serving multiple clients. SSE specifically is deprecated in the 2025-11-25 spec; use streamable HTTP if you need an HTTP transport.
>
> **Stdout is the MCP wire — log to stderr.** Every byte you write to stdout becomes an MCP message frame. A stray `fmt.Println` corrupts the protocol; a `log.Print` that writes to stderr is fine. Configure `slog` with `os.Stderr` as the destination. This is the single most common new-server bug.
>
> **Use `log/slog`.** Structured JSON. `slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{Level: slog.LevelInfo})` is the baseline. Every log line is queryable; no printf strings; level set so production has Info+ unless debugging.
>
> **Bounded shutdown.** `signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)` gives a context that cancels on signal. The server's main loop respects the context; SIGTERM from the orchestrator (Container Apps, Kubernetes, systemd) results in a clean exit.
>
> **Minimal `main.go`**
>
> ```go
> package main
>
> import (
>     "context"
>     "log/slog"
>     "os"
>     "os/signal"
>     "syscall"
>
>     "example/internal/mcpserver"
>     "github.com/mark3labs/mcp-go/server"
> )
>
> func main() {
>     logger := slog.New(slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{Level: slog.LevelInfo}))
>     slog.SetDefault(logger)
>
>     s := mcpserver.NewServer(logger) // tools wired in there, not here
>
>     ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
>     defer cancel()
>
>     logger.Info("starting MCP server", slog.String("transport", "stdio"))
>     if err := server.ServeStdio(s); err != nil {
>         logger.Error("server failed", slog.String("error", err.Error()))
>         os.Exit(1)
>     }
>     <-ctx.Done()
> }
> ```
>
> Composition over customization: tool registration lives in `internal/mcpserver/server.go` and `internal/tools/*/register.go`. `main.go` doesn't grow.

## Notes

Catches the stdout-logging bug that's the #1 reason new servers don't work.
