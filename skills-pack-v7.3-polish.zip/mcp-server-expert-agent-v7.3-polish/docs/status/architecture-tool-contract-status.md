# Architecture Tool Contract Status

Architecture tool contracts are intentionally split into implemented and planned folders.

## Implemented contracts

| Contract | Location | Status | Notes |
|---|---|---|---|
| `review_microservice_design` | `contracts/architecture-tools/implemented/review_microservice_design.md` | Implemented starter | Supported by the system-design MCP server service path. |
| `recommend_microservice_patterns` | `contracts/architecture-tools/implemented/recommend_microservice_patterns.md` | Implemented starter | Pattern recommendation is available as starter logic. |
| `score_well_architected_readiness` | `contracts/architecture-tools/implemented/score_well_architected_readiness.md` | Implemented starter | Scoring service and demo/golden outputs are included. |

## Planned contracts

| Contract | Location | Intended purpose |
|---|---|---|
| `detect_architecture_risks` | `contracts/architecture-tools/planned/detect_architecture_risks.md` | Structured risk detection across service, data, security, resilience, and operations concerns. |
| `generate_architecture_decision_record` | `contracts/architecture-tools/planned/generate_architecture_decision_record.md` | ADR generation from architecture decisions and trade-offs. |
| `generate_service_boundary_canvas` | `contracts/architecture-tools/planned/generate_service_boundary_canvas.md` | Service boundary documentation. |
| `map_patterns_to_azure_services` | `contracts/architecture-tools/planned/map_patterns_to_azure_services.md` | Azure service mapping for selected design patterns. |
| `generate_api_contract` | `contracts/architecture-tools/planned/generate_api_contract.md` | API contract generation. |
| `generate_event_contract` | `contracts/architecture-tools/planned/generate_event_contract.md` | Event contract generation. |
| `generate_resilience_plan` | `contracts/architecture-tools/planned/generate_resilience_plan.md` | Reliability and failure-mode planning. |
| `generate_observability_plan` | `contracts/architecture-tools/planned/generate_observability_plan.md` | Logging, metrics, tracing, and dashboard planning. |
| `generate_deployment_topology` | `contracts/architecture-tools/planned/generate_deployment_topology.md` | Azure deployment topology generation. |
| `generate_diagram_assets` | `contracts/architecture-tools/planned/generate_diagram_assets.md` | Mermaid, PlantUML, or draw.io-ready assets. |

## Rule for agent responses

Do not present planned contracts as implemented tools. When using a planned contract, explicitly call it a design template or expansion backlog item.
