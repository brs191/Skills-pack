# Skill — Microservices System Design Review

## Purpose
Review system designs for service boundaries, Azure implementation fit, production readiness, and cloud risks.

## Review Output
1. Executive summary
2. Service boundary assessment
3. Data ownership assessment
4. Communication assessment
5. Pattern recommendations
6. Azure service mapping
7. Security risks
8. Resilience risks
9. Observability gaps
10. Deployment risks
11. Cost risks
12. ADRs required
13. Production-readiness score
14. Priority action plan

## Scoring Areas
- Service boundaries
- Data ownership
- Communication model
- Resilience
- Security
- Observability
- Deployment topology
- Scalability
- Cost awareness
- Operational simplicity
