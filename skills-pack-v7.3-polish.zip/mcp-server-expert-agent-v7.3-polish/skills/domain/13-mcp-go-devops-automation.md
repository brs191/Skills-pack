# Skill — DevOps Automation MCP Server Using mcp-go

## Purpose

Design DevOps automation MCP tools using mcp-go.

## MCP Tools

```text
get_pipeline_status
summarize_failed_build
analyze_deployment_failure
get_recent_deployments
create_release_notes
open_pull_request
create_work_item
trigger_pipeline_dry_run
```

## Risk Classification

| Tool | Risk | Approval |
|---|---|---|
| get_pipeline_status | Low | No |
| summarize_failed_build | Low | No |
| create_release_notes | Medium | Optional |
| open_pull_request | Medium | Yes for protected repos |
| trigger_pipeline | High | Yes |
| deploy_to_production | Critical | Mandatory |

## Safety Rules

Never allow direct arbitrary shell execution. Require approval for deployment and PR creation in protected repositories. Always log actor, repo, branch, and action.
