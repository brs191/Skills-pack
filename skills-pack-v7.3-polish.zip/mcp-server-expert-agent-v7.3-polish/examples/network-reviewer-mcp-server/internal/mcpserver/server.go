package mcpserver

import (
	"github.com/example/network-reviewer-mcp-server/internal/audit"
	"github.com/example/network-reviewer-mcp-server/internal/policy"
	networksvc "github.com/example/network-reviewer-mcp-server/internal/services/network"
	"github.com/example/network-reviewer-mcp-server/internal/tools/health"
	domaintools "github.com/example/network-reviewer-mcp-server/internal/tools/network"
	"github.com/mark3labs/mcp-go/server"
)

func NewServer() *server.MCPServer {
	s := server.NewMCPServer("network-reviewer-mcp-server", "1.0.0", server.WithToolCapabilities(true), server.WithRecovery())
	svc := networksvc.NewService(networksvc.NewMockClient())
	pol := policy.NewEngine()
	aud := audit.NewStdoutAuditor()
	health.Register(s)
	domaintools.Register(s, svc, pol, aud)
	return s
}
