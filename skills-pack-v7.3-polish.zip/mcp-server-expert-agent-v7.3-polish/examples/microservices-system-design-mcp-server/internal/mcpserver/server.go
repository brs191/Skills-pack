package mcpserver

import (
	"github.com/example/microservices-system-design-mcp-server/internal/services/design"
	designtools "github.com/example/microservices-system-design-mcp-server/internal/tools/design"
	"github.com/mark3labs/mcp-go/server"
)

func NewServer() *server.MCPServer {
	s := server.NewMCPServer("microservices-system-design-mcp-server", "1.0.0", server.WithToolCapabilities(true), server.WithRecovery())
	svc := design.NewService()
	designtools.Register(s, svc)
	return s
}
