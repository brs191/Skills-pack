package design

import "testing"

func TestReviewDetectsMissingBoundaries(t *testing.T) {
	s := NewService()
	res := s.Review(ReviewInput{SystemName: "orders"})
	if res.Score >= 75 {
		t.Fatalf("expected lower score when service boundaries are missing")
	}
	if len(res.Risks) == 0 {
		t.Fatalf("expected risks")
	}
}

func TestRecommendSagaForWorkflow(t *testing.T) {
	s := NewService()
	p := s.RecommendPatterns("order workflow transaction across services")
	found := false
	for _, v := range p {
		if v == "Saga" {
			found = true
		}
	}
	if !found {
		t.Fatalf("expected Saga recommendation")
	}
}

func TestScoreWellArchitected(t *testing.T) {
	s := NewService()
	res := s.ScoreWellArchitected()
	if res.OverallScore <= 0 {
		t.Fatalf("expected overall score")
	}
	if res.Rating == "" {
		t.Fatalf("expected rating")
	}
}
