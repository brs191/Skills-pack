# Skill — Azure Cloud-Native Microservices Patterns

## Purpose
Map microservices architecture decisions to Azure implementation options.

## Azure Target Selection
| Need | Prefer | Avoid When |
|---|---|---|
| Full Kubernetes control | AKS | Team lacks K8s operations maturity |
| Managed containers with less ops | Azure Container Apps | Complex service mesh/custom networking required |
| API governance | Azure API Management | Internal-only simple service call |
| Durable commands/queues | Azure Service Bus | High-volume telemetry streaming |
| Event notifications | Event Grid | Ordered command processing required |
| High-volume streams | Event Hubs | Business workflow orchestration needed |
| Service-owned NoSQL data | Cosmos DB | Strong relational constraints dominate |
| Cache aside/session/cache | Azure Cache for Redis | Source-of-truth storage required |
| Secrets and keys | Key Vault + Managed Identity | Never hardcode secrets |
| Observability | Azure Monitor + App Insights + OTel | Never depend only on app logs |

## Review Checklist
- Are services deployed independently?
- Are backing services private where possible?
- Is APIM used for external API contracts?
- Is Service Bus used for durable business commands?
- Are events versioned?
- Are identities workload-scoped?
- Is telemetry correlated across services?
