# ADR-002 — Use Saga Pattern for the Order Workflow

## Status

Accepted

## Context

The order workflow spans multiple services: Order, Inventory, Payment, Notification, and Fulfillment. Each service owns its own data. A single distributed database transaction across these services would create tight coupling, reduce autonomy, and increase operational fragility.

The system needs a controlled way to coordinate local transactions while supporting eventual consistency and compensating actions.

## Decision

Use the **Saga pattern** for the order workflow.

The initial implementation should favor choreography for simple event-driven coordination. If the workflow becomes complex, long-running, or difficult to observe, move orchestration into a dedicated workflow component.

## Options Considered

| Option | Pros | Cons |
|---|---|---|
| Distributed transaction / 2PC | Strong consistency | Not practical for cloud-native microservices, high coupling, operational complexity |
| Single order service owns all workflow logic | Simple early implementation | Service becomes too large and owns too many responsibilities |
| Choreographed saga | Loose coupling, natural event-driven model | Harder to reason about at scale without strong observability |
| Orchestrated saga | Clear workflow ownership and visibility | Adds workflow component and governance overhead |

## Decision Drivers

- Service autonomy
- Database-per-service ownership
- Eventual consistency acceptance
- Need for compensating actions
- Operational observability of order state
- Avoidance of distributed transactions

## Consequences

### Positive

- Services remain loosely coupled
- Each service performs local transactions only
- Failure handling can be modeled explicitly
- Order lifecycle is extensible

### Negative

- Eventual consistency must be explained to product/business stakeholders
- Duplicate events and retries must be handled safely
- Compensation logic must be implemented and tested
- Observability is mandatory to debug workflow state

## Failure Modes

- Inventory is reserved but payment fails
- Payment is authorized but order confirmation fails
- Duplicate event delivery triggers duplicate side effects
- Poison messages block processing
- Compensation events are missing or incomplete
- Order state becomes unclear to customer support

## Operational Impact

- Every event consumer must be idempotent.
- Dead-letter queues must be monitored.
- Correlation IDs must be propagated across the saga.
- A saga-state view or order timeline is required for operations.
- Compensation paths must be tested in lower environments.

## Cost Impact

The saga pattern increases messaging and observability cost. This is acceptable because it reduces coupling and avoids the operational cost of distributed transactions.

## Azure Services Involved

- Azure Service Bus
- Azure Container Apps or AKS
- Azure Cosmos DB or Azure SQL per service
- Azure Monitor / Application Insights
- Azure Key Vault

## MCP Tools / Resources Impacted

- `review_microservice_design`
- `recommend_microservice_patterns`
- `detect_architecture_risks` planned
- `generate_event_contract` planned
- `generate_resilience_plan` planned

## Review Date

Review when the order workflow adds new participating services, compensation paths, or business-critical SLA changes.
