# Service Boundaries

| Service | Owns | Does Not Own | APIs | Events |
|---|---|---|---|---|
| Catalog | Product metadata, pricing view | inventory stock | Product query APIs | ProductUpdated |
| Cart | Customer cart state | final order | Cart APIs | CartCheckedOut |
| Order | Order lifecycle | payment processing, stock ledger | Order APIs | OrderCreated, OrderConfirmed, OrderCancelled |
| Inventory | Stock reservation | payment/order state | Reservation APIs | InventoryReserved, InventoryRejected |
| Payment | Payment authorization/capture | order orchestration | Payment APIs | PaymentAuthorized, PaymentFailed |
| Shipping | Shipment creation/tracking | order/payment decision | Shipment APIs | ShipmentCreated, ShipmentDelayed |
| Notification | Notification templates and delivery | order state | Notification APIs | NotificationSent, NotificationFailed |

## Key Design Decision

Order Service owns orchestration of the order lifecycle. Inventory, Payment, Shipping, and Notification own their local decisions and publish events.
