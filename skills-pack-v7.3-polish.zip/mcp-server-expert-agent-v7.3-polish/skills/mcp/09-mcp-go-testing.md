# Skill — MCP-Go Testing

## Purpose

Define testing strategy for mcp-go servers.

## Testing Layers

```text
Unit Tests
  ↓
Tool Handler Tests
  ↓
Service Layer Tests
  ↓
Connector Mock Tests
  ↓
MCP Contract Tests
  ↓
Transport Tests
  ↓
Security Tests
  ↓
Deployment Smoke Tests
```

## Test Focus

- input validation
- missing required fields
- enum validation
- date parsing
- error mapping
- service behavior
- redaction
- policy denial
- authorization failure
- transport behavior

## Required CI Checks

```bash
go test ./...
go vet ./...
gofmt -w .
go test -race ./...
```
