# Skill — Agent Packaging and Adoption

## Purpose

Package this skills pack for Custom GPTs, VS Code agents, internal copilots, or enterprise AI platforms.

## Use When

The user asks how to operationalize the skills pack or plug it into agent workflows.

## Packaging Options

| Mode | Best For | Files to Use |
|---|---|---|
| Custom GPT | Architecture Q&A and reviews | instructions.md, context.md, memory.md, skills/ |
| VS Code Agent | Engineering implementation | skills/, examples/, snippets/, contracts/ |
| Enterprise Copilot | Governed architecture reviews | contracts/, templates/, resources/, rubrics/ |
| MCP Tool Server | Executable review tools | examples/microservices-system-design-mcp-server/ |
| Architecture Board Pack | Leadership decision support | presentation/, case-studies/, diagrams/ |

## Adoption Roadmap

1. Use the pack for manual reviews.
2. Add it to an architecture agent.
3. Expose review tools through MCP.
4. Connect to design repositories and service catalogs.
5. Add governance workflows and approval gates.
