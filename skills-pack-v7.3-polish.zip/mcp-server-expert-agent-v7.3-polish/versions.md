# Version Policy

## Go

- Recommended: Go 1.23.x for new examples.
- Minimum practical baseline: Go 1.23+.

## MCP library

- Primary Go MCP library: `github.com/mark3labs/mcp-go`.
- Example module pin: `v0.52.0`.
- Treat library versions as explicit dependencies. Do not generate examples with floating or implicit versions.

## Transports

- Local development: stdio.
- Enterprise deployment: Streamable HTTP behind an API gateway.
- Real-time web clients: SSE where appropriate.

## Compatibility rule

When generating implementation code, always state the library version and transport assumption in the README.

## Production rule

Do not expose Streamable HTTP or SSE deployments without authentication, authorization, rate limits, audit logging, output redaction, and tenant-aware policy checks.
