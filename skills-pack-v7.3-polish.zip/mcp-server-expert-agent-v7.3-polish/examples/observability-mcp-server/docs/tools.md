# MCP Tools

## `query_metrics`

Read-only domain tool. Risk: Low. Approval: No.

## `detect_error_spike`

Read-only domain tool. Risk: Low. Approval: No.

## `summarize_incident`

Read-only domain tool. Risk: Low. Approval: No.

## `generate_runbook_recommendation`

Read-only domain tool. Risk: Low. Approval: No.


## Query controls

Bound time windows and redact log output before returning to an agent.
