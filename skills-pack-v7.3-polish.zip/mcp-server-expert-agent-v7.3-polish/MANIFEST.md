# Manifest — MCP Server Expert Skills Pack v7.3 Polish

This manifest explains what each top-level folder is for, who should use it, and whether it is agent-loadable, executable, or reference-only.

| Path | Purpose | Primary audience | Status | Load into agent? | Copy as repo? |
|---|---|---|---|---:|---:|
| `instructions.md` | Root behavior and quality rules for the MCP Server Expert agent | Agent builder | Ready | Yes | No |
| `context.md` | User/workspace context for the agent | Agent builder | Ready | Yes | No |
| `memory.md` | Stable agent preferences and operating assumptions | Agent builder | Ready | Yes | No |
| `skills/` | Task-specific agent skills grouped by MCP, domain, microservices, and accelerator workflows | Agent builder / architect | Ready | Yes, selectively | No |
| `patterns/microservices/` | Actionable pattern cards | Architect / agent | Ready | Selectively | No |
| `azure-implementation-maps/` | Azure service mappings for cloud-native implementation | Architect / cloud engineer | Ready | Selectively | No |
| `playbooks/` | Step-by-step implementation playbooks | Engineering leads | Ready | Selectively | No |
| `reference-architectures/` | Reusable architecture combinations | Architect | Ready | Selectively | No |
| `templates/` | Output templates for ADRs, contracts, scorecards, topology, reviews, and backlog | Architect / agent | Ready | Selectively | No |
| `templates/go/` | Shared Go utility templates for MCP starter repos | Go engineer | Ready | Optional | Copy snippets only |
| `contracts/` | MCP tool and architecture tool contracts | Agent/tool designer | Ready | Selectively | No |
| `examples/` | Standalone Go/mcp-go starter repos | Go engineer | Starter | No, unless implementing | Yes |
| `case-studies/` | Applied architecture examples | Architect / leadership reviewer | Ready | Optional | No |
| `diagram-prompts/` | Mermaid, PlantUML, and draw.io-ready assets | Architect | Ready | Optional | No |
| `presentation/` | Executive, architecture-board, and engineering communication pack | Leadership / architecture board | Ready | Optional | No |
| `demo/architecture-review-demo/` | Offline deterministic architecture-review demo | Agent adopter / reviewer | Ready | No | No |
| `testdata/golden/` | Golden outputs used by demo validation | Maintainer | Ready | No | No |
| `docs/status/` | Status, loading, and contract-index documents | Maintainer / adopter | Ready | Optional | No |

## Important scope notes

- The demo is an offline deterministic review workflow. It validates output structure and packaging discipline.
- The demo does not start an MCP server or perform live MCP client-to-server calls.
- The Go examples are starter repos. They include service-layer tests and MCP wiring, but full builds require dependency download with `go mod tidy`.
- Planned architecture-tool contracts are deliberate backlog items, not implemented MCP tools.
