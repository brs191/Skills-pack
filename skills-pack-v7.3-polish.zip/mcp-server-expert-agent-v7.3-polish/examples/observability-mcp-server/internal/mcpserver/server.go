package mcpserver

import (
	"github.com/example/observability-mcp-server/internal/audit"
	"github.com/example/observability-mcp-server/internal/policy"
	observabilitysvc "github.com/example/observability-mcp-server/internal/services/observability"
	"github.com/example/observability-mcp-server/internal/tools/health"
	domaintools "github.com/example/observability-mcp-server/internal/tools/observability"
	"github.com/mark3labs/mcp-go/server"
)

func NewServer() *server.MCPServer {
	s := server.NewMCPServer("observability-mcp-server", "1.0.0", server.WithToolCapabilities(true), server.WithRecovery())
	svc := observabilitysvc.NewService(observabilitysvc.NewMockClient())
	pol := policy.NewEngine()
	aud := audit.NewStdoutAuditor()
	health.Register(s)
	domaintools.Register(s, svc, pol, aud)
	return s
}
