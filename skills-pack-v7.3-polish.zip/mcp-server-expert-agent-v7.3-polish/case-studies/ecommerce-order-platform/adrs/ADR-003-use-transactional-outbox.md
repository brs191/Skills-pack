# ADR-003 — Use Transactional Outbox for Reliable Event Publishing

## Status

Accepted

## Context

Services need to update their local database and publish domain events reliably. If a service writes to the database and then publishes an event in a separate operation, failures can create inconsistent state: the database commit succeeds but the event is never published, or the event is published but the local transaction fails.

The platform needs reliable event publication without distributed transactions.

## Decision

Use the **Transactional Outbox** pattern for services that publish business-critical events.

Each service writes domain state and an outbox record in the same local database transaction. A background publisher reads the outbox and publishes events to the messaging system. Published events are marked as delivered after successful publish.

## Options Considered

| Option | Pros | Cons |
|---|---|---|
| Publish event directly after database write | Simple | Can lose events if publish fails after commit |
| Publish before database write | Simple | Can publish invalid events if DB write fails |
| Distributed transaction | Strong consistency | Not practical across cloud services and message brokers |
| Transactional Outbox | Reliable local transaction and eventual event publish | Requires outbox table/container, publisher, retries, and cleanup |

## Decision Drivers

- Avoid lost business events
- Avoid distributed transactions
- Support database-per-service architecture
- Enable replay and audit of published events
- Improve operational recovery

## Consequences

### Positive

- Database state and event intent are committed together
- Failed publishes can be retried
- Outbox can support operational audit and replay
- Works well with Saga and event-driven workflows

### Negative

- Adds background publisher complexity
- Requires cleanup and retention policy
- Duplicate event delivery remains possible
- Consumers must remain idempotent

## Failure Modes

- Publisher crashes after publishing but before marking event delivered
- Outbox grows due to publisher failure
- Duplicate event delivery occurs after retry
- Event schema version drift breaks consumers
- Cleanup removes events too early for audit needs

## Operational Impact

- Monitor outbox depth and oldest unprocessed event age.
- Alert on publish failures and dead-letter growth.
- Include idempotency keys and event IDs in all events.
- Add replay tooling for controlled recovery.
- Document retention and cleanup policy.

## Cost Impact

Outbox storage and publisher compute increase operating cost slightly. The reliability gain is worth it for order, inventory, payment, and fulfillment events.

## Azure Services Involved

- Azure Cosmos DB or Azure SQL
- Azure Service Bus
- Azure Container Apps jobs / worker services or AKS workers
- Azure Monitor / Application Insights

## MCP Tools / Resources Impacted

- `recommend_microservice_patterns`
- `review_microservice_design`
- `detect_architecture_risks` planned
- `generate_event_contract` planned

## Review Date

Review when a service publishes business-critical events or changes its event storage, publisher, or broker strategy.
