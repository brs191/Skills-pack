package cost

import (
	"context"
	"fmt"
)

type AzureCostClient interface {
	GetCostSummary(ctx context.Context, req CostSummaryRequest) (CostSummary, error)
	FindIdleResources(ctx context.Context, subscriptionID string, lookbackDays string) ([]IdleResource, error)
	DetectCostAnomalies(ctx context.Context, subscriptionID, fromDate, toDate string) ([]CostAnomaly, error)
}

type Service struct{ client AzureCostClient }

func NewService(client AzureCostClient) *Service { return &Service{client: client} }

type CostSummaryRequest struct {
	SubscriptionID string `json:"subscription_id"`
	FromDate       string `json:"from_date"`
	ToDate         string `json:"to_date"`
	Granularity    string `json:"granularity"`
}

type CostSummary struct {
	SubscriptionID string          `json:"subscription_id"`
	Currency       string          `json:"currency"`
	TotalCost      float64         `json:"total_cost"`
	Granularity    string          `json:"granularity"`
	Items          []CostBreakdown `json:"items"`
}

type CostBreakdown struct {
	Service       string  `json:"service"`
	ResourceGroup string  `json:"resource_group"`
	Cost          float64 `json:"cost"`
}

type IdleResource struct {
	ResourceID          string  `json:"resource_id"`
	ResourceType        string  `json:"resource_type"`
	ResourceGroup       string  `json:"resource_group"`
	EstimatedMonthlyRun float64 `json:"estimated_monthly_run_cost"`
	Reason              string  `json:"reason"`
	Recommendation      string  `json:"recommendation"`
}

type CostAnomaly struct {
	Service         string  `json:"service"`
	ResourceGroup   string  `json:"resource_group"`
	DeltaPercent    float64 `json:"delta_percent"`
	EstimatedImpact float64 `json:"estimated_impact"`
	Explanation     string  `json:"explanation"`
}

type FinOpsReport struct {
	SubscriptionID     string          `json:"subscription_id"`
	ExecutiveSummary   string          `json:"executive_summary"`
	TotalCost          float64         `json:"total_cost"`
	TopCostDrivers     []CostBreakdown `json:"top_cost_drivers"`
	IdleResources      []IdleResource  `json:"idle_resources"`
	Anomalies          []CostAnomaly   `json:"anomalies"`
	RecommendedActions []string        `json:"recommended_actions"`
}

func (s *Service) GetCostSummary(ctx context.Context, req CostSummaryRequest) (CostSummary, error) {
	if req.SubscriptionID == "" {
		return CostSummary{}, fmt.Errorf("subscription_id is required")
	}
	if req.Granularity == "" {
		req.Granularity = "daily"
	}
	return s.client.GetCostSummary(ctx, req)
}

func (s *Service) FindIdleResources(ctx context.Context, subscriptionID string, lookbackDays string) ([]IdleResource, error) {
	if subscriptionID == "" {
		return nil, fmt.Errorf("subscription_id is required")
	}
	if lookbackDays == "" {
		lookbackDays = "30"
	}
	return s.client.FindIdleResources(ctx, subscriptionID, lookbackDays)
}

func (s *Service) DetectCostAnomalies(ctx context.Context, subscriptionID, fromDate, toDate string) ([]CostAnomaly, error) {
	if subscriptionID == "" {
		return nil, fmt.Errorf("subscription_id is required")
	}
	return s.client.DetectCostAnomalies(ctx, subscriptionID, fromDate, toDate)
}

func (s *Service) GenerateFinOpsReport(ctx context.Context, subscriptionID, fromDate, toDate string) (FinOpsReport, error) {
	summary, err := s.GetCostSummary(ctx, CostSummaryRequest{SubscriptionID: subscriptionID, FromDate: fromDate, ToDate: toDate, Granularity: "monthly"})
	if err != nil {
		return FinOpsReport{}, err
	}
	idle, err := s.FindIdleResources(ctx, subscriptionID, "30")
	if err != nil {
		return FinOpsReport{}, err
	}
	anomalies, err := s.DetectCostAnomalies(ctx, subscriptionID, fromDate, toDate)
	if err != nil {
		return FinOpsReport{}, err
	}
	return FinOpsReport{
		SubscriptionID:     subscriptionID,
		ExecutiveSummary:   "Cost is concentrated in compute and database services. Review idle resources and investigate anomaly signals before taking action.",
		TotalCost:          summary.TotalCost,
		TopCostDrivers:     summary.Items,
		IdleResources:      idle,
		Anomalies:          anomalies,
		RecommendedActions: []string{"Review idle VMs", "Validate database SKU utilization", "Create budget alert for anomaly-prone services"},
	}, nil
}
