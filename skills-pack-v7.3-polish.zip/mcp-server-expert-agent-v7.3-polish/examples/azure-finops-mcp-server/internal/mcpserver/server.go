package mcpserver

import (
	"github.com/example/azure-finops-mcp-server/internal/audit"
	"github.com/example/azure-finops-mcp-server/internal/connectors/azure"
	"github.com/example/azure-finops-mcp-server/internal/policy"
	costservice "github.com/example/azure-finops-mcp-server/internal/services/cost"
	costtools "github.com/example/azure-finops-mcp-server/internal/tools/cost"
	"github.com/example/azure-finops-mcp-server/internal/tools/health"
	"github.com/mark3labs/mcp-go/server"
)

func NewServer() *server.MCPServer {
	s := server.NewMCPServer(
		"azure-finops-mcp-server",
		"0.3.0",
		server.WithToolCapabilities(true),
		server.WithRecovery(),
	)

	auditor := audit.NewStdoutAuditor()
	policyEngine := policy.NewEngine()
	azureClient := azure.NewMockCostClient()
	costSvc := costservice.NewService(azureClient)

	health.Register(s)
	costtools.Register(s, costSvc, policyEngine, auditor)

	return s
}
