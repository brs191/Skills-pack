# DevOps MCP Tool Backlog

| Tool | Purpose | Risk | Approval | Status | Test cases |
|---|---|---|---|---|---|
| `get_pipeline_status` | Read current pipeline status | Low | No | Implemented starter | success, missing pipeline, unauthorized repo |
| `summarize_failed_build` | Summarize failed build logs | Low | No | Implemented starter | failed step, truncated logs, no logs |
| `get_recent_deployments` | List recent deployments | Low | No | Planned | empty env, invalid environment, large result limit |
| `create_release_notes` | Draft release notes from commits/work items | Medium | Optional | Planned | protected repo, no commits, large changelog |
| `open_pull_request` | Create PR from generated change | Medium | Yes for protected repos | Planned | branch exists, policy denial, reviewer required |
| `trigger_pipeline` | Trigger CI/CD pipeline | High | Yes | Planned | dry-run, approval missing, protected environment |

## Implementation rules

- Start with read-only tools.
- Never expose arbitrary shell execution.
- Require approval for deployment or repo-write tools.
- Always log actor, repo, branch, environment, and action.
