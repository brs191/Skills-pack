# Skill — MCP-Go Security Test Generation

## Purpose

Generate executable security-oriented tests for MCP server service, policy, and redaction layers.

## Use When

The user asks for:
- security tests
- tenant isolation tests
- approval workflow tests
- prompt injection tests
- redaction tests
- production readiness hardening

## Required Test Categories

- Unauthorized user denied
- Wrong tenant denied
- High-risk tool denied without approval
- Invalid subscription scope rejected
- Oversized query window rejected
- Secrets and sensitive data redacted
- Prompt-injection-like input treated as data
- Read-only MVP has no mutation tools

## Preferred Location

```text
internal/policy/policy_test.go
internal/security/redaction_test.go
internal/services/<domain>/service_test.go
```

## Rule

Security tests should validate the service and policy boundary even if the MCP client layer is mocked.
