---
skill: skills/microservices/05-data-architecture.md
exercises_section: Cross-service consistency patterns
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: data architecture

## Prompt

Pick the right data-pattern combination for: a service that publishes inventory change events that three downstream services consume, with strict consistency required between the inventory database and the events (an event must never be lost or duplicated in a way that misleads consumers). Justify the choice.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Transactional outbox for the producer** — names outbox as the way to atomically write inventory change + event
- [ ] **Idempotent consumers for the three subscribers** — names idempotency at every consumer because at-least-once delivery means duplicates
- [ ] **"Never lost OR never duplicated" is two different problems** — distinguishes them: outbox addresses lost; idempotency addresses duplicates
- [ ] **No 2PC** — explicitly rejects two-phase commit between DB and broker as the wrong shape
- [ ] **Specific Azure mechanism** — names Service Bus (or Event Grid / Event Hubs) with a reason; doesn't say "use messaging"
- [ ] **Tail risk: relay or projector lag** — calls out that outbox + idempotency don't eliminate delivery delay; consumers may see events seconds after the DB commit

## Reference output

> **Combination: transactional outbox on the producer + idempotent consumers on each subscriber.**
>
> "Never lost" and "never duplicated in a misleading way" are two distinct guarantees and need different mechanisms.
>
> **Never lost** is solved at the producer with the transactional outbox. The inventory-service writes the inventory change row and an `outbox` row in the same DB transaction. A relay process polls the outbox and publishes to the broker. If the broker is unreachable, the outbox row stays unpublished; the relay retries until success. The DB commit is the durable point — no event can be acknowledged to downstream without it being recoverable. Two-phase commit between DB and broker is the alternative; it's brittle (long locks, broker availability tied to DB throughput) and disfavored in cloud-native designs.
>
> **Never duplicated** is solved at each consumer with idempotency. The broker (Service Bus) is at-least-once: the relay or the broker itself may redeliver. Each downstream maintains a `processed_events(event_id)` table; on receipt, it checks-then-inserts in the same DB transaction as the side-effect. Duplicate delivery becomes a no-op.
>
> **Azure choice: Service Bus Topics with per-consumer subscriptions.** Each downstream gets its own subscription with its own DLQ. Subject-message-id is used as the event ID for dedup. Sessions can be enabled if per-aggregate ordering matters (e.g., `sessionId = productId` so updates to one product are processed serially).
>
> **Tail risk to communicate**: outbox + idempotency does not eliminate latency. The relay polls; downstream subscriptions can fall behind. The guarantee is *eventual* — events arrive, in order per-session, without loss or duplicate effect, but there's a window during which the inventory DB is updated and the consumer hasn't yet seen the event. Surface this in product expectations.
>
> **Combination summary**
> - Producer writes domain row + outbox row in one transaction. ✓ never lost.
> - Relay publishes to Service Bus, marks outbox rows as sent. ✓ at-least-once.
> - Consumer dedups on event_id in same transaction as side-effect. ✓ never effectively duplicated.

## Notes

Catches LLMs that name "outbox" without the consumer-side half, or "idempotent consumer" without the producer-side half. Both are needed; the skill explicitly pairs them.
