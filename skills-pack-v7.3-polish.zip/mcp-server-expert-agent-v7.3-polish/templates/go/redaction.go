package security

import "regexp"

var sensitivePatterns = []*regexp.Regexp{
	regexp.MustCompile(`(?i)(api[_-]?key|token|secret|password)\s*[:=]\s*[^\s,]+`),
	regexp.MustCompile(`(?i)Bearer\s+[A-Za-z0-9._\-]+`),
}

func Redact(input string) string {
	out := input
	for _, pattern := range sensitivePatterns {
		out = pattern.ReplaceAllString(out, "$1=<redacted>")
	}
	return out
}
