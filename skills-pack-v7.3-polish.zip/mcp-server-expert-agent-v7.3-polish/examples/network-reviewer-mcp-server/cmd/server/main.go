package main

import (
	"fmt"
	"log"
	"os"

	"github.com/example/network-reviewer-mcp-server/internal/mcpserver"
	"github.com/mark3labs/mcp-go/server"
)

func main() {
	s := mcpserver.NewServer()
	transport := os.Getenv("MCP_TRANSPORT")
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	switch transport {
	case "streamablehttp", "http":
		fmt.Printf("starting Network Reviewer MCP Server on Streamable HTTP :%s\n", port)
		if err := server.NewStreamableHTTPServer(s).Start(":" + port); err != nil {
			log.Fatal(err)
		}
	case "sse":
		fmt.Printf("starting Network Reviewer MCP Server on SSE :%s\n", port)
		if err := server.NewSSEServer(s).Start(":" + port); err != nil {
			log.Fatal(err)
		}
	default:
		fmt.Println("starting Network Reviewer MCP Server on stdio")
		if err := server.ServeStdio(s); err != nil {
			log.Fatal(err)
		}
	}
}
