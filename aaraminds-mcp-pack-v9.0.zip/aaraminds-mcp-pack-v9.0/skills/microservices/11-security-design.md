# Skill — Microservices Security and Compliance Design

## Purpose

Design defense-in-depth security for microservices systems: authentication, authorization, data protection, and audit. This skill applies the principle that no single layer is trusted; every layer validates. Use this after the full architecture is designed to ensure security is embedded, not bolted on.

## Defense-in-Depth Principle

Security is not a single gate. Assume every layer can be breached. Design so breaches are detected and contain damage.

**Layers (from client to data):**
1. **Ingress authentication:** Verify who the client is (OAuth, API key, mTLS)
2. **Authorization:** Verify the client can do what they're asking (fine-grained per endpoint)
3. **Service-to-service:** Services authenticate each other (managed identity, mTLS)
4. **Data access:** Database enforces who can see what (row-level security, encryption)
5. **Encryption at rest:** Data encrypted in storage
6. **Audit:** Every action logged with who/when/what

If any layer fails, others remain. If authentication is broken, authorization still limits damage.

## Layer 1 — Ingress Authentication

**For user-facing APIs (public or user-authenticated):**

### OAuth 2.0 / OIDC (recommended for web/mobile)

**Flow:**
```
User: "I want to log in"
  ↓ Browser redirects to OAuth provider (Azure AD, Google, etc.)
OAuth provider: "Here's a token"
  ↓ Browser returns token to app
App: "I have a token. Can I access this?"
  ↓ API validates token against OAuth provider
API: "Token is valid for user-123"
  ↓ API processes request as user-123
```

**Implementation:**
```
Headers:
  Authorization: Bearer <access_token>

Token validation:
  1. Check signature (using provider's public key)
  2. Check expiration (token is not stale)
  3. Check scopes (token grants required permissions)
```

**Azure implementation:**
- Azure AD: built-in OAuth provider
- Application Insights: automatic token validation for .NET

### API Keys (for service-to-service or simple cases)

**Flow:**
```
Service A: calls Service B with API key
Service B: looks up key in database
Service B: loads permissions for that key
Service B: checks if key permits the operation
```

**Best practices:**
- Rotate keys frequently (3–6 months)
- Use different keys per environment (prod key never appears in dev)
- Rate-limit per key (detect compromised keys early)

**Azure implementation:**
- API Management: API key management built-in
- Key Vault: store keys securely

### mTLS (Mutual TLS, for service-to-service)

**Flow:**
```
Service A: "I'm service-a (with certificate)"
Service B: verifies certificate against CA
Service B: "You're authorized"
  ↓ Encrypted connection established
```

**When to use:**
- Service-to-service (internal network)
- Dapr sidecars: mTLS built-in

## Layer 2 — Authorization (Fine-Grained Access Control)

**Problem:** Authentication only answers "who are you?" Authorization answers "can you do this?"

**Example — without fine-grained authorization:**
```
User logged in as employee
GET /salaries/employee-123 → returns Jane's salary
GET /salaries/employee-456 → returns Bob's salary (should fail! Jane can't see Bob's salary)
```

**With fine-grained authorization:**
```
GET /salaries/employee-123 → allowed (Jane's own record)
GET /salaries/employee-456 → denied (not your record, not manager/HR)
```

### RBAC (Role-Based Access Control)

**Model:**
- User has role (employee, manager, admin)
- Role has permissions (can read payroll, can approve expenses)
- Check: does user's role have permission?

**Example:**
```
User: alice, Role: manager
POST /approvals/expense-claim-123
  Check: manager role has "approve_expenses" permission? Yes
  Proceed

User: bob, Role: employee
POST /approvals/expense-claim-123
  Check: employee role has "approve_expenses" permission? No
  Deny (401 Unauthorized)
```

### ABAC (Attribute-Based Access Control)

**Model:**
- Attributes: user attributes (department), resource attributes (classification), action (read/write)
- Rules: if user.department == resource.department AND action == read, allow

**Example:**
```
User: alice, Attributes: {department: sales, clearance: standard}
Resource: contract-2024.pdf, Attributes: {department: sales, classification: internal}

Rule: access if (user.department == resource.department)
Check: sales == sales? Yes
Allow

User: bob, Attributes: {department: engineering, clearance: standard}
Check: engineering == sales? No
Deny
```

### Decision Framework

| Scenario | Model | Implementation |
|---|---|---|
| Few roles (employee, manager, admin) | RBAC | Check user.role against permission table |
| Many departments, fine-grained rules | ABAC | Policy engine (e.g., OPA, AWS IAM) |
| Sensitive data (healthcare, finance) | ABAC + field-level | Encrypt fields, decrypt only if authorized |

## Layer 3 — Service-to-Service Security

**Problem:** If attacker compromises one service, they can call any other service and bypass authorization.

**Solution:** Services authenticate each other.

### Managed Identity (Azure-native)

**Flow:**
```
Order service: "I'm order-service (with Azure managed identity)"
Payment service: verifies with Azure AD
Payment service: "You're order-service, proceed"
```

**Azure implementation:**
- Container Apps: automatic managed identity
- Service gets token from Azure AD automatically
- No credential management needed

### API Keys (between services)

**Flow:**
```
Order service: calls Payment service with API key
Payment service: checks key is valid, loads permissions
```

**Security:** Keys stored in Azure Key Vault, injected at runtime.

## Layer 4 — Data Access Control

**Database-level:** Encrypt sensitive columns, enforce row-level access.

### Encryption at Rest (Azure SQL, Cosmos)

**What's encrypted:** data on disk, in backups, in replication

**How:**
- Azure handles encryption transparently
- Encryption key in Key Vault (BYOK: Bring Your Own Key)

### Row-Level Security (Azure SQL)

**Example:**
```
Customer table:
  customer_id | name | email | department
  1 | Alice | alice@... | sales
  2 | Bob | bob@... | engineering

Security policy:
  if user.role == employee:
    only see rows where department == user.department

Query: SELECT * FROM customers
  Employee (sales): sees only Alice
  Employee (engineering): sees only Bob
  Admin: sees both
```

**Implementation:**
```sql
CREATE SECURITY POLICY EmployeeSecurityPolicy
  ADD FILTER PREDICATE dbo.fn_securitypredicate(department)
    ON dbo.customers

WHERE function checks:
  if user.role == admin: return 1 (all rows)
  else: return (department = user_context_department)
```

## Layer 5 — Encryption in Transit

**TLS (Transport Layer Security):** Encrypt all network traffic.

**Implementation:**
- HTTPS for all HTTP APIs (TLS 1.2+)
- Service Bus: built-in encryption
- Dapr: mTLS between sidecars

**Certificate management:**
- Azure Key Vault: store certificates
- Azure App Service: automatic cert renewal
- Let's Encrypt: free, automated (for public APIs)

## Layer 6 — Audit and Compliance

**What to log (audit trail):**
- Who (user ID, service, IP)
- When (timestamp)
- What (action: read order, update payment, delete record)
- Result (success or failure)
- Context (which order, customer, amount)

**Example audit log:**
```json
{
  "timestamp": "2026-05-18T10:23:45Z",
  "user": "alice@company.com",
  "service": "order-service",
  "action": "read",
  "resource": "order-123",
  "result": "success",
  "ipAddress": "192.168.1.100"
}

{
  "timestamp": "2026-05-18T10:24:00Z",
  "user": "bob@company.com",
  "service": "order-service",
  "action": "read",
  "resource": "order-123",
  "result": "denied (unauthorized)",
  "reason": "user not in order's department",
  "ipAddress": "203.0.113.45"
}
```

**Compliance:**
- GDPR: audit who accessed PII
- PCI-DSS: audit payment data access
- HIPAA: audit patient data access
- SOC 2: continuous audit logging

**Azure implementation:**
- Application Insights: logs every request
- Log Analytics: centralized audit trail
- Azure Policy: enforce compliance rules

## Common Vulnerabilities and Mitigations

| Vulnerability | Mitigation |
|---|---|
| Passwords in logs | Never log passwords; use structured logs with sanitization |
| Secrets in config files | Azure Key Vault; never hardcode secrets |
| SQL injection | Parameterized queries; input validation |
| Authorization bypass | Test every endpoint with unauthorized user |
| Insecure deserialization | Validate JSON schema before deserializing |
| Unencrypted PII | Encrypt sensitive columns; TLS for transport |
| Missing audit trail | Log every state-changing action |
| Weak token validation | Always validate signature and expiration |

## Worked Example — Order Service Security

**Authentication (Layer 1):**
- User-facing API: OAuth token (bearer token in header)
- Service-to-service: Azure managed identity

**Authorization (Layer 2):**
```
GET /orders/{orderId}:
  ✓ Allowed: the order belongs to the authenticated user
  ✗ Denied: different user trying to read someone else's order

POST /orders:
  ✓ Allowed: authenticated user (customer)
  ✗ Denied: unauthenticated request

PUT /orders/{orderId}/cancel:
  ✓ Allowed: order owner or support staff with override
  ✗ Denied: other users
```

**Service-to-service (Layer 3):**
- Order service → Payment service: managed identity
- Order service → Inventory service: managed identity

**Data protection (Layer 4-5):**
- Customer email, address: encrypted at rest
- All APIs: HTTPS only
- Service Bus: encrypted messages

**Audit (Layer 6):**
```
Order created: {user: customer-123, orderId, items: [...], timestamp}
Order cancelled: {user: customer-123, reason, timestamp}
Order accessed: {user: support-staff-456, action: view, timestamp}
```

## Verification Questions

1. **Authentication:** How do you verify the client is who they claim? (Token, API key, cert)

2. **Authorization:** Can user A access user B's order? (Should be no; is it no?)

3. **Service-to-service:** How do services authenticate each other? (Managed identity, mTLS, API key)

4. **Encryption:** Is data encrypted in transit (TLS) and at rest?

5. **Audit:** Can you retrieve "who accessed this order?" from logs?

6. **Secrets:** Are any secrets in config files, logs, or source code? (Should be zero.)

## What to read next

- For Azure-specific security: `09-azure-mapping.md`
- For compliance standards: Azure compliance documentation
- For threat modeling: MCP skill `skills/mcp/20-mcp-go-threat-modeling.md`
