# Architecture Tool Contract Index

This folder separates implemented architecture-tool contracts from planned contracts.

## Implemented contracts

| Tool | Contract | Handler/service path exists? | Test coverage | Demo coverage | Risk level |
|---|---|---:|---:|---:|---|
| `review_microservice_design` | `implemented/review_microservice_design.md` | Yes | Service-layer | Yes, offline demo | Low |
| `recommend_microservice_patterns` | `implemented/recommend_microservice_patterns.md` | Yes | Service-layer | Yes, offline demo | Low |
| `score_well_architected_readiness` | `implemented/score_well_architected_readiness.md` | Yes | Service-layer | Yes, offline demo | Low |

## Planned contracts

| Tool | Contract | Why planned | Suggested next step | Risk level |
|---|---|---|---|---|
| `map_patterns_to_azure_services` | `planned/map_patterns_to_azure_services.md` | Useful for explicit Azure mapping output | Implement service that reads `azure-implementation-maps/` | Low |
| `detect_architecture_risks` | `planned/detect_architecture_risks.md` | Useful for architecture-board decisions | Implement rule-based risk classifier | Low |
| `generate_architecture_decision_record` | `planned/generate_architecture_decision_record.md` | Useful for formal governance | Implement ADR generator using template | Low |
| `generate_service_boundary_canvas` | `planned/generate_service_boundary_canvas.md` | Useful for service ownership clarity | Implement canvas generator | Low |
| `generate_api_contract` | `planned/generate_api_contract.md` | Useful for API-first design | Implement OpenAPI-like contract output | Low |
| `generate_event_contract` | `planned/generate_event_contract.md` | Useful for event-driven systems | Implement event schema output | Low |
| `generate_resilience_plan` | `planned/generate_resilience_plan.md` | Useful for reliability review | Implement failure-mode and mitigation planner | Low |
| `generate_observability_plan` | `planned/generate_observability_plan.md` | Useful for operations readiness | Implement logging/metrics/tracing planner | Low |
| `generate_deployment_topology` | `planned/generate_deployment_topology.md` | Useful for cloud deployment design | Implement topology generator | Low |
| `generate_diagram_assets` | `planned/generate_diagram_assets.md` | Useful for Mermaid/PlantUML/draw.io output | Implement diagram asset generator | Low |

## Usage rule

Do not present planned contracts as implemented MCP tools. When using a planned contract, describe it as a design template or backlog item.
