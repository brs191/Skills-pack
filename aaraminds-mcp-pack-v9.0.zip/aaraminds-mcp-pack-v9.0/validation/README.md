# Validation Pack

Evidence that the v9.0 pack works at the quality it claims. Three concerns, three subdirectories:

| Subdirectory | What it contains | When you use it |
|---|---|---|
| [prompts/](prompts/) | Curated capability prompts spanning MCP server building, microservices design, architecture review, and cross-cutting concerns. Each prompt ships with a rubric (objective checklist) and a reference output (exemplar). | Quarterly quality demonstration; before tagging a release; when teaching a new contributor what "good" looks like. |
| [skill-evals/](skill-evals/) | One eval per skill file. Each eval is a small prompt that exercises the specific guidance in the skill, plus a rubric for scoring the response. | After any change to a skill file. The eval is the regression check for that skill. |
| [governance/](governance/) | Freshness cadence with named ownership and a pre-release checklist that ties together every gap. | Quarterly (re-verify Go SDK / Azure / ecosystem facts). Before each tagged release. |

## Why this exists

The earlier gaps (skills depth, pattern cards, demo authenticity) made the pack **better**. This gap makes the quality **provable**. Without it, a change to a load-bearing skill can silently regress without anyone noticing until a user files an issue. With it, every skill and capability area has a small, runnable check that a maintainer can use to catch drift before it ships.

## Validation model: rubric + reference

Goldens cannot be byte-exact for LLM-driven prompts (LLMs are stochastic). Instead, every prompt and every skill eval has two complementary artifacts:

- **Rubric** — a checklist of objective points the response must cover. Each point is yes/no. The pass criterion (e.g., "at least 7 of 9 rubric points") is declared in the eval.
- **Reference output** — a hand-curated exemplar showing the *shape and depth* of a quality response. This is not a byte-exact target; it is a "good answer looks like this" reference for human reviewers.

A run "passes" when the response satisfies the declared rubric threshold. The reference output is for inspection — does the actual response look like the same quality bar?

This split is deliberate. Rubrics make the check objective and machine-checkable. References keep the quality bar visible and human-meaningful.

## How to run it

This pack provides the **artifacts**. The user provides the **runtime** (Claude Code, an Anthropic SDK script, OpenAI API, anything that takes a prompt and produces a response).

### Manual flow

1. Pick a prompt or skill eval.
2. Paste the prompt section into your LLM with the relevant skill file(s) attached as context.
3. Score the response against the rubric.
4. Compare against the reference output for shape and depth.
5. If rubric threshold is met, log the run in the eval's "Last run" field (date + result). Otherwise, file an issue against the skill or the eval.

### Automated flow (optional)

You can wire a runner script that:
1. Parses an eval's prompt + rubric.
2. Calls your LLM with the skill file in context.
3. Scores response against rubric (each point: scan response for the keyphrase or pattern; or use an LLM-as-judge call).
4. Emits PASS / FAIL with per-point breakdown.

This pack does not ship the runner script — the right shape depends on which LLM you use and how you want to integrate it (CI step, pre-commit hook, ad-hoc CLI). The eval file format is intentionally parseable so a 100-line script can drive it.

## Coverage at v9.0

| Area | Files | What's covered |
|---|---|---|
| Validation prompts | 12 | 3 MCP-server-building, 4 microservices-design, 3 architecture-review, 2 cross-cutting |
| Per-skill evals (microservices) | 12 | All 12 microservices skill files |
| Per-skill evals (MCP) | 22 | All 22 uplifted MCP skill files (the full Gap 3 set) |
| Governance | 2 | Freshness cadence, pre-release checklist |

Pattern-card-level evals (21 cards) are intentionally not included at v9.0. The cards follow a uniform structure validated by the Phase B boilerplate-grep tests, and the per-skill evals indirectly exercise them through cross-references. Add card evals only if the cards begin to drift.

## What this pack is NOT

- It is not an LLM benchmark. The rubrics are pack-specific, not general capability measurements.
- It is not a substitute for human judgment. The reference outputs are exemplars, not ceilings.
- It is not exhaustive coverage. It is the smallest set of artifacts that, if all pass, gives high confidence the pack works at quality.

## Related

- [governance/freshness-cadence.md](governance/freshness-cadence.md) — who owns each refresh
- [governance/release-checklist.md](governance/release-checklist.md) — pre-release runbook tying every gap together
- [../ROADMAP.md](../ROADMAP.md) — Gap 6 entry, where this work lands in the path to 9.0+
