---
skill: skills/microservices/01-design-router.md
exercises_section: Routing logic and reasoning sequence
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: design router

## Prompt

A user asks: "How should I structure a microservices system for an online learning platform?" Walk through how you would route this request through the design steps — what do you address first, second, third? Don't design the system; show the order of reasoning.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Starts with the business capability** — first step is naming what the system is *for*, not jumping to services or technologies
- [ ] **Bounded contexts before services** — addresses domain decomposition before naming concrete services
- [ ] **Data ownership before communication** — establishes who owns what data before deciding how services talk
- [ ] **Communication shape after boundaries** — sync vs. async decisions come after the boundaries are clear
- [ ] **Resilience and observability come late** — added after the architecture is established, not first
- [ ] **Cost and trade-offs as a checkpoint** — explicitly notes that cost / team-size / complexity is a gate before commitment

## Reference output

> The router applies the design sequence in order; jumping ahead is the most common failure mode.
>
> 1. **Business capability.** What is the platform actually *for*? Course delivery? Live cohort sessions? Self-paced content? The answer changes everything downstream. Without this step, the team designs for "an online learning platform" in the abstract and ends up with services nobody can defend.
> 2. **Bounded contexts.** Identify the core domains — content authoring, enrollment, progress tracking, billing, video delivery — without picking service names yet. Contexts come from the business; services are an implementation choice that follows.
> 3. **Service boundaries from contexts.** Each context becomes one or two services with clear data ownership. No service co-owns data with another.
> 4. **Communication shape.** For each cross-service interaction: synchronous if the caller blocks on the result, asynchronous (event) otherwise. Saga / outbox / idempotent-consumer become relevant for any multi-step workflow.
> 5. **Azure mapping.** Pick services per workload: Container Apps for most, Azure SQL or Cosmos by data shape, Service Bus for transactional messaging.
> 6. **Resilience and observability.** Timeout/retry/circuit-breaker per dependency; distributed tracing; SLOs.
> 7. **Cost / team-size gate.** Step back: does this architecture fit the team and the realistic Year-1 load? If not, lean it down — modular monolith if it's small, fewer services, cheaper tiers.
>
> Only at the end of this sequence do you have a defensible design. Doing step 5 before step 1 is how teams build elaborate Azure architectures for products nobody wants.

## Notes

Catches LLMs that jump to "use these Azure services" without walking the upstream decisions. Order of reasoning is the test, not depth at any one step.
