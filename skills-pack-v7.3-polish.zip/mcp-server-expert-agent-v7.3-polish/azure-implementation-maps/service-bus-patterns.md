# Azure Implementation Map — Service Bus Patterns

## Purpose
Azure Service Bus supports durable commands, queues, topics, dead-letter queues, sessions, and business workflow decoupling.

## Use When
- The architectural concern is present in the system.
- Azure-native implementation reduces operational burden.
- Security, reliability, cost, and observability are explicitly addressed.

## Implementation Checklist
- [ ] Identity model defined
- [ ] Network boundary defined
- [ ] Data ownership clear
- [ ] Failure handling defined
- [ ] Observability enabled
- [ ] Cost and scaling model defined
- [ ] CI/CD and rollback defined

## MCP Review Guidance
Use this map when generating Azure service recommendations, ADRs, risk reviews, and deployment topology.
