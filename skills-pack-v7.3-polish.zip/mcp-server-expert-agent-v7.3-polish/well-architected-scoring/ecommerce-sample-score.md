# E-Commerce Order Platform — Sample Well-Architected Score

| Pillar | Score | Evidence | Key Gap |
|---|---:|---|---|
| Reliability | 86 | Saga, outbox, DLQ, retries, idempotency | Multi-region failover not yet defined |
| Security | 88 | APIM, WAF, Managed Identity, Key Vault | Admin API privilege model needs detail |
| Operational Excellence | 84 | OpenTelemetry, dashboards, CI/CD, ADRs | Runbooks need ownership mapping |
| Performance Efficiency | 82 | Autoscaling, Redis cache, async messaging | Load test targets need finalization |
| Cost Optimization | 78 | Container Apps option, autoscaling, right-sizing | Cost guardrails need automation |

## Overall Score

84 / 100 — Strong design, targeted hardening required.

## Top Remediations

1. Define multi-region strategy for checkout-critical paths.
2. Add admin API authorization model.
3. Add operational runbooks and ownership.
4. Add load testing targets.
5. Add budget alerts and cost anomaly detection.
