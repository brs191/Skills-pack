# Case Study — Azure E-Commerce Order Platform

## Purpose

A complete reference case study for designing a cloud-native, Azure-hosted microservices platform.

## Scenario

A retail business wants to modernize from a monolith into a scalable order platform that can support web/mobile checkout, inventory reservation, payments, shipping, notifications, and customer order tracking.

## Architecture Goal

Design a practical microservices architecture that balances autonomy, reliability, operational simplicity, and Azure implementation fit.

## Included Assets

- Problem statement
- Business capabilities
- Service boundary canvas
- API contracts
- Event contracts
- ADRs
- Azure deployment topology
- Resilience, security, and observability models
- Mermaid diagrams
- Well-Architected score
- MCP architecture tool execution examples

## Recommended Azure Services

- Azure Front Door
- Azure API Management
- AKS or Azure Container Apps
- Azure Service Bus
- Azure Event Grid
- Azure Cosmos DB
- Azure Cache for Redis
- Azure SQL Database where relational consistency is needed
- Azure Key Vault
- Microsoft Entra ID / Managed Identity
- Azure Monitor + Application Insights + OpenTelemetry
