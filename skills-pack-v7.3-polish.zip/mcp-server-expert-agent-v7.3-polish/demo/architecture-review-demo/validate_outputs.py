#!/usr/bin/env python3
import argparse
import json
import sys
from pathlib import Path

REQUIRED = [
    'ecommerce-review-output.json',
    'ecommerce-pattern-map.json',
    'ecommerce-scorecard.json',
    'ecommerce-adr-output.md',
    'ecommerce-diagram-output.mmd',
    'architecture-board-summary.md',
]


def read_json(path: Path):
    return json.loads(path.read_text())


def normalize_text(s: str) -> str:
    return '\n'.join(line.rstrip() for line in s.strip().splitlines()) + '\n'


def compare_file(generated: Path, golden: Path) -> list[str]:
    if generated.suffix == '.json':
        if read_json(generated) != read_json(golden):
            return [f'JSON mismatch: {generated.name}']
        return []
    if normalize_text(generated.read_text()) != normalize_text(golden.read_text()):
        return [f'Text mismatch: {generated.name}']
    return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--golden', default='../../testdata/golden')
    args = ap.parse_args()

    out = Path(args.out)
    golden = Path(args.golden)

    missing_out = [f for f in REQUIRED if not (out / f).exists()]
    missing_golden = [f for f in REQUIRED if not (golden / f).exists()]
    if missing_out:
        print('Missing generated outputs:', ', '.join(missing_out))
        sys.exit(1)
    if missing_golden:
        print('Missing golden outputs:', ', '.join(missing_golden))
        sys.exit(1)

    errors: list[str] = []
    for f in REQUIRED:
        errors.extend(compare_file(out / f, golden / f))

    review = read_json(out / 'ecommerce-review-output.json')
    score = read_json(out / 'ecommerce-scorecard.json')
    if review['production_readiness_score'] < 75:
        errors.append('production_readiness_score below acceptance threshold')
    if score['overall_score'] < 75:
        errors.append('overall_score below acceptance threshold')
    if len(review['recommended_patterns']) < 5:
        errors.append('expected at least five recommended patterns')

    if errors:
        print('Validation failed:')
        for e in errors:
            print(f'- {e}')
        sys.exit(1)

    print('Validation passed: generated outputs match golden outputs')


if __name__ == '__main__':
    main()
