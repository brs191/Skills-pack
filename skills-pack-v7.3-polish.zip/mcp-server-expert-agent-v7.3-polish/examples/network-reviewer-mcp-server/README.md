# Network Reviewer MCP Server

Go MCP server starter repo using `github.com/mark3labs/mcp-go`.

## Tools

- `get_network_topology`
- `detect_nsg_risks`
- `analyze_route_tables`
- `estimate_network_cost_impact`


## Run locally

```bash
go mod tidy
go run ./cmd/server
```

## Run HTTP

```bash
MCP_TRANSPORT=streamablehttp PORT=8080 go run ./cmd/server
```

## Test

```bash
go test ./...
```

## Production note

This starter uses mock connectors. Replace them with real enterprise connectors and keep policy, audit, redaction, and approval gates in place.
