package policy

import "testing"

func TestWrongTenantDenied(t *testing.T) {
	engine := NewEngine()
	decision := engine.Authorize(Request{Tool: "test", TenantID: "wrong-tenant", Risk: RiskLow})
	if decision.Allowed {
		t.Fatal("expected wrong tenant to be denied")
	}
}

func TestHighRiskRequiresApproval(t *testing.T) {
	engine := NewEngine()
	decision := engine.Authorize(Request{Tool: "deploy", TenantID: "tenant-example", Risk: RiskHigh})
	if decision.Allowed {
		t.Fatal("expected high risk request without approval to be denied")
	}
}

func TestApprovedHighRiskAllowed(t *testing.T) {
	engine := NewEngine()
	decision := engine.Authorize(Request{Tool: "deploy", TenantID: "tenant-example", Risk: RiskHigh, Approved: true})
	if !decision.Allowed {
		t.Fatalf("expected approved high risk request to be allowed: %s", decision.Reason)
	}
}
