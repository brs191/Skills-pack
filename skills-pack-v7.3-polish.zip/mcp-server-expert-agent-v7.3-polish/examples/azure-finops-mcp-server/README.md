# Azure FinOps MCP Server

A Go-based MCP server using `github.com/mark3labs/mcp-go` for Azure FinOps analysis.

## Features

- `health_check`
- `get_cost_summary`
- `find_idle_resources`
- `detect_cost_anomalies`
- `generate_finops_report`
- stdio transport for local agent usage
- Streamable HTTP transport for enterprise deployment
- SSE transport option
- mock Azure connector for local development
- policy, audit, and telemetry boundaries
- unit tests and CI

## Run locally

```bash
go mod tidy
go run ./cmd/server
```

## Run with Streamable HTTP

```bash
MCP_TRANSPORT=streamablehttp PORT=8080 go run ./cmd/server
```

## Run tests

```bash
go test ./...
go test -race ./...
```

## Tool maturity

All tools are read-only in this starter implementation. Replace `internal/connectors/azure/mock_client.go` with real Azure SDK clients when moving beyond local development.

## Security note

Do not expose this server remotely without authentication, authorization, tenant checks, rate limits, and audit logging.
