# Azure Microservices Well-Architected Scoring Model

## Pillars and Weight

| Pillar | Weight |
|---|---:|
| Reliability | 25 |
| Security | 25 |
| Operational Excellence | 20 |
| Performance Efficiency | 15 |
| Cost Optimization | 15 |

## Rating Bands

| Score | Rating |
|---:|---|
| 90-100 | Production-ready with minor refinements |
| 75-89 | Strong design, targeted hardening required |
| 60-74 | Viable but several production gaps |
| 40-59 | High-risk design |
| <40 | Not ready |

## Evidence Rule

A score must be backed by explicit design evidence. Do not assign high scores for stated intent alone.
