# Skill — Microservices Resilience Patterns

## Purpose
Design failure-aware cloud microservices.

## Core Patterns
- Timeout
- Retry with backoff and jitter
- Circuit breaker
- Bulkhead
- Rate limiting
- Queue-based load leveling
- Dead-letter queue
- Health probes
- Graceful degradation
- Multi-region failover where justified

## Azure Mapping
| Concern | Azure Option |
|---|---|
| API throttling | APIM policies |
| Queue resilience | Service Bus retry + DLQ |
| Workload health | AKS/Container Apps probes |
| Traffic routing | Front Door / Traffic Manager |
| Monitoring | Azure Monitor alerts |
| Secrets availability | Key Vault with caching strategy |

## Review Questions
- What happens if one service is slow?
- What happens if the queue consumer is down?
- What happens if a message is duplicated?
- What happens if a dependency times out?
- Can the user-facing path degrade safely?
