# Skill — Microservices Architecture Generation

## Purpose
Generate actionable Azure-hosted microservices architectures.

## Required Input Discovery
When possible identify:
- business capability
- expected users and traffic
- critical workflows
- data domains
- consistency needs
- integration systems
- security/compliance needs
- availability target
- team maturity
- deployment preference

## Output Template
1. Problem statement
2. Business capability map
3. Service map
4. Data ownership model
5. API/event contracts required
6. Recommended Azure topology
7. Resilience patterns
8. Security model
9. Observability model
10. Deployment strategy
11. Cost considerations
12. ADR list
13. MVP implementation backlog

## Guardrail
If microservices are not justified, recommend a modular monolith first and show the migration path to microservices.
