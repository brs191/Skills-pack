# Skill — Microservices Communication Patterns

## Purpose
Choose synchronous, asynchronous, event-driven, and workflow communication patterns.

## Decision Rules
- Use synchronous HTTP/gRPC only for short, user-facing, low-latency calls.
- Use async messaging for long-running workflows, unreliable dependencies, and cross-domain integration.
- Use events for state-change notifications.
- Use queues/commands when work must be performed reliably.
- Add idempotency and correlation IDs to every message.

## Azure Mapping
| Communication Need | Azure Service |
|---|---|
| External API | Azure API Management |
| Internal REST | AKS/Container Apps internal ingress |
| Durable commands | Azure Service Bus queues |
| Pub/sub domain events | Service Bus topics or Event Grid |
| Telemetry streams | Event Hubs |
| Long-running workflows | Durable Functions / Temporal on AKS |

## Required Message Metadata
- correlation_id
- causation_id
- message_id
- schema_version
- producer
- tenant_id when multi-tenant
- idempotency_key where needed
