# Skill — One-Command Architecture Demo Workflow

## Purpose

Run a deterministic end-to-end demo that converts a sample architecture input into architecture review artifacts.

## Use When

The user asks to demonstrate the skills pack, show an end-to-end flow, validate output quality, or create architecture board-ready artifacts.

## Default Flow

```text
sample architecture input
  ↓
architecture review engine
  ↓
pattern recommendation
  ↓
Azure mapping
  ↓
Well-Architected scoring
  ↓
ADR generation
  ↓
diagram output
  ↓
architecture board summary
```

## Expected Command

```bash
cd demo/architecture-review-demo
make demo
```

## Outputs

- `ecommerce-review-output.json`
- `ecommerce-pattern-map.json`
- `ecommerce-scorecard.json`
- `ecommerce-adr-output.md`
- `ecommerce-diagram-output.mmd`
- `architecture-board-summary.md`

## Agent Behavior

When asked for a demo, do not explain patterns in isolation. Produce a full review package with:

1. Architecture summary
2. Service boundaries
3. Recommended patterns
4. Azure service mapping
5. Risks and mitigations
6. Well-Architected score
7. ADRs
8. Diagram-ready output
9. Next-step implementation roadmap
