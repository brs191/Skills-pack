package policy

type Risk string

const (
	RiskLow      Risk = "low"
	RiskMedium   Risk = "medium"
	RiskHigh     Risk = "high"
	RiskCritical Risk = "critical"
)

type Request struct {
	Tool     string
	TenantID string
	Risk     Risk
	Approved bool
}

type Decision struct {
	Allowed bool
	Reason  string
}

type Engine struct{ AllowedTenant string }

func NewEngine() *Engine { return &Engine{AllowedTenant: "tenant-example"} }

func (e *Engine) Authorize(req Request) Decision {
	if req.TenantID != "" && e.AllowedTenant != "" && req.TenantID != e.AllowedTenant {
		return Decision{Allowed: false, Reason: "tenant is not authorized"}
	}
	if (req.Risk == RiskHigh || req.Risk == RiskCritical) && !req.Approved {
		return Decision{Allowed: false, Reason: "human approval required"}
	}
	return Decision{Allowed: true, Reason: "allowed"}
}
