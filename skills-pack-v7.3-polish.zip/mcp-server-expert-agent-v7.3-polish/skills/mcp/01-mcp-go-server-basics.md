# Skill — MCP-Go Server Basics

## Purpose

Help the user create a basic MCP server using `github.com/mark3labs/mcp-go`.

## Use When

The user asks to create an MCP server in Go, start with mcp-go, build a basic MCP server, create hello world MCP server, or add the first MCP tool.

## Installation

```bash
go mod init github.com/example/my-mcp-server
go get github.com/mark3labs/mcp-go
```

## Minimal Server Pattern

```go
package main

import (
	"context"
	"fmt"

	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func main() {
	s := server.NewMCPServer(
		"enterprise-mcp-server",
		"1.0.0",
		server.WithToolCapabilities(false),
		server.WithRecovery(),
	)

	helloTool := mcp.NewTool("hello_world",
		mcp.WithDescription("Say hello to a person"),
		mcp.WithString("name", mcp.Required(), mcp.Description("Name of the person to greet")),
	)

	s.AddTool(helloTool, helloHandler)

	if err := server.ServeStdio(s); err != nil {
		fmt.Printf("server error: %v\n", err)
	}
}

func helloHandler(ctx context.Context, request mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	name, err := request.RequireString("name")
	if err != nil {
		return mcp.NewToolResultError(err.Error()), nil
	}
	return mcp.NewToolResultText(fmt.Sprintf("Hello, %s!", name)), nil
}
```

## Guidance

Start with one binary, one transport, one or two tools, a clear README, and no enterprise complexity until the tool contract is stable.

## Production Warning

Start with read-only tools. Add authorization, audit, and approval workflows before enabling write actions.
