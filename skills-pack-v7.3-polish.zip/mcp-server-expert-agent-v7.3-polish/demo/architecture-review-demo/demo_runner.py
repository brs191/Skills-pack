#!/usr/bin/env python3
import argparse, json
from pathlib import Path


def review(data):
    return {
        "system_name": data["system_name"],
        "summary": "The design is a strong fit for a managed Azure microservices MVP if service boundaries, data ownership, async workflows, and observability are implemented deliberately.",
        "service_boundary_assessment": [
            {"service": s["name"], "assessment": "Good business-capability boundary", "owns_data": s.get("owns_data", [])}
            for s in data["services"]
        ],
        "recommended_patterns": ["API Gateway", "Saga", "Transactional Outbox", "Idempotent Consumer", "Circuit Breaker", "Distributed Tracing", "Cache Aside"],
        "azure_service_mapping": [
            {"concern": "API Gateway", "azure_service": "Azure API Management", "reason": "Centralized auth, throttling, versioning, and external API governance"},
            {"concern": "Async workflow", "azure_service": "Azure Service Bus", "reason": "Durable commands and order workflow messages"},
            {"concern": "Domain events", "azure_service": "Event Grid", "reason": "Event notification fan-out"},
            {"concern": "Service data", "azure_service": "Cosmos DB", "reason": "Service-owned document data and elastic scale"},
            {"concern": "Secrets", "azure_service": "Key Vault + Managed Identity", "reason": "No shared secrets in services or MCP tools"},
            {"concern": "Observability", "azure_service": "Azure Monitor + OpenTelemetry", "reason": "Distributed traces, logs, metrics, and incident correlation"}
        ],
        "risks": [
            {"risk": "Distributed transaction complexity", "severity": "High", "mitigation": "Use Saga with explicit compensation and idempotency"},
            {"risk": "Event duplication", "severity": "Medium", "mitigation": "Use idempotent consumers and message de-duplication keys"},
            {"risk": "Service boundary drift", "severity": "Medium", "mitigation": "Maintain service boundary canvas and ADR reviews"},
            {"risk": "Observability gaps", "severity": "High", "mitigation": "Mandate correlation IDs and OpenTelemetry from MVP"}
        ],
        "missing_decisions": ["MVP target: Container Apps or AKS", "Payment provider failure policy", "Inventory reservation timeout", "Data retention and privacy controls"],
        "production_readiness_score": 86,
        "recommended_next_steps": ["Finalize ADRs", "Create API and event contracts", "Implement outbox for order-service", "Add trace correlation", "Run security review before production"]
    }


def pattern_map():
    return {
        "patterns": [
            {"pattern": "API Gateway", "azure_mapping": "Azure API Management", "why": "External API governance and policy enforcement"},
            {"pattern": "Saga", "azure_mapping": "Azure Service Bus + workflow state", "why": "Order, inventory, and payment consistency without distributed transactions"},
            {"pattern": "Transactional Outbox", "azure_mapping": "Cosmos DB container + Service Bus publisher", "why": "Reliable event publishing after local transaction"},
            {"pattern": "Idempotent Consumer", "azure_mapping": "Service Bus message ID + consumer state", "why": "Safe duplicate handling"},
            {"pattern": "Distributed Tracing", "azure_mapping": "OpenTelemetry + Application Insights", "why": "End-to-end incident diagnosis"}
        ]
    }


def scorecard():
    pillars = {
        "reliability": 86,
        "security": 88,
        "cost_optimization": 82,
        "operational_excellence": 84,
        "performance_efficiency": 87
    }
    return {
        "overall_score": round(sum(pillars.values())/len(pillars), 1),
        "pillars": pillars,
        "rating": "Strong design, needs targeted hardening",
        "top_improvements": [
            "Add compensation rules for failed payment and inventory release",
            "Define DLQ ownership and operational runbook",
            "Add per-service SLOs and alert rules",
            "Confirm Container Apps vs AKS decision based on platform maturity"
        ]
    }


def adr():
    return """# ADR: Use Saga with Transactional Outbox for Order Workflow

## Status
Accepted for MVP with implementation guardrails.

## Context
The order workflow spans order capture, inventory reservation, payment authorization, and notification. Each service must own its data, so a distributed database transaction is not appropriate.

## Decision
Use a Saga pattern coordinated through durable messages. Each service performs a local transaction and publishes events using a Transactional Outbox.

## Options Considered

| Option | Pros | Cons |
|---|---|---|
| Distributed transaction | Strong consistency | Poor cloud fit, operational complexity |
| Single checkout service | Simpler MVP | Weak boundaries, limited scale independence |
| Saga + Outbox | Cloud-native, resilient, auditable | Requires idempotency and compensation logic |

## Consequences

- Services remain independently deployable.
- Eventual consistency must be visible in product and operations.
- Compensation and timeout rules must be implemented explicitly.
- Observability must include correlation IDs across all workflow steps.

## Azure Services

- Azure Service Bus
- Cosmos DB
- Azure Monitor
- OpenTelemetry
"""


def diagram():
    return """flowchart LR
    C[Web / Mobile Client] --> FD[Azure Front Door]
    FD --> APIM[Azure API Management]
    APIM --> OS[Order Service]
    OS --> ODB[(Cosmos DB - Orders)]
    OS --> SB[Azure Service Bus]
    SB --> IS[Inventory Service]
    SB --> PS[Payment Service]
    IS --> IDB[(Cosmos DB - Inventory)]
    PS --> PDB[(Cosmos DB - Payments)]
    IS --> EG[Event Grid]
    PS --> EG
    EG --> NS[Notification Service]
    OS -. traces .-> OTEL[OpenTelemetry]
    IS -. traces .-> OTEL
    PS -. traces .-> OTEL
    OTEL --> MON[Azure Monitor / App Insights]
"""


def board_summary(score):
    return f"""# Architecture Board Summary — Azure E-Commerce Order Platform

## Decision Requested
Approve MVP architecture with targeted hardening actions before production go-live.

## Recommendation
Proceed with Azure API Management, Azure Container Apps for MVP, Azure Service Bus for durable workflow messaging, Cosmos DB for service-owned data, and OpenTelemetry for end-to-end tracing.

## Overall Score
{score['overall_score']} / 100 — {score['rating']}

## Top Risks

1. Distributed transaction complexity across order, inventory, and payment.
2. Event duplication and inconsistent consumer behavior.
3. Observability gaps during incidents.
4. Platform decision between Container Apps and AKS may need revisiting as scale grows.

## Required Conditions for Approval

- Saga compensation rules documented.
- Transactional Outbox implemented for order workflow events.
- DLQ runbook and ownership defined.
- Service-level SLOs and alert rules created.
- ADRs approved by architecture board.
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    data = json.loads(Path(args.input).read_text())
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    r = review(data); pm = pattern_map(); sc = scorecard()
    (out/'ecommerce-review-output.json').write_text(json.dumps(r, indent=2)+"\n")
    (out/'ecommerce-pattern-map.json').write_text(json.dumps(pm, indent=2)+"\n")
    (out/'ecommerce-scorecard.json').write_text(json.dumps(sc, indent=2)+"\n")
    (out/'ecommerce-adr-output.md').write_text(adr()+"\n")
    (out/'ecommerce-diagram-output.mmd').write_text(diagram()+"\n")
    (out/'architecture-board-summary.md').write_text(board_summary(sc)+"\n")
    print(f"Generated architecture review package in {out}")

if __name__ == '__main__':
    main()
