# Architecture Board Review Pack

## 1. Decision Requested
Approve the proposed MVP architecture with required hardening conditions.

## 2. Proposed Architecture
Azure API Management fronts managed microservices running on Azure Container Apps. Order workflows use Azure Service Bus. Domain notifications use Event Grid. Each service owns its data in Cosmos DB. OpenTelemetry sends traces and metrics to Azure Monitor/Application Insights.

## 3. Key Decisions

| Decision | Recommendation |
|---|---|
| API gateway | Azure API Management |
| Workflow consistency | Saga |
| Event reliability | Transactional Outbox |
| MVP runtime | Azure Container Apps |
| Future platform scale | AKS evaluation checkpoint |

## 4. Approval Conditions

- ADRs accepted
- API/event contracts baselined
- SLOs created
- DLQ runbooks completed
- Security controls validated

## 5. Recommendation
Approve with conditions.
