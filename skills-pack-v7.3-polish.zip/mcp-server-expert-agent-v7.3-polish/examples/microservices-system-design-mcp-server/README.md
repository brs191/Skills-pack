# Microservices System Design MCP Server

A reference MCP server for architecture review, pattern recommendation, Azure mapping, ADR generation, and Well-Architected scoring.

## Tools

- `review_microservice_design`
- `score_well_architected_readiness`

## Run

```bash
go mod tidy
go run ./cmd/server
```

## Run HTTP

```bash
MCP_TRANSPORT=streamablehttp PORT=8080 go run ./cmd/server
```

## Test

```bash
go test ./...
```

## Purpose

This example demonstrates how architecture knowledge can be exposed as MCP tools for AI architects and system-design agents.
