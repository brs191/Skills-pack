---
skill: skills/mcp/00-ecosystem-facts.md
exercises_section: Dated ecosystem state and verification cadence
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: ecosystem facts

## Prompt

A teammate says: "the MCP server-basics skill says use mark3labs/mcp-go. Let's just pin that version forever." Why is that wrong, and what does the ecosystem-facts file teach about how to handle the question of which version to use?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Pinning forever is wrong** — names that the ecosystem moves; pinned versions become security and compatibility debt
- [ ] **Dated facts** — names that the ecosystem-facts file dates every claim and recommends re-verification quarterly
- [ ] **Two viable SDKs** — names both `mark3labs/mcp-go` and `modelcontextprotocol/go-sdk` and explains they exist for different reasons
- [ ] **Default for new teams** — names that the official SDK is the recommended default for teams without a prior commitment
- [ ] **MCP spec version** — distinguishes MCP protocol version from SDK version
- [ ] **Process not just answer** — frames "which version" as a process question (re-verify, document the date, capture in pack) not a one-time answer

## Reference output

> "Pin forever" is wrong because the ecosystem moves. The MCP spec evolves; SDKs follow; Go versions advance; transitive deps get CVEs. A version that was correct in May 2026 may be wrong (insecure, incompatible, abandoned) by November.
>
> The ecosystem-facts file in the pack is dated. Every claim it makes — "as of <date>, the verified-current SDK versions are X" — has a verification date and a recommended cadence for re-checking. Quarterly is the default. The file isn't "the answer for all time"; it's "the answer at this moment, with the recipe for checking again."
>
> **On which SDK to use**
>
> Two SDKs are viable: `mark3labs/mcp-go` (early, community-driven, what this pack's example server uses) and `modelcontextprotocol/go-sdk` (the official one, stable post-1.0). They cover the same ground with different trade-offs. The pack standardizes on `mark3labs/mcp-go` for consistency with its example code; teams without that constraint should consider the official SDK as the default for new work.
>
> **MCP protocol version is separate.** The protocol version (e.g., `2025-11-25`) is what clients and servers negotiate at `initialize`. SDK versions implement *some* spec version; check which. Pinning the SDK pins the spec implementation; bumping the SDK may bump the spec.
>
> **The process the file teaches**
>
> 1. Don't take any version claim in the pack as eternal truth. Check the date.
> 2. Quarterly: re-verify Go version, SDK versions, MCP spec version, Azure service capabilities.
> 3. Update the facts file with new date and any deltas; bump pack version if material.
> 4. Capture the decision (and the date) in the project's ADRs so the team knows when to revisit.
>
> "Pin forever" replaces this discipline with one decision that decays silently. The discipline replaces silent decay with periodic conscious re-verification.

## Notes

Catches the absent-mindedness about ecosystem freshness that makes packs decay. The skill's whole purpose is to make freshness explicit.
