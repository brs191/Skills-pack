---
skill: skills/microservices/09-azure-mapping.md
exercises_section: Hosting and data store decision frameworks
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: Azure mapping

## Prompt

A team is about to commit to AKS as the hosting platform for a brand-new 5-service microservices system. Their justification: "Kubernetes is the standard." Push back, then recommend.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **AKS is the operational tax** — names that managed Kubernetes still requires cluster operations, upgrades, networking, RBAC
- [ ] **Container Apps as the default** — recommends Azure Container Apps for greenfield microservices unless there's a specific reason
- [ ] **When AKS pays** — names concrete conditions for choosing AKS: existing K8s investment, multi-tenant requirements, custom networking, complex orchestration
- [ ] **Container Apps trade-offs** — mentions that Container Apps gives less control (no custom CRDs, limited networking) — call it out, don't hide it
- [ ] **Migration path** — notes that you can start with Container Apps and migrate to AKS later if needed; the reverse is much harder
- [ ] **"Kubernetes is the standard" is not a reason** — explicitly names that "industry default" is a cargo-cult argument; the question is whether this team needs what Kubernetes offers

## Reference output

> "Kubernetes is the standard" is a cargo-cult argument, not a decision. Push back with: what specifically about Kubernetes does this 5-service system need that Container Apps doesn't give?
>
> **The default for greenfield Azure microservices is Container Apps.**
>
> Container Apps gives you managed compute, autoscaling (including scale-to-zero), Dapr integration for mesh-lite features, revisions for blue-green and canary, secrets via Key Vault, and ingress without an operations burden. For 5 services, that's the whole list of things you actually need.
>
> AKS is the right choice when:
> - You already have a Kubernetes investment elsewhere and want to align tooling. (You don't.)
> - You need custom networking (specific CNI, BGP, weird routing). (Unlikely for a 5-service greenfield.)
> - You need to run multi-tenant workloads with strong isolation tied to namespaces and node pools. (Unlikely.)
> - You depend on specific Kubernetes-ecosystem tools (custom CRDs, operators, complex Helm charts). (Don't introduce these by default.)
> - You need fine-grained control over scheduling and resources (Pod-level QoS, anti-affinity rules at scale).
>
> If none of these apply, AKS gives you nothing Container Apps doesn't, and it gives you a cluster to operate.
>
> **The Container Apps trade-off, honestly stated**
>
> You give up: custom CRDs, raw Kubernetes API access, the ability to install arbitrary operators, fine-grained scheduling control, multi-cluster federation. For most greenfield workloads, this is "you give up things you didn't need."
>
> **Migration path**
>
> Start with Container Apps. If you hit a wall — and you'll know which specific feature is missing — migrate to AKS. The reverse is much harder: once you're on AKS with custom operators and Helm charts, you can't easily move to Container Apps. Pick the cheaper option first, escalate when justified.
>
> **Concrete recommendation**
>
> Container Apps. 5 services in a Container Apps environment, Dapr enabled for sidecar features (mTLS, pub/sub, state) without standing up a mesh. Revisions for deploy strategy. Application Insights for observability. Total ops surface: nearly zero.
>
> If the team really wants Kubernetes for resume reasons, that's a different conversation that has nothing to do with the right design choice for this system.

## Notes

Catches the "default to maximum complexity" pattern. The challenge is to actually argue against AKS rather than offering balanced both-sides.
