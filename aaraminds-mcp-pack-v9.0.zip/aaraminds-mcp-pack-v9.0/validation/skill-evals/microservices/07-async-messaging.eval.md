---
skill: skills/microservices/07-async-messaging.md
exercises_section: Choreography vs. orchestration, ordering, idempotency
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: async messaging

## Prompt

A team is debating choreography (services react to events independently) vs. orchestration (a coordinator drives the workflow) for a 6-step order-fulfillment flow. Which do you recommend at this size, and what changes that decision?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Recommends orchestration at 6 steps** — names a coordinator (Durable Functions or equivalent) as the right choice for this size
- [ ] **Choreography becomes preferable when** — names a concrete threshold (≥8 services, or "when no one service owns the workflow") at which choreography wins
- [ ] **Orchestrator gives a single source of truth** — names the operational benefit: queryable saga state, easier debugging
- [ ] **Choreography is harder to reason about** — names the failure mode: no one can draw the flow from a whiteboard
- [ ] **Both still need outbox + idempotency** — points out the choice doesn't relieve either requirement
- [ ] **Hybrid is sometimes right** — acknowledges that real systems often orchestrate the critical path and choreograph fan-out (analytics, notifications)

## Reference output

> **At 6 steps, orchestration is the right choice.**
>
> One coordinator (Azure Durable Functions, an in-house state machine, or a workflow engine) drives the flow. The orchestrator persists state at each step, calls activity functions, handles compensation on failure, and surfaces "where is order X stuck" as a single query. Six steps choreographed across 5+ services would mean each service reasons independently about state; no one can answer where a saga is without correlating logs across all of them.
>
> **Choreography becomes preferable when:**
> - The number of independent reactors grows beyond ~8 services. At that point, central orchestration becomes a coordination bottleneck, and the operational cost of orchestrator state management exceeds the cost of debugging emergent flows.
> - No single service "owns" the workflow. If every step has a different concerned team and the flow is more of a pub/sub fan-out than a directed graph, choreography fits the shape.
> - The workflow is naturally event-shaped (state changes drive interest), not command-shaped.
>
> **What's the same regardless of choice**
> - Transactional outbox at every producer. The events must be reliably published.
> - Idempotent consumers at every receiver. At-least-once delivery means duplicates regardless of which pattern.
> - Distributed tracing with correlation ID. Without it, neither pattern is debuggable in production.
>
> **Hybrid is common.** A real system might orchestrate the customer-facing critical path (order → reserve → authorize → confirm with explicit compensation) while choreographing downstream fan-out (order-confirmed → analytics, ML training, audit, notification — independent subscribers, no compensation). Orchestrate where consistency matters, choreograph where decoupling matters.
>
> **Operational tell-tale for the wrong choice**
> If on-call says "I have no idea where this order is right now," you're probably under-orchestrated. If on-call says "the orchestrator is the bottleneck for everything," you're probably over-orchestrated.

## Notes

Catches "always pick choreography" (event-driven hype) and "always pick orchestration" (state-machine mindset). Both are wrong without sizing the system first.
