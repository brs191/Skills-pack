# Deployment Topology Template

## System Name

## Deployment Target

AKS / Azure Container Apps / App Service / Hybrid

## Environments

| Environment | Region | Purpose | Data classification | Approval gate |
|---|---|---|---|---|

## Topology

```text
Client
  ↓
Front Door / Application Gateway
  ↓
Azure API Management
  ↓
Private ingress
  ↓
Compute platform
  ↓
Services
  ↓
Data / Messaging / Cache
```

## Azure Services

| Concern | Azure Service | Reason |
|---|---|---|

## Network Model

- Public endpoints:
- Private endpoints:
- VNet integration:
- Ingress:
- Egress:
- DNS:

## Identity and Secrets

- Managed identity:
- Key Vault:
- Workload identity:
- Certificate management:

## Release Strategy

- Blue/green:
- Canary:
- Feature flags:
- Rollback:

## Reliability

- Availability zones:
- Multi-region:
- Backup:
- DR target RTO/RPO:

## Observability

- Logs:
- Metrics:
- Traces:
- Dashboards:
- Alerts:

## Cost Controls

- Autoscaling:
- Budgets:
- Tagging:
- Reserved capacity:
