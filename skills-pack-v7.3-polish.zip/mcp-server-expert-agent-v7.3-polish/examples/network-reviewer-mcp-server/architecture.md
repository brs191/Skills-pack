# Network Reviewer MCP Server Architecture

## Purpose

Expose read-only Azure network review capabilities to AI agents for topology analysis, risk detection, and architecture recommendations.

## Architecture

```text
Network Reviewer Agent
  ↓
MCP Client
  ↓
Network Reviewer MCP Server
  ↓
Tenant Boundary + Policy + Audit
  ↓
Tool Handlers
  ↓
Network Review Service Layer
  ↓
Azure Resource Graph / Network Watcher / Firewall / NSG Connectors
```

## Starter scope

- Read network topology
- Review risks and missing controls
- Identify planned improvements
- Keep modification tools out of the MVP

## Security model

- Subscription and tenant scoping
- Read-only by default
- Mandatory approval for any future write action
- Audit for every topology query and risk review

## Production gaps to close

- Real Azure Resource Graph connector
- Network Watcher integration
- Cost impact model
- Policy-as-code integration
- Diagram generation from topology data
