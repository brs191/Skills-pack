---
skill: skills/mcp/22-mcp-go-cicd-quality-gates.md
exercises_section: Gate hierarchy and cost discipline
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go CI/CD quality gates

## Prompt

A team has a CI pipeline with `go test` (no `-race`), `gofmt`, and a demo step that takes 12 minutes and runs on every PR. Developers routinely bypass CI to merge. Redesign the gates: what runs on PR, what runs post-merge, what runs pre-release?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **PR gates fast (<5 min)** — names the runtime ceiling for PR-blocking checks
- [ ] **`go test -race` always** — points out the missing race detector
- [ ] **`-count=1` to bypass cache** — bonus point if mentioned
- [ ] **Lint failure rule** — `gofmt -l . | (! grep .)` to fail build on unformatted files (not `gofmt -d`)
- [ ] **Demo moves off PR** — demo belongs on nightly or pre-release, not PR
- [ ] **Security scans on PR** — govulncheck and dependency check should be PR gates; image scan post-merge
- [ ] **Branch protection enforces required checks** — names that gates without enforcement are advisory

## Reference output

> The pipeline has two problems: missing critical gates (race detector, security scans) and a slow demo on every PR that the team works around. Fix both.
>
> **PR-blocking gates (target: <5 min total)**
>
> 1. `gofmt -l . | tee /dev/stderr | (! grep .)` — fails on any unformatted file. Use `-l` not `-d`; the latter shows diff but doesn't fail.
> 2. `go vet ./...` — catches shadowed vars, format-string bugs, unreachable code.
> 3. `go build ./...` — type-checks everything.
> 4. `go test -race -count=1 ./...` — race detector mandatory; `-count=1` defeats the result cache.
> 5. `govulncheck ./...` — flags CVE-affected dependencies. Cheap.
> 6. Contract test — calls `tools/list` against an in-process server; ensures the tool catalog is what's expected.
>
> All six should complete in under 5 minutes for a small server. Developers stop bypassing CI when it's fast.
>
> **Post-merge gates (run on push to main)**
>
> 1. Docker build — multi-stage, produces the production image.
> 2. Image scan — Trivy or equivalent; fail on CRITICAL/HIGH CVEs.
> 3. Push to registry tagged with the commit SHA.
>
> **Nightly gates (run on a schedule)**
>
> 1. Full demo run: `make demo && make validate` — exercises the server end-to-end across the three reference architectures.
> 2. Long-running integration tests if any.
>
> **Pre-release gates (run before tagging a version)**
>
> 1. All PR gates pass on the release commit.
> 2. All post-merge gates pass.
> 3. Demo run passes.
> 4. Per-skill evals run; ≥90% pass at threshold.
> 5. Release checklist walked (`validation/governance/release-checklist.md`).
>
> **Enforcement**
>
> Configure branch protection on `main` to require the six PR gates. Without enforcement, the gates are advisory; PRs can merge despite failures. The configuration lives in the repo's branch-protection rules (GitHub) or equivalent.
>
> **Why this fixes the bypass problem**
>
> The demo's 12-minute runtime made CI feel punitive on every PR. Moving it to nightly means PRs stay quick; the demo still runs daily and catches regressions before they accumulate. Adding `-race`, govulncheck, and contract tests catches a broader class of bugs at PR time without adding much runtime. The team gets faster PRs *and* better coverage.

## Notes

Catches LLMs that add gates without thinking about cost. The "slow PR gates lead to bypass" framing is the value-add.
