# Demo Flow — Azure Network Topology Review

## User request

"Review this subscription network topology for risks and cost impact."

## Agent flow

```text
1. Call MCP tool: get_network_topology.
2. Call MCP tool: detect_nsg_risks.
3. Call MCP tool: analyze_route_tables.
4. Call MCP tool: estimate_network_cost_impact.
5. Produce security, resiliency, and cost recommendations.
```

## Approval boundary

Reading topology is low risk. Updating NSGs, route tables, firewall rules, or peering requires mandatory approval and change record.
