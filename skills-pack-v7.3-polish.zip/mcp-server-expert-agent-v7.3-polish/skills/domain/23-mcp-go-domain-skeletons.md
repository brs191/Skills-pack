# Skill — MCP-Go Domain Skeletons

## Purpose

Generate domain-specific MCP server skeletons using consistent mcp-go structure.

## Supported skeletons

- Azure FinOps MCP Server
- DevOps Automation MCP Server
- Observability/Grafana MCP Server
- Azure Network Reviewer MCP Server

## Default skeleton structure

```text
cmd/server/main.go
internal/mcpserver/server.go
internal/tools/<domain>/
internal/services/<domain>/
internal/connectors/<backend>/
internal/policy/
internal/audit/
internal/telemetry/
configs/
docs/
deployments/
testdata/
.github/workflows/ci.yml
```

## Generation rules

- Start with read-only tools.
- Add write tools only with policy and approval.
- Include mock connector first.
- Include service tests before backend implementation.
- Include docs and tool contracts.
