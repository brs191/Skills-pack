package observability

import (
	"github.com/example/observability-mcp-server/internal/audit"
	"github.com/example/observability-mcp-server/internal/policy"
	observabilitysvc "github.com/example/observability-mcp-server/internal/services/observability"
	"github.com/mark3labs/mcp-go/server"
)

func Register(s *server.MCPServer, svc *observabilitysvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	registerQueryMetrics(s, svc, policyEngine, auditor)
	registerDetectErrorSpike(s, svc, policyEngine, auditor)
	registerSummarizeIncident(s, svc, policyEngine, auditor)
	registerGenerateRunbookRecommendation(s, svc, policyEngine, auditor)
}
