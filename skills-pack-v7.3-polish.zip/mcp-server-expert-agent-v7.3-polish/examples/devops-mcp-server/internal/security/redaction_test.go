package security

import "testing"

func TestRedactSensitiveValues(t *testing.T) {
	cases := []string{"password=abc", "Bearer token", "api_key:123", "Authorization: xyz"}
	for _, c := range cases {
		if Redact(c) != "[REDACTED]" {
			t.Fatalf("expected redaction for %q", c)
		}
	}
}

func TestNonSensitiveValuePasses(t *testing.T) {
	got := Redact("normal service message")
	if got != "normal service message" {
		t.Fatalf("unexpected redaction: %s", got)
	}
}
