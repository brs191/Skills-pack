# Observability Model

## Required Signals

- distributed traces across checkout workflow
- order_id correlation
- customer_id hashed or tokenized
- payment attempt result
- inventory reservation result
- event publish/consume latency
- dead letter queue depth
- service-level latency and error rate

## Recommended Azure Stack

- OpenTelemetry SDK in all services
- Application Insights for traces and app telemetry
- Azure Monitor for platform metrics
- Log Analytics for query and retention
- Grafana dashboards for operational views

## Golden Signals

- Checkout success rate
- Payment authorization latency
- Inventory reservation failure rate
- Order confirmation latency
- Dead letter queue depth
- API gateway 4xx/5xx rate
