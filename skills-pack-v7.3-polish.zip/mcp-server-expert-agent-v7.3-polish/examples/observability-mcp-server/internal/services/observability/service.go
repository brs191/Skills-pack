package observability

import "context"

type Result struct {
	Summary string   `json:"summary"`
	Items   []string `json:"items"`
}

type Client interface {
	Execute(context.Context, string) (Result, error)
}

type Service struct{ client Client }

func NewService(client Client) *Service { return &Service{client: client} }
func NewMockClient() Client             { return &MockClient{} }

func (s *Service) Execute(ctx context.Context, tool string) (Result, error) {
	return s.client.Execute(ctx, tool)
}
func (s *Service) Primary(ctx context.Context) (string, error) {
	out, err := s.client.Execute(ctx, "query_metrics")
	if err != nil {
		return "", err
	}
	return out.Summary, nil
}

type MockClient struct{}

func (m *MockClient) Execute(ctx context.Context, tool string) (Result, error) {
	return Result{Summary: "Observability mock result for " + tool, Items: []string{"p95 latency elevated", "5xx errors increased", "checkout service affected"}}, nil
}
