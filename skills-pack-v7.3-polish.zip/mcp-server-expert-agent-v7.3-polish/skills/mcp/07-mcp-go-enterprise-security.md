# Skill — MCP-Go Enterprise Security

## Purpose

Apply enterprise security patterns to mcp-go servers.

## Security Model

```text
Identity
  ↓
Tenant Context
  ↓
Tool Permission Check
  ↓
Input Validation
  ↓
Policy Decision
  ↓
Optional Human Approval
  ↓
Tool Execution
  ↓
Output Redaction
  ↓
Audit Log
```

## Required Controls

- Authentication for remote MCP servers
- Authorization per user, tenant, role, environment, tool, action, and resource scope
- Tenant isolation
- Input validation
- Output redaction
- Audit logging
- Rate limits
- Human approval for high-risk tools

## Risk Levels

| Risk | Example | Control |
|---|---|---|
| Low | read cost summary | auth + audit |
| Medium | query logs | auth + redaction + audit |
| High | restart service | approval + audit + rollback |
| Critical | modify IAM/firewall/delete | approval + change ticket + rollback |

## Dangerous Tools

Require human approval for tools that delete resources, restart production, change access, modify firewall/routing, deploy to production, scale infrastructure, update secrets, or change billing controls.
