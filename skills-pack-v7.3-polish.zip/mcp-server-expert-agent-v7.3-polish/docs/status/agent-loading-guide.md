# Agent Loading Guide

Load only the files needed for the task. Do not load the entire pack by default.

## Load Profile 1 — Minimal Load

Use for quick MCP design or review questions.

```text
instructions.md
context.md
memory.md
MANIFEST.md
skills/README.md
skills/00-skill-router.md
```

## Load Profile 2 — Core MCP Load

Use for Go/mcp-go server implementation, tool design, security review, transport choice, or deployment guidance.

```text
instructions.md
context.md
memory.md
skills/README.md
skills/00-skill-router.md
skills/mcp/
templates/tool-definition.md
templates/resource-definition.md
templates/prompt-definition.md
templates/go/
contracts/tools/
docs/status/example-repo-status.md
```

## Load Profile 3 — Domain MCP Load

Use when working on a specific domain MCP server. Load only one domain at a time.

### Azure FinOps

```text
skills/domain/12-mcp-go-azure-finops.md
examples/azure-finops-mcp-server/
contracts/tools/get_cost_summary.md
contracts/tools/find_idle_resources.md
```

### DevOps

```text
skills/domain/13-mcp-go-devops-automation.md
examples/devops-mcp-server/
```

### Observability

```text
skills/domain/14-mcp-go-observability-grafana.md
examples/observability-mcp-server/
```

### Network Reviewer

```text
skills/domain/15-mcp-go-network-reviewer.md
examples/network-reviewer-mcp-server/
```

## Load Profile 4 — Architecture Review Load

Use for microservices system design, Azure architecture reviews, pattern selection, ADRs, scorecards, and architecture-board outputs.

```text
instructions.md
context.md
memory.md
MANIFEST.md
skills/README.md
skills/00-skill-router.md
skills/microservices/
skills/accelerator/
patterns/microservices/
azure-implementation-maps/
rubrics/microservices-system-design-rubric.md
templates/service-boundary-canvas.md
templates/architecture-decision-record.md
templates/microservices-system-design-output.md
templates/azure-well-architected-review.md
contracts/architecture-tools/README.md
contracts/architecture-tools/implemented/
docs/status/architecture-tool-contract-status.md
```

## Load Profile 5 — Full Enterprise Load

Use only when building or reviewing the full accelerator.

```text
all root instruction files
skills/
patterns/
azure-implementation-maps/
playbooks/
reference-architectures/
templates/
contracts/
rubrics/
case-studies/
diagram-prompts/
presentation/
docs/status/
```

## Loading rule

Start small. Add context only when the task needs it. Too many files can make the agent slower and less precise.
