# Skill — MCP-Go Project Structure

## Purpose

Create production-grade Go project structures for mcp-go servers.

## Recommended Structure

```text
mcp-server/
├── cmd/server/main.go
├── internal/
│   ├── app/
│   ├── config/
│   ├── mcpserver/
│   ├── tools/
│   ├── services/
│   ├── connectors/
│   ├── auth/
│   ├── policy/
│   ├── audit/
│   ├── telemetry/
│   └── errors/
├── configs/
├── deployments/docker/
├── deployments/k8s/
├── deployments/helm/
├── docs/
├── test/integration/
├── Dockerfile
├── Makefile
├── go.mod
└── README.md
```

## Package Rules

- `internal/mcpserver`: MCP registration only.
- `internal/tools`: Tool handlers, input parsing, validation, MCP result formatting.
- `internal/services`: Business logic.
- `internal/connectors`: External APIs.
- `internal/policy`: Approval, RBAC, risk checks.
- `internal/audit`: Tool-call audit events.
- `internal/telemetry`: Metrics, traces, structured logs.

## Design Rule

Do not put business logic directly inside `main.go` or MCP registration files.
