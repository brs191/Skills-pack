# Dependency Readiness

## Current state

The Go example repos include `go.mod` files and starter code, but this package does not include `go.sum` files.

Reason: generating `go.sum` requires resolving external dependencies, including `github.com/mark3labs/mcp-go`, from the Go module proxy or source repository.

## What to run after download

From the pack root:

```bash
make tidy-examples
```

Or per repo:

```bash
cd examples/<repo-name>
go mod tidy
go test ./...
```

## Offline-safe validation

The architecture-review demo is offline and deterministic:

```bash
make demo
```

The architecture MCP server service-layer test is also designed to be locally testable where external dependencies are not required:

```bash
make test-system-design
```

## Release positioning

Describe the example repos as **starter repos**, not fully dependency-vendored runnable products.
