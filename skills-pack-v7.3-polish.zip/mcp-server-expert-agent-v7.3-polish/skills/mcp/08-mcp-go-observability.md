# Skill — MCP-Go Observability

## Purpose

Add logging, metrics, tracing, and auditability to mcp-go servers.

## Track

- tool call count
- tool success/failure rate
- latency
- user/session/tenant
- backend dependency calls
- approval decisions
- policy denials
- rate-limit events

## Recommended Events

```text
mcp.server.started
mcp.tool.called
mcp.tool.succeeded
mcp.tool.failed
mcp.tool.denied
mcp.resource.read
mcp.prompt.requested
mcp.policy.evaluated
mcp.approval.requested
mcp.approval.granted
mcp.approval.denied
mcp.backend.call.started
mcp.backend.call.failed
```

## Standard Log Fields

```json
{
  "event": "mcp.tool.called",
  "tool": "get_cost_summary",
  "user_id": "user-123",
  "tenant_id": "tenant-abc",
  "session_id": "session-xyz",
  "risk_level": "low",
  "duration_ms": 123,
  "status": "success"
}
```

## Azure Mapping

| Concern | Azure Service |
|---|---|
| Logs | Azure Monitor / Log Analytics |
| Traces | Application Insights + OpenTelemetry |
| Metrics | Azure Monitor Metrics |
| Secrets | Azure Key Vault |
| Dashboards | Azure Monitor Workbooks / Grafana |
