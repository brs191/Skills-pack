---
skill: skills/mcp/21-mcp-go-client-integration.md
exercises_section: Protocol handshake and client correctness
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go client integration

## Prompt

I'm writing a Python client that drives an MCP server over stdio for a CI smoke test. What are the four things I have to do right for the protocol exchange to work, and what bug appears if I skip each one?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Initialize handshake** — must send `initialize` request first and wait for the response
- [ ] **Initialized notification** — must send `notifications/initialized` before any `tools/call`; server may refuse otherwise
- [ ] **Request ID tracking** — each request gets a unique ID; responses matched by ID; notifications discarded
- [ ] **Stderr handling** — captured deliberately; not parsed as protocol; useful for debugging
- [ ] **Graceful shutdown** — close stdin, wait with timeout, SIGTERM if hung; otherwise orphan processes
- [ ] **`isError: true` not retried as transport error** — tool-level rejections surface to the caller, not retry loops

## Reference output

> Four protocol-level musts; a fifth (shutdown) and a sixth (error handling) keep things clean.
>
> **1. Initialize handshake.** Send `{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "smoke", "version": "1.0"}}}` and wait for the response. The server replies with its capabilities and identity. If you skip this and send a `tools/call` first, the server is in an undefined state — depending on the SDK, it may error or hang.
>
> **2. Initialized notification.** After initialize succeeds, send `{"jsonrpc": "2.0", "method": "notifications/initialized"}` (no `id`; it's a notification). Some servers refuse `tools/call` until this notification is seen. Bug if skipped: first tool call returns an error along the lines of "server not initialized" or hangs.
>
> **3. Request ID tracking.** Every request gets a unique monotonic ID. When reading responses, match the response's `id` field to your in-flight request. Notifications (no `id`) and server-initiated messages must be discarded. Bug if skipped: you read a notification as a response, deserialise it as a tool result, and either crash or get a confusing message.
>
> **4. Stderr handling.** Capture stderr explicitly (subprocess.PIPE). Forward to your own stderr or your logger. The server's stderr is its log channel; if you don't read it, you have no visibility into server-side problems. Bug if skipped: failures are silent; debugging requires running the server manually.
>
> **5. Graceful shutdown.** When the smoke test finishes: close the server's stdin, `wait()` with a timeout (e.g., 5 s), and if the server hasn't exited, `terminate()` then `kill()`. Bug if skipped: orphaned server processes accumulate, eventually exhausting PIDs or memory on the CI runner.
>
> **6. Tool-error vs. transport-error distinction.** A response with `result.isError: true` is the server saying "your tool call had a problem with the arguments or the operation"; that's not a transport failure. Surface it to the test (assert against it) — don't retry. Bug if skipped: retry storms on validation errors.
>
> **One concrete reference**: the pack ships `demo/architecture-review-demo/demo_runner.py` as a ~250-line stdlib Python client doing all of this correctly. Read it as a template before writing your own.

## Notes

Catches LLMs that skip the initialized notification or conflate tool errors with transport errors.
