# MCP Architecture Tool Execution Example — One-Command Demo

## Input

`demo/architecture-review-demo/input/ecommerce-architecture-input.json`

## Simulated Tool Calls

```text
review_microservice_design(input)
recommend_microservice_patterns(input)
map_patterns_to_azure_services(patterns)
score_well_architected_readiness(review)
generate_architecture_decision_record(decision=saga_outbox)
generate_deployment_topology(review)
```

## Output Package

```text
out/ecommerce-review-output.json
out/ecommerce-pattern-map.json
out/ecommerce-scorecard.json
out/ecommerce-adr-output.md
out/ecommerce-diagram-output.mmd
out/architecture-board-summary.md
```

## Interpretation

The output is suitable for a first-pass architecture review. It should be refined with real NFRs, actual traffic estimates, team maturity, compliance constraints, and platform operations input.
