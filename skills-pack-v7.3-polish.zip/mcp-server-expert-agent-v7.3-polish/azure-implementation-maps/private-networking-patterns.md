# Azure Implementation Map — Private Networking Patterns

## Purpose
Private Endpoints, VNets, NSGs, and private DNS reduce public exposure for backend services.

## Use When
- The architectural concern is present in the system.
- Azure-native implementation reduces operational burden.
- Security, reliability, cost, and observability are explicitly addressed.

## Implementation Checklist
- [ ] Identity model defined
- [ ] Network boundary defined
- [ ] Data ownership clear
- [ ] Failure handling defined
- [ ] Observability enabled
- [ ] Cost and scaling model defined
- [ ] CI/CD and rollback defined

## MCP Review Guidance
Use this map when generating Azure service recommendations, ADRs, risk reviews, and deployment topology.
