package devops

import (
	"context"
	"encoding/json"

	"github.com/example/devops-mcp-server/internal/audit"
	"github.com/example/devops-mcp-server/internal/policy"
	devopssvc "github.com/example/devops-mcp-server/internal/services/devops"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerSummarizeFailedBuild(s *server.MCPServer, svc *devopssvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	tool := mcp.NewTool("summarize_failed_build",
		mcp.WithDescription("Execute read-only summarize_failed_build capability"),
		mcp.WithString("tenant_id", mcp.Description("Tenant ID; defaults to tenant-example")),
	)
	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		tenantID := req.GetString("tenant_id", "tenant-example")
		decision := policyEngine.Authorize(policy.Request{Tool: "summarize_failed_build", TenantID: tenantID, Risk: policy.RiskLow})
		if !decision.Allowed {
			return mcp.NewToolResultError(decision.Reason), nil
		}
		out, err := svc.Execute(ctx, "summarize_failed_build")
		if err != nil {
			return mcp.NewToolResultError(err.Error()), nil
		}
		auditor.Record(ctx, audit.Event{Tool: "summarize_failed_build", Status: "success", Risk: "low", TenantID: tenantID})
		b, _ := json.MarshalIndent(out, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})
}
