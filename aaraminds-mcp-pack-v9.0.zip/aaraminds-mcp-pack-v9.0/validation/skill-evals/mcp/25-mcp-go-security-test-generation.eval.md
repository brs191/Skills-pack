---
skill: skills/mcp/25-mcp-go-security-test-generation.md
exercises_section: Categories of security test for MCP servers
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go security test generation

## Prompt

I have a new MCP tool `get_pod_logs(namespace, pod_name, lines)` that I want to add security tests for. Give me a focused set of test cases that catches the regressions most likely to land in production.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Input validation cases** — invalid identifier patterns (path traversal, special chars), out-of-range `lines`, missing required fields
- [ ] **Authorisation cases** — anonymous call rejected, wrong-role call rejected, cross-tenant or cross-namespace call rejected
- [ ] **Resource exhaustion** — large `lines` value bounded or rejected; concurrent calls don't OOM
- [ ] **Information disclosure** — output redacts secrets (tokens, connection strings) from log lines
- [ ] **Error-shape assertion** — tests assert the error *shape*, not just that it errored (e.g., "expected size-related error message, got X")
- [ ] **Concurrency / `-race`** — tests run under `-race` to catch data races in shared state

## Reference output

> Here's a focused set of cases for `get_pod_logs`:
>
> **Input validation**
>
> 1. `namespace: ""` — required, reject.
> 2. `pod_name: ""` — required, reject.
> 3. `namespace: "../../../etc"` — path-traversal-shaped value, must fail pattern validation.
> 4. `pod_name: "my-pod; rm -rf /"` — shell-meta characters, reject.
> 5. `lines: -1` — must be non-negative, reject.
> 6. `lines: 10_000_000` — above documented max (e.g., 10,000), reject with size message.
> 7. `lines` omitted — accept; use default (e.g., 100).
> 8. Unknown field `password` in input — silently ignored, doesn't change behaviour.
>
> **Authorisation**
>
> 9. Anonymous call — reject with auth-required error.
> 10. Authenticated but lacking `cluster-reader` role — reject with "not authorised for this namespace".
> 11. Caller authorised for namespace A, calls with `namespace: "B"` — reject.
> 12. Expired token — reject; structured error indicating expiry.
>
> **Resource exhaustion**
>
> 13. `lines: 9999` (high but within limit) — accept; assert response size is bounded.
> 14. 100 concurrent calls — all complete; no data races (`-race` flag); no panics.
> 15. Very slow connection over HTTP transport — server enforces request timeout; doesn't hang.
>
> **Information disclosure**
>
> 16. Log content contains a connection string like `password=hunter2` — output redacts to `password=***` or omits the line.
> 17. Server-side error (e.g., upstream K8s API down) — error response contains a clear message, no stack trace, no file paths.
>
> **Error-shape assertion**
>
> For each negative test, assert not only `IsError == true` but also the error message structure:
>
> ```go
> if !strings.Contains(strings.ToLower(res.ErrorMessage), "namespace is required") {
>     t.Errorf("expected 'namespace is required' message, got %q", res.ErrorMessage)
> }
> ```
>
> Without shape assertions, the test passes when the server panics with a 500 instead of returning a clean error — exactly the regression we're trying to catch.
>
> **Where to put them**
>
> A separate `internal/services/podlogs/security_test.go` file (or a `+build security` tag) so the security suite can run as a focused CI gate. Run with `-race` always. Failure of a security test is a release blocker.

## Notes

Catches LLMs that produce a generic "test for SQL injection" list without engaging with the specific tool's attack surface.
