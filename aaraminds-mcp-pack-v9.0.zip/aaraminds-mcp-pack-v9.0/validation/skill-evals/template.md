---
skill: skills/<area>/<file>.md
exercises_section: <heading from the skill that this eval stresses>
pass_threshold: <N>/<M>
last_run: never
last_result: never run
---

# Eval: <skill display name>

## Prompt

<1–3 sentence prompt that exercises the specific guidance in this skill.
Should be small enough that a quality response fits in 200–500 words.
Should target one decision, one risk, or one trade-off — not all of them.>

## Rubric

A response passes if it covers at least <N> of the following <M> points:

- [ ] **<short label>** — <specific point the skill teaches that the response must hit>
- [ ] **<short label>** — <...>
- [ ] **<short label>** — <...>
- [ ] **<short label>** — <...>
- [ ] **<short label>** — <...>
- [ ] **<short label>** — <...>

## Reference output

<5–20 line exemplar showing what a quality response at this skill's depth looks like.
Not a byte-exact target — a shape and density reference.>

## Notes

<Optional: what this eval is meant to catch; what kind of regression it surfaces.>
