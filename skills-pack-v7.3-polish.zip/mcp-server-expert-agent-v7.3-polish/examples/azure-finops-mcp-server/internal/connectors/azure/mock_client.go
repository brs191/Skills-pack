package azure

import (
	"context"

	costservice "github.com/example/azure-finops-mcp-server/internal/services/cost"
)

type MockCostClient struct{}

func NewMockCostClient() *MockCostClient { return &MockCostClient{} }

func (m *MockCostClient) GetCostSummary(ctx context.Context, req costservice.CostSummaryRequest) (costservice.CostSummary, error) {
	return costservice.CostSummary{
		SubscriptionID: req.SubscriptionID,
		Currency:       "USD",
		TotalCost:      18420.75,
		Granularity:    req.Granularity,
		Items: []costservice.CostBreakdown{
			{Service: "Virtual Machines", ResourceGroup: "rg-prod-app", Cost: 7210.40},
			{Service: "Azure SQL", ResourceGroup: "rg-prod-data", Cost: 4620.25},
			{Service: "Storage", ResourceGroup: "rg-shared", Cost: 2190.10},
		},
	}, nil
}

func (m *MockCostClient) FindIdleResources(ctx context.Context, subscriptionID string, lookbackDays string) ([]costservice.IdleResource, error) {
	return []costservice.IdleResource{
		{ResourceID: "/subscriptions/xxx/resourceGroups/rg-dev/providers/Microsoft.Compute/virtualMachines/dev-vm-01", ResourceType: "Virtual Machine", ResourceGroup: "rg-dev", EstimatedMonthlyRun: 310.50, Reason: "CPU below 3% for most of the lookback window", Recommendation: "Stop, resize, or schedule shutdown after owner validation"},
		{ResourceID: "/subscriptions/xxx/resourceGroups/rg-test/providers/Microsoft.Network/publicIPAddresses/pip-unused-01", ResourceType: "Public IP", ResourceGroup: "rg-test", EstimatedMonthlyRun: 18.00, Reason: "No attached resource found", Recommendation: "Delete after dependency validation"},
	}, nil
}

func (m *MockCostClient) DetectCostAnomalies(ctx context.Context, subscriptionID, fromDate, toDate string) ([]costservice.CostAnomaly, error) {
	return []costservice.CostAnomaly{
		{Service: "Azure SQL", ResourceGroup: "rg-prod-data", DeltaPercent: 38.4, EstimatedImpact: 920.20, Explanation: "Spend increased after SKU change or workload spike"},
	}, nil
}
