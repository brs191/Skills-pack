package snippets

import (
	"os"
	"github.com/mark3labs/mcp-go/server"
)

func Serve(s *server.MCPServer) error {
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	switch os.Getenv("MCP_TRANSPORT") {
	case "streamablehttp":
		return server.NewStreamableHTTPServer(s).Start(":" + port)
	case "sse":
		return server.NewSSEServer(s).Start(":" + port)
	default:
		return server.ServeStdio(s)
	}
}
