package observability

import (
	"context"
	"testing"
)

func TestServicePrimaryFlow(t *testing.T) {
	svc := NewService(NewMockClient())
	out, err := svc.Primary(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if out == "" {
		t.Fatal("expected non-empty output")
	}
}
