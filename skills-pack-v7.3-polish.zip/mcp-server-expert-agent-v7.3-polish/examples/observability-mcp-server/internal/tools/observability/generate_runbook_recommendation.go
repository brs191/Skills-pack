package observability

import (
	"context"
	"encoding/json"

	"github.com/example/observability-mcp-server/internal/audit"
	"github.com/example/observability-mcp-server/internal/policy"
	observabilitysvc "github.com/example/observability-mcp-server/internal/services/observability"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerGenerateRunbookRecommendation(s *server.MCPServer, svc *observabilitysvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	tool := mcp.NewTool("generate_runbook_recommendation",
		mcp.WithDescription("Execute read-only generate_runbook_recommendation capability"),
		mcp.WithString("tenant_id", mcp.Description("Tenant ID; defaults to tenant-example")),
	)
	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		tenantID := req.GetString("tenant_id", "tenant-example")
		decision := policyEngine.Authorize(policy.Request{Tool: "generate_runbook_recommendation", TenantID: tenantID, Risk: policy.RiskLow})
		if !decision.Allowed {
			return mcp.NewToolResultError(decision.Reason), nil
		}
		out, err := svc.Execute(ctx, "generate_runbook_recommendation")
		if err != nil {
			return mcp.NewToolResultError(err.Error()), nil
		}
		auditor.Record(ctx, audit.Event{Tool: "generate_runbook_recommendation", Status: "success", Risk: "low", TenantID: tenantID})
		b, _ := json.MarshalIndent(out, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})
}
