# MCP Resource Catalog for System Design Capability

## Pattern Resources
- patterns://microservices/saga
- patterns://microservices/cqrs
- patterns://microservices/api-gateway
- patterns://microservices/transactional-outbox
- patterns://microservices/database-per-service

## Azure Resources
- patterns://azure/aks-microservices
- patterns://azure/container-apps-microservices
- patterns://azure/service-bus-saga
- patterns://azure/apim-api-gateway
- patterns://azure/monitor-opentelemetry

## Templates
- templates://architecture/adr
- templates://architecture/service-boundary-canvas
- templates://architecture/event-contract
- templates://architecture/api-contract

## Rubrics
- rubrics://microservices/system-design
