# Event Contract Template

## Event Name

## Owning Service

## Business Meaning

Describe what happened in business language. Events should represent facts, not commands.

## Topic / Queue

## Version

## Schema

```json
{
  "eventId": "uuid",
  "eventType": "DomainEventName",
  "eventVersion": "1.0",
  "occurredAt": "2026-05-12T00:00:00Z",
  "correlationId": "uuid",
  "causationId": "uuid",
  "tenantId": "tenant-id",
  "payload": {}
}
```

## Producers

| Producer | Reason for publishing |
|---|---|

## Consumers

| Consumer | Reason for consuming | Idempotent? | Failure behavior |
|---|---|---|---|

## Delivery Semantics

- At-least-once / exactly-once illusion / best effort:
- Ordering requirement:
- Duplicate handling:
- Dead-letter behavior:

## Compatibility Rules

- Additive changes only:
- Required fields:
- Deprecated fields:
- Version migration strategy:

## Security and Compliance

- Data classification:
- PII present:
- Encryption:
- Retention:

## Observability

- Correlation fields:
- Metrics:
- Alerts:

## Azure Implementation Notes

- Azure Service Bus / Event Grid / Event Hubs:
- DLQ configuration:
- Retry policy:
