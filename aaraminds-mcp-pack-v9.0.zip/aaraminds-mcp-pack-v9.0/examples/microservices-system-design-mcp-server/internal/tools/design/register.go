// Package design registers the existing design-review MCP tools.
//
// Migrated in session 3 to the logger-bearing registration signature used by
// boundary, archrisks, and the other architecture tools, so every tool
// package emits the same structured tool-call events.
package design

import (
	"context"
	"encoding/json"
	"log/slog"
	"strings"

	designsvc "github.com/example/microservices-system-design-mcp-server/internal/services/design"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

// Register wires the design-review tools into the MCP server.
//
// Logger is used for structured tool-call events (start, completion, error),
// matching the registration pattern established by the boundary tool.
func Register(s *server.MCPServer, svc *designsvc.Service, logger *slog.Logger) {
	review := mcp.NewTool("review_microservice_design",
		mcp.WithDescription("Review a microservices system design for Azure cloud readiness"),
		mcp.WithString("system_name", mcp.Required(), mcp.Description("Name of the system")),
		mcp.WithString("business_capability", mcp.Description("Business capability being designed")),
		mcp.WithString("deployment_target", mcp.Description("AKS, Container Apps, App Service, or hybrid")),
		mcp.WithString("services", mcp.Description("Comma-separated proposed services")),
	)
	s.AddTool(review, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		logger.Info("tool call started", slog.String("tool", "review_microservice_design"))
		name, err := req.RequireString("system_name")
		if err != nil {
			logger.Info("tool call rejected",
				slog.String("tool", "review_microservice_design"),
				slog.String("error", "system_name is required"),
			)
			return mcp.NewToolResultError("system_name is required"), nil
		}
		capability := req.GetString("business_capability", "")
		deployment := req.GetString("deployment_target", "")
		servicesRaw := req.GetString("services", "")
		services := []string{}
		if servicesRaw != "" {
			services = strings.Split(servicesRaw, ",")
		}
		res := svc.Review(designsvc.ReviewInput{SystemName: name, BusinessCapability: capability, DeploymentTarget: deployment, Services: services})
		b, err := json.MarshalIndent(res, "", "  ")
		if err != nil {
			logger.Error("failed to marshal result",
				slog.String("tool", "review_microservice_design"),
				slog.String("error", err.Error()),
			)
			return mcp.NewToolResultError("internal error: failed to format result"), nil
		}
		logger.Info("tool call completed",
			slog.String("tool", "review_microservice_design"),
			slog.String("system", name),
		)
		return mcp.NewToolResultText(string(b)), nil
	})

	recommend := mcp.NewTool("recommend_microservice_patterns",
		mcp.WithDescription("Recommend microservices patterns based on a problem statement"),
		mcp.WithString("problem", mcp.Required(), mcp.Description("Problem statement or design challenge")),
	)
	s.AddTool(recommend, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		logger.Info("tool call started", slog.String("tool", "recommend_microservice_patterns"))
		problem, err := req.RequireString("problem")
		if err != nil {
			logger.Info("tool call rejected",
				slog.String("tool", "recommend_microservice_patterns"),
				slog.String("error", "problem is required"),
			)
			return mcp.NewToolResultError("problem is required"), nil
		}
		b, err := json.MarshalIndent(map[string]any{"patterns": svc.RecommendPatterns(problem)}, "", "  ")
		if err != nil {
			logger.Error("failed to marshal result",
				slog.String("tool", "recommend_microservice_patterns"),
				slog.String("error", err.Error()),
			)
			return mcp.NewToolResultError("internal error: failed to format result"), nil
		}
		logger.Info("tool call completed", slog.String("tool", "recommend_microservice_patterns"))
		return mcp.NewToolResultText(string(b)), nil
	})

	score := mcp.NewTool("score_well_architected_readiness",
		mcp.WithDescription("Score a microservices design against Azure Well-Architected style pillars"),
		mcp.WithString("system_name", mcp.Required(), mcp.Description("System name")),
	)
	s.AddTool(score, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		logger.Info("tool call started", slog.String("tool", "score_well_architected_readiness"))
		name, err := req.RequireString("system_name")
		if err != nil {
			logger.Info("tool call rejected",
				slog.String("tool", "score_well_architected_readiness"),
				slog.String("error", "system_name is required"),
			)
			return mcp.NewToolResultError("system_name is required"), nil
		}
		b, err := json.MarshalIndent(svc.ScoreWellArchitected(), "", "  ")
		if err != nil {
			logger.Error("failed to marshal result",
				slog.String("tool", "score_well_architected_readiness"),
				slog.String("error", err.Error()),
			)
			return mcp.NewToolResultError("internal error: failed to format result"), nil
		}
		logger.Info("tool call completed",
			slog.String("tool", "score_well_architected_readiness"),
			slog.String("system", name),
		)
		return mcp.NewToolResultText(string(b)), nil
	})
}
