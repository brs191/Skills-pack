package security

import "strings"

var sensitiveMarkers = []string{"password", "secret", "token", "apikey", "api_key", "authorization"}

func Redact(value string) string {
	lower := strings.ToLower(value)
	for _, marker := range sensitiveMarkers {
		if strings.Contains(lower, marker) {
			return "[REDACTED]"
		}
	}
	return value
}
