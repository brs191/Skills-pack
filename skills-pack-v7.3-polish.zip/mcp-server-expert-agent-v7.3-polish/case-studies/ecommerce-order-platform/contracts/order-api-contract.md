# API Contract — Order Service

## POST /orders

Create a new order.

### Request

```json
{
  "customerId": "cust-123",
  "cartId": "cart-456",
  "paymentMethodId": "pm-789",
  "shippingAddressId": "addr-101"
}
```

### Response

```json
{
  "orderId": "ord-1001",
  "status": "PENDING_CONFIRMATION",
  "createdAt": "2026-05-12T09:00:00Z"
}
```

## GET /orders/{orderId}

Returns order status and summary.
