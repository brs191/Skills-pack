# ADR: Use Saga with Transactional Outbox for Order Workflow

## Status
Accepted for MVP with implementation guardrails.

## Context
The order workflow spans order capture, inventory reservation, payment authorization, and notification. Each service must own its data, so a distributed database transaction is not appropriate.

## Decision
Use a Saga pattern coordinated through durable messages. Each service performs a local transaction and publishes events using a Transactional Outbox.

## Options Considered

| Option | Pros | Cons |
|---|---|---|
| Distributed transaction | Strong consistency | Poor cloud fit, operational complexity |
| Single checkout service | Simpler MVP | Weak boundaries, limited scale independence |
| Saga + Outbox | Cloud-native, resilient, auditable | Requires idempotency and compensation logic |

## Consequences

- Services remain independently deployable.
- Eventual consistency must be visible in product and operations.
- Compensation and timeout rules must be implemented explicitly.
- Observability must include correlation IDs across all workflow steps.

## Azure Services

- Azure Service Bus
- Cosmos DB
- Azure Monitor
- OpenTelemetry

