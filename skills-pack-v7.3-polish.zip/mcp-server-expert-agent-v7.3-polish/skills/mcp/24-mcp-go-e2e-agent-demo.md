# Skill — MCP-Go End-to-End Agent Demo

## Purpose

Create end-to-end demo flows where an AI agent safely consumes MCP tools.

## Use When

The user asks for:
- LangGraph + MCP demo
- end-to-end MCP flow
- agent workflow using MCP tools
- leadership demo flow
- technical demo flow

## Default Flow Pattern

```text
User question
  ↓
Agent classifies intent
  ↓
Agent selects read-only MCP tools first
  ↓
MCP server validates policy and input
  ↓
MCP server returns bounded structured output
  ↓
Agent synthesizes answer
  ↓
Agent asks for approval before high-risk action
```

## Required Demo Artifacts

For every end-to-end demo, include:

1. Scenario
2. Agent steps
3. MCP tools used
4. Mock input
5. Mock output
6. Approval boundary
7. Failure path
8. Security notes

## Safety Rule

The demo must not show an agent directly executing production changes. Any remediation must be recommendation-only unless a human approval gate is explicitly present.
