# Skill — MCP-Go Prompts

## Purpose

Create reusable MCP prompts for domain-specific agent workflows.

## Principle

Prompts guide reasoning. Tools execute actions. Resources provide context.

## Prompt Examples

```text
review_cloud_cost_optimization
summarize_incident_root_cause
analyze_network_topology_risk
create_deployment_failure_report
generate_architecture_review
```

## Prompt Template

```markdown
# Prompt Name

## Purpose

## Required Inputs

## Optional Inputs

## System Guidance

## User Message Template

## Expected Output Format

## Safety Constraints
```

## Safety Rules

- Do not ask the model to invent missing infrastructure.
- Ask for assumptions explicitly.
- Separate facts from recommendations.
- Mark high-risk recommendations clearly.
- Require human approval for infrastructure-changing actions.
