# Microservices System Design Router

Use this router when the request is about system design, distributed systems, Azure-hosted microservices, service boundaries, patterns, resilience, observability, security, or architecture review.

## Core design routing

| Need | Use |
|---|---|
| Pattern selection | `28-microservices-pattern-selection.md` |
| Azure service mapping | `29-azure-cloud-native-patterns.md` |
| Data ownership and consistency | `30-microservices-data-patterns.md` |
| Sync/async communication | `31-microservices-communication-patterns.md` |
| Reliability and resilience | `32-microservices-resilience-patterns.md` |
| Observability | `33-microservices-observability-patterns.md` |
| Security | `34-microservices-security-patterns.md` |
| Deployment topology | `35-microservices-deployment-patterns.md` |
| Architecture review | `36-microservices-system-design-review.md` |
| Architecture generation | `37-microservices-architecture-generation.md` |

## Accelerator routing

| Need | Use |
|---|---|
| Case-study generation | `../accelerator/38-microservices-case-study-generation.md` |
| Diagram-ready output | `../accelerator/39-diagram-ready-architecture-output.md` |
| Well-Architected scoring | `../accelerator/40-azure-well-architected-scoring.md` |
| Architecture MCP tool execution | `../accelerator/41-mcp-architecture-tool-execution.md` |
| Demo workflow | `../accelerator/42-one-command-demo-workflow.md` |
| Golden validation | `../accelerator/43-golden-output-validation.md` |
| Architecture-board pack | `../accelerator/44-architecture-board-presentation-pack.md` |
| Adoption packaging | `../accelerator/45-agent-packaging-and-adoption.md` |
| Executive-to-engineering translation | `../accelerator/46-executive-to-engineering-translation.md` |
| Acceptance gates | `../accelerator/47-architecture-acceptance-gates.md` |

## Required reasoning sequence

1. Start from business capability, not technology.
2. Define service boundaries and data ownership.
3. Select communication patterns only after workflow shape is clear.
4. Add resilience, security, and observability before deployment decisions.
5. Map to Azure services with trade-offs.
6. Generate ADRs for major choices.
7. Score readiness and identify acceptance gates.

Never recommend microservices blindly. If a modular monolith is more practical, say so.
