# Business Capabilities

| Capability | Description | Candidate Service |
|---|---|---|
| Product discovery | Product listing, search, product details | Catalog Service |
| Cart management | Add/remove items, calculate cart totals | Cart Service |
| Order placement | Create order, coordinate order lifecycle | Order Service |
| Inventory reservation | Reserve and release stock | Inventory Service |
| Payment authorization | Authorize/capture/refund payments | Payment Service |
| Shipping fulfillment | Create shipment and track delivery | Shipping Service |
| Customer notification | Email/SMS/push notifications | Notification Service |
| Customer identity | Sign-in, customer profile | Identity/Profile Service |
| Operational reporting | Order, payment, inventory analytics | Reporting Service |

## Boundary Rule

Each service owns a business capability and its data. Services should not share databases.
