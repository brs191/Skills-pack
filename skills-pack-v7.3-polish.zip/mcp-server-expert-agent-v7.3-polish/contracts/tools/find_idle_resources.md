# Tool Contract — find_idle_resources

## Version
v1

## Purpose
Find likely idle Azure resources based on utilization and cost signals.

## Risk Level
Low for read-only analysis. High if later connected to deletion/resize actions.

## Approval Required
No for analysis. Mandatory for any remediation.

## Inputs
- subscription_id: required string
- lookback_days: optional integer, default 30
- min_monthly_cost: optional number

## Output
List of candidate resources with evidence, estimated waste, and confidence.
