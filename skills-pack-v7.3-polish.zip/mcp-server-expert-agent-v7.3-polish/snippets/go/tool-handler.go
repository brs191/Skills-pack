package snippets

import (
	"context"
	"github.com/mark3labs/mcp-go/mcp"
)

// ToolHandlerPattern shows the intended handler shape.
func ToolHandlerPattern(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	value, err := req.RequireString("value")
	if err != nil {
		return mcp.NewToolResultError("value is required"), nil
	}

	if value == "" {
		return mcp.NewToolResultError("value cannot be empty"), nil
	}

	return mcp.NewToolResultText("ok"), nil
}
