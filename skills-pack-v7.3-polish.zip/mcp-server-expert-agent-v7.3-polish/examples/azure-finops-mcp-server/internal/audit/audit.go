package audit

import (
	"context"
	"encoding/json"
	"fmt"
	"time"
)

type Event struct {
	Tool      string    `json:"tool"`
	Status    string    `json:"status"`
	Risk      string    `json:"risk"`
	TenantID  string    `json:"tenant_id,omitempty"`
	Timestamp time.Time `json:"timestamp"`
}

type Auditor interface{ Record(context.Context, Event) }

type StdoutAuditor struct{}

func NewStdoutAuditor() *StdoutAuditor { return &StdoutAuditor{} }

func (a *StdoutAuditor) Record(ctx context.Context, event Event) {
	event.Timestamp = time.Now().UTC()
	b, _ := json.Marshal(event)
	fmt.Printf("audit=%s\n", string(b))
}
