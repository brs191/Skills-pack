# MCP Tools

## health_check

Checks whether the server is healthy.

## get_cost_summary

Gets Azure cost summary for a subscription and date range.

Risk: Low  
Approval: Not required  
Access: Subscription cost reader

## find_idle_resources

Finds potentially idle resources using mock usage/cost signals.

Risk: Low  
Approval: Not required

## detect_cost_anomalies

Detects unusual cost movements.

Risk: Low  
Approval: Not required

## generate_finops_report

Generates a summarized FinOps report from cost, idle resource, and anomaly signals.

Risk: Medium  
Approval: Not required for read-only output
