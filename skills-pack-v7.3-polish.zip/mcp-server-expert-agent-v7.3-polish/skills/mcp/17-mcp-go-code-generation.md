# Skill — MCP-Go Code Generation

## Purpose

Generate practical mcp-go code for servers, tools, resources, prompts, and deployment.

## Code Generation Rules

Always generate practical Go code, simple structure first, clear input validation, safe error messages, context-aware handlers, service layer separation, README instructions, and a test strategy.

## Do Not Generate

- Arbitrary command execution tools
- Production write actions without approval logic
- Hardcoded secrets
- Unbounded log/query tools
- Raw admin API wrappers
- Unauthenticated remote servers

## Default Server Bootstrap

```go
package mcpserver

import "github.com/mark3labs/mcp-go/server"

func NewServer() *server.MCPServer {
	s := server.NewMCPServer(
		"enterprise-mcp-server",
		"1.0.0",
		server.WithToolCapabilities(true),
		server.WithRecovery(),
	)

	RegisterTools(s)
	RegisterResources(s)
	RegisterPrompts(s)

	return s
}
```

## Default main.go

```go
package main

import (
	"fmt"
	"os"

	"github.com/example/mcp-server/internal/mcpserver"
	"github.com/mark3labs/mcp-go/server"
)

func main() {
	s := mcpserver.NewServer()
	transport := os.Getenv("MCP_TRANSPORT")
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	switch transport {
	case "sse":
		fmt.Printf("starting MCP SSE server on :%s\n", port)
		if err := server.NewSSEServer(s).Start(":" + port); err != nil {
			panic(err)
		}
	case "streamablehttp":
		fmt.Printf("starting MCP Streamable HTTP server on :%s\n", port)
		if err := server.NewStreamableHTTPServer(s).Start(":" + port); err != nil {
			panic(err)
		}
	default:
		fmt.Println("starting MCP stdio server")
		if err := server.ServeStdio(s); err != nil {
			panic(err)
		}
	}
}
```

## Default Health Tool

```go
package mcpserver

import (
	"context"

	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerHealthTool(s *server.MCPServer) {
	tool := mcp.NewTool("health_check", mcp.WithDescription("Check whether the MCP server is healthy"))

	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		return mcp.NewToolResultText("MCP server is healthy"), nil
	})
}
```
