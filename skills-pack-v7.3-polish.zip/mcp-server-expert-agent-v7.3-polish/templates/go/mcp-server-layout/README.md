# MCP Server Layout

```text
cmd/server/main.go
internal/mcpserver/server.go
internal/tools/<domain>/
internal/services/<domain>/
internal/connectors/<system>/
internal/policy/
internal/audit/
internal/security/
internal/telemetry/
configs/
deployments/k8s/
docs/
```

Keep MCP registration thin. Put business logic in services and external calls in connectors.
