# Skill — Microservices Pattern Selection

## Purpose
Select actionable microservices patterns based on system constraints.

## Pattern Selection Flow
1. Identify business capabilities and bounded contexts.
2. Identify data ownership and consistency needs.
3. Identify communication paths and latency requirements.
4. Identify failure modes and availability targets.
5. Identify security and compliance constraints.
6. Select the smallest set of patterns that solve real problems.

## Common Pattern Mapping
| Problem | Preferred Pattern | Azure Fit |
|---|---|---|
| External API governance | API Gateway | Azure API Management |
| Multiple frontend experiences | Backend for Frontend | APIM + Container Apps/AKS |
| Monolith modernization | Strangler Fig | APIM routing + phased services |
| Cross-service transaction | Saga | Service Bus + Durable Functions/AKS worker |
| Read/write scale split | CQRS | Cosmos DB/SQL + cache/projections |
| Reliable event publication | Transactional Outbox | SQL/Cosmos + Service Bus/Event Grid |
| Duplicate message handling | Idempotent Consumer | Service Bus + idempotency store |
| Failure isolation | Circuit Breaker/Bulkhead | SDK policy + service mesh |
| API versioning and throttling | API Gateway | APIM policies |
| Traceability | Distributed Tracing | OpenTelemetry + App Insights |

## Output Style
Always state why each pattern is needed, where it should be implemented, and what operational risk it introduces.
