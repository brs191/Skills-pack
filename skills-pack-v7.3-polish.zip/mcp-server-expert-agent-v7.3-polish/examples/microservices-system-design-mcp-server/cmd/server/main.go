package main

import (
    "fmt"
    "os"

    "github.com/example/microservices-system-design-mcp-server/internal/tools/architecture"
    "github.com/mark3labs/mcp-go/server"
)

func main() {
    s := server.NewMCPServer(
        "microservices-system-design-mcp-server",
        "1.0.0",
        server.WithToolCapabilities(true),
        server.WithRecovery(),
    )

    architecture.RegisterTools(s)

    transport := os.Getenv("MCP_TRANSPORT")
    port := os.Getenv("PORT")
    if port == "" { port = "8080" }

    switch transport {
    case "streamablehttp":
        if err := server.NewStreamableHTTPServer(s).Start(":" + port); err != nil { panic(err) }
    case "sse":
        if err := server.NewSSEServer(s).Start(":" + port); err != nil { panic(err) }
    default:
        fmt.Println("starting stdio MCP server")
        if err := server.ServeStdio(s); err != nil { panic(err) }
    }
}
