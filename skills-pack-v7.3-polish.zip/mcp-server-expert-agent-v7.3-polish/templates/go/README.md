# Go Shared Utility Templates

This folder contains reusable Go-oriented templates that support the standalone MCP server example repos.

The example repos intentionally duplicate small pieces of policy, audit, redaction, Docker, and CI code so each repo can be copied independently. These templates provide the source pattern to reuse when creating a new MCP server starter.

## Files

| File | Purpose |
|---|---|
| `audit.go` | Minimal audit event pattern for tool calls and policy decisions |
| `policy.go` | Basic allow/deny policy structure and risk-level handling |
| `redaction.go` | Sensitive-field redaction helper pattern |
| `github-actions-ci.yml` | CI template for Go service-layer tests and formatting checks |
| `Dockerfile` | Multi-stage Docker build template |
| `mcp-server-layout.md` | Recommended folder structure for a Go MCP server |

## Usage rule

Copy these templates into a new example repo only when needed. Keep domain-specific logic inside the repo, not inside this shared template folder.

## Version standard

Use Go `1.23.x` in CI workflows and `go 1.23` in `go.mod` unless the project explicitly requires a newer version.
