---
skill: skills/microservices/12-cost-and-tradeoffs.md
exercises_section: Cost vs. complexity vs. capability
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: cost and trade-offs

## Prompt

A team's monthly Azure bill has grown from $2,000 to $5,000 over six months. The architecture hasn't changed but the team is happy: "we're just paying for traffic growth." Pressure-test that claim by listing the categories of cost where this kind of growth often masks waste, and how you'd diagnose each.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Question the claim first** — explicitly states that "we're paying for traffic" needs proof, not assertion
- [ ] **Right-sizing** — names compute resources (vCPU, memory) that may have been over-provisioned and never tuned
- [ ] **Data store tier** — names that DB tier (DTU / vCore) is often over-sized; query patterns may not justify the tier
- [ ] **Always-on vs. scale-to-zero** — names that services running 24/7 for low-traffic-hours waste compute; scale-to-zero or Functions
- [ ] **Log / telemetry ingestion** — names that Application Insights / Log Analytics ingestion volume grows with traffic and is a major hidden cost
- [ ] **Reserved capacity** — names that long-running workloads on PAYG can save 20–40% with 1-year reservations; cost has grown because no one bought reservations
- [ ] **Concrete diagnosis** — for at least one category, names how to investigate (cost analysis by resource group, CPU utilization graphs, query tier, ingestion-volume report)

## Reference output

> "We're just paying for traffic" is the kind of claim that gets defended for a year before someone runs the numbers. Pressure-test:
>
> **1. Right-sizing.** Compute resources often get sized for peak and never tuned downward. Check: CPU and memory utilization graphs over a typical week. If services run at <30% CPU sustained, the resource allocation is over-provisioned. Container Apps and AKS both make right-sizing trivial once you measure; many teams never measure.
>
> **2. Data store tier.** Azure SQL DTU or vCore tier is sticky — chosen once, rarely re-evaluated. If query latency is well under target and DTU consumption is <50%, you're paying for a tier you don't need. Cosmos DB RUs are the same trap: provisioned RUs vs. actual consumption. Cosmos especially deserves the "are we provisioned for the right tier?" check.
>
> **3. Always-on services.** Workers and batch services often run 24/7 even though they process work for 8 hours/day. Scale-to-zero (Container Apps) or Functions can reduce compute cost by 50–66% for these. Audit: which services have steady-state low traffic and are still always-on?
>
> **4. Log and telemetry ingestion.** Application Insights and Log Analytics charge per GB ingested. With traffic growth, log volume grows proportionally — and often disproportionally, because verbose logging doesn't get trimmed as scale increases. Sampling rate may have been set high in early days when volume was low and never tightened. Check: ingestion volume per service per day; sample if any service exceeds a reasonable cap.
>
> **5. No reserved capacity.** Long-running workloads on pay-as-you-go are the easiest 20–30% savings nobody takes. If the architecture is stable and the workloads are predictable, 1-year reservations on Container Apps, Azure SQL, and Cosmos pay back fast. Check: what fraction of compute is reserved vs. PAYG?
>
> **6. Orphan resources.** Test environments left running, old dev databases, unattached disks, NAT gateways from POCs. Run Azure Advisor and the cost management "unused resources" report. Often $200–500/month of pure waste.
>
> **Diagnostic checklist**
> - Cost analysis grouped by resource group → which RG grew most? Does it match traffic?
> - CPU and memory utilization across services → any under 30% sustained?
> - Application Insights ingestion volume report → any service exceeding 1 GB/day per replica?
> - Reservations report → what's PAYG that could be reserved?
> - Advisor → unused resources, right-sizing recommendations.
>
> Run this once a quarter, even when nobody is asking. The 2.5x growth in 6 months might be partially traffic and partially waste; you can't tell without measuring.

## Notes

Catches the assumption that cost growth = traffic growth. Quarterly cost hygiene is in the skill.
