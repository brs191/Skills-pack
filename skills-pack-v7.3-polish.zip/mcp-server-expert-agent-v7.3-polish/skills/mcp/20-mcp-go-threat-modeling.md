# Skill — MCP-Go Threat Modeling

## Purpose
Threat-model MCP servers that expose enterprise capabilities to AI agents.

## Use When
The user asks for security, production readiness, enterprise governance, or high-risk tool design.

## Threat Categories

| Threat | Example | Mitigation |
|---|---|---|
| Prompt injection | Log/resource instructs agent to ignore policy | Treat tool output as untrusted, enforce policy outside the LLM |
| Tool abuse | Agent repeatedly calls expensive APIs | Rate limits, quotas, cost controls |
| Privilege escalation | User triggers admin-only tool | Per-tool RBAC and tenant checks |
| Data leakage | Tool returns secrets or PII | Output redaction and scoped queries |
| Destructive action | Agent deletes or changes production | Dry-run, approvals, rollback |
| Cross-tenant access | User queries another tenant | Tenant context enforcement |
| Over-broad resources | Resource exposes entire logs/catalog | Limit, summarize, filter |
| Supply-chain drift | SDK/API changes silently | Version policy and dependency pinning |
| Audit gaps | Action cannot be traced to actor | Structured audit logs |

## Review Questions

1. What can this MCP server access?
2. What can it change?
3. Who is allowed to call each tool?
4. What is the worst action a compromised agent could trigger?
5. Are high-risk tools blocked by approval?
6. Are secrets ever returned to the model?
7. Are logs and resources treated as untrusted input?
8. Can tool output cause another unsafe tool call?
9. Are all decisions auditable?
10. Can the action be rolled back?
