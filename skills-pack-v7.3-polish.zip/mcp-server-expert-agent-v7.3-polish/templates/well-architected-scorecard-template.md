# Well-Architected Scorecard Template

## System Name

## Review Date

| Pillar | Score | Evidence | Risks | Remediations |
|---|---:|---|---|---|
| Reliability | 0 |  |  |  |
| Security | 0 |  |  |  |
| Operational Excellence | 0 |  |  |  |
| Performance Efficiency | 0 |  |  |  |
| Cost Optimization | 0 |  |  |  |

## Overall Score

## Top 5 Risks

## Top 5 Recommended Actions
