# Pattern: Blue-Green and Canary

## Problem
Release safely with rollback and controlled exposure.

## Use When
- The problem exists in a real workflow.
- The pattern reduces coupling, improves reliability, or clarifies ownership.
- The team can operate the added complexity.

## Avoid When
Avoid unobservable canaries.

## Azure Implementation Options
Use AKS/Container Apps traffic splitting, APIM routing, Front Door, and feature flags.

## Implementation Steps
1. Define the business capability and boundary.
2. Define API/event/data contracts.
3. Implement least-privilege identity and network access.
4. Add validation, idempotency, retry/timeout behavior where applicable.
5. Add logs, metrics, traces, and alerts.
6. Add tests and deployment automation.
7. Document an ADR for the decision.

## Common Failure Modes
- Over-engineering
- Missing ownership
- Missing observability
- Missing rollback or compensation
- Security boundary unclear

## MCP Tool Opportunities
- `recommend_microservice_patterns`
- `detect_architecture_risks`
- `generate_architecture_decision_record`
- `map_patterns_to_azure_services`
