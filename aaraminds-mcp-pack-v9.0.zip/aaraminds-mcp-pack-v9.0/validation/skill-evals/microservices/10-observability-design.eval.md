---
skill: skills/microservices/10-observability-design.md
exercises_section: Three pillars; alert strategy; SLO/SLI
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: observability design

## Prompt

A new service is about to ship. The team plans to "add Application Insights" and call it done. What specific observability deliverables do you require before merge, and what failure does each prevent?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Distributed tracing with context propagation** — required because the service is one hop in a multi-service request; without it, "where did this fail" is unanswerable
- [ ] **Structured logs with correlation IDs** — required so logs from different services can be joined by trace ID; format is structured, not formatted strings
- [ ] **Domain-meaningful metrics** — required beyond CPU/memory: request rate per endpoint, latency histograms, business counters (orders placed, payments authorized)
- [ ] **Alerting on the right thresholds** — at least one critical alert (error rate > 5%, P99 > Xms, queue depth, circuit-breaker open) with on-call routing
- [ ] **SLO / SLI defined** — service has at least one declared SLO (availability or latency) with measurement method
- [ ] **No PII in logs** — explicit policy; logs derived counts and IDs, not full request bodies

## Reference output

> "Add Application Insights" is a tool choice, not an observability plan. The merge bar should be:
>
> **1. Distributed tracing with propagation.** The service emits spans for every incoming request and every outgoing call (HTTP, DB, messaging). It propagates `traceparent` headers on every outbound call so the request can be traced end-to-end across services. Without this, when something is slow, no one can answer which service caused it. OpenTelemetry SDK auto-instruments most clients; verify it works in dev before merge.
>
> **2. Structured logs.** Every log line is JSON with at minimum `timestamp, level, service, trace_id, event, ...domain_fields`. No printf-formatted strings. The trace ID joins logs to the trace; without it, log search and trace navigation are disconnected.
>
> **3. Domain-meaningful metrics.** Beyond CPU and memory (which the platform gives you free), the service emits at least: request count and latency histogram per endpoint, error count per error class, and at least one business counter (e.g., `orders_created_total`, `payment_authorizations_total`). These are what dashboards and alerts are built from; without them, you can't see anything specific to this service.
>
> **4. At least one alert.** Critical alert: error rate > 5% over 5 minutes, paging on-call. Less critical: P99 latency > target for 5 minutes (Slack ping or ticket). Without alerts, observability is "we'll know if someone complains." Each alert has a documented response in the runbook so the page is actionable.
>
> **5. SLO and SLI declared.** At minimum, availability ("99.9% of POST /orders return 2xx") and latency ("P99 < 500 ms"). Documented in code or wiki near the service. Without an SLO, "is this service healthy?" has no answer.
>
> **6. No PII in logs.** Explicit policy: do not log full request bodies, emails, account numbers. Log IDs and counts and derived classifications. This catches the most common compliance failure on launch day.
>
> **What each prevents**
> - Tracing prevents "spent two hours grepping logs to find the slow service."
> - Structured logs prevent "the search query doesn't return results in the right format."
> - Domain metrics prevent "we don't know if the business is OK, only that the CPU isn't on fire."
> - Alerts prevent "first sign of trouble was a customer support ticket."
> - SLOs prevent "we have no shared definition of 'healthy.'"
> - PII discipline prevents "the post-incident audit found PII in last week's logs."

## Notes

Catches LLMs that conflate "set up tooling" with "have observability." The merge-bar framing forces specifics.
