---
skill: skills/mcp/26-mcp-go-runnable-domain-repos.md
exercises_section: When to create a new domain repo
pass_threshold: 3/5
last_run: never
last_result: never run
---

# Eval: MCP Go runnable domain repos

## Prompt

We have one example MCP server in the pack today. A teammate wants to add a brand-new example because their feature is "different enough." How do you decide whether they should create a new domain repo or add to the existing one?

## Rubric

A response passes if it covers at least 3 of the following 5 points:

- [ ] **Default: extend the existing example** — if the new tool fits the domain, add it; don't fork
- [ ] **Spin up new only for genuinely new domain** — different domain (security, FinOps, infrastructure) justifies a new repo; "slightly different tool" doesn't
- [ ] **Repo proliferation has a cost** — names maintenance burden, CI duplication, dependency drift
- [ ] **Each new repo must demonstrate the full pattern** — server skeleton, tool, Dockerfile, CI, README, verification checklist; otherwise it's a sketch, not a repo
- [ ] **Avoids "clean slate" framing** — a new repo for "fresh start" is rarely justified; use a branch

## Reference output

> Default is to extend the existing example. Spin up a new domain repo only when the work is genuinely a new domain.
>
> **Heuristic**
>
> Add to the existing example when:
> - The new tool fits the same domain (microservices design, in our case).
> - The patterns being demonstrated overlap substantially with what's already there.
> - The team that owns it is the same team that owns the existing example.
>
> Spin up a new repo when:
> - The domain is genuinely different (security review, Azure FinOps, infrastructure review, observability tooling).
> - The patterns the new skills require can't be demonstrated by adding to the existing example.
> - Multiple new tools share the new domain and benefit from being grouped.
>
> **Cost of proliferation**
>
> Every new repo means:
> - Another CI pipeline to maintain (Go version bumps, dependency updates, action upgrades).
> - Another Dockerfile to keep current with base-image security updates.
> - Another README to keep accurate.
> - Another set of dependencies that can drift from the canonical versions.
> - More cognitive load on readers ("which example do I look at?").
>
> If you have three near-identical examples, you don't have three references — you have one reference and two distractions.
>
> **Minimum bar for any new repo**
>
> Each new domain repo must demonstrate:
> 1. Server skeleton (stderr logging, signal-bounded shutdown, transport via env).
> 2. At least one tool with the standard package layering.
> 3. Multi-stage Dockerfile (distroless, non-root, stripped).
> 4. CI workflow (lint, vet, race, build).
> 5. README (build, run, configure, troubleshoot).
> 6. Verification checklist.
>
> If your prospective new repo lacks any of these, it's a sketch, not a domain repo. Polish before tagging.
>
> **"Clean slate" is a code smell**
>
> "I want a fresh start" is rarely a real reason. If the existing example is making the new work hard, fix the example. If you need a temporary playground, use a branch. The cost of a long-lived repo is measured in years; don't take it on lightly.

## Notes

Catches the "every feature gets its own repo" sprawl. The cost framing is the value-add.
