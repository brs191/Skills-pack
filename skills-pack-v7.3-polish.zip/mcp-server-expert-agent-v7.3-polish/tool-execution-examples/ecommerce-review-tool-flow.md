# MCP Tool Execution Example — E-Commerce Architecture Review

## User Request

Review this proposed Azure microservices architecture for an e-commerce order platform.

## Tool 1 — review_microservice_design

### Input

```json
{
  "system_name": "E-Commerce Order Platform",
  "business_capability": "Order placement and fulfillment",
  "services": ["Catalog", "Cart", "Order", "Inventory", "Payment", "Shipping", "Notification"],
  "communication": ["REST", "Azure Service Bus events"],
  "deployment_target": "Azure Container Apps or AKS",
  "non_functional_requirements": {
    "availability": "99.9% MVP, 99.95% target",
    "peak_orders_per_minute": 5000,
    "region": "India + global expansion"
  }
}
```

### Output Summary

```json
{
  "summary": "Service boundaries are business-aligned. Order workflow requires Saga, Outbox, idempotent consumers, and strong tracing.",
  "production_readiness_score": 78,
  "risks": ["distributed workflow complexity", "payment compensation gaps", "DLQ ownership missing"],
  "recommended_next_steps": ["create ADRs", "define event contracts", "add DLQ monitoring", "score against Well-Architected pillars"]
}
```

## Tool 2 — recommend_microservice_patterns

Recommended patterns:

- API Gateway
- Saga
- Transactional Outbox
- Idempotent Consumer
- Circuit Breaker
- Cache Aside
- Blue-Green/Canary Deployment
- Distributed Tracing

## Tool 3 — map_patterns_to_azure_services

| Pattern | Azure Mapping |
|---|---|
| API Gateway | Azure API Management |
| Saga | Azure Service Bus + Order Service orchestration |
| Outbox | SQL/Cosmos outbox table + worker |
| DLQ | Service Bus Dead Letter Queue |
| Distributed Tracing | OpenTelemetry + Application Insights |
| Secrets | Key Vault + Managed Identity |

## Tool 4 — generate_architecture_decision_record

Generates ADRs for APIM, Saga, Outbox, and Container Apps vs AKS.

## Tool 5 — score_well_architected_readiness

Overall result: 84/100 — Strong design, targeted hardening required.
