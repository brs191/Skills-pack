---
skill: skills/microservices/03-domain-decomposition.md
exercises_section: DDD, bounded contexts, concept ambiguity
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: domain decomposition

## Prompt

Two teams are arguing. Team A says "an Order is an order; we should have one Order service." Team B says "the order means different things in the customer-facing flow versus fulfillment versus billing; we should have separate Order entities in each context." Who's right, and how do you decide?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Team B is right** — same word, different meaning, different lifecycle = different bounded contexts
- [ ] **Concept ambiguity is the smell** — names that when one word has multiple meanings, you have multiple concepts pretending to be one
- [ ] **Distinguish concept from data** — same word may share an identifier across contexts (orderId) but each context owns its own view/projection
- [ ] **Lifecycle is the test** — different lifecycles or different responsible teams = different contexts
- [ ] **Ubiquitous language inside each context** — within one context, terms are precise; the precision is per-context, not global
- [ ] **Anti-corruption layer at the boundary** — when contexts must communicate, an explicit translation layer maps one context's "order" to another's

## Reference output

> Team B is right. When the same word means different things in different contexts, that is a strong signal you have multiple concepts pretending to be one.
>
> "Order" in the customer-facing flow is the customer's shopping intent — created at checkout, contains line items, status reflects payment and confirmation. "Order" in fulfillment is the operations team's job — references the customer order by ID but tracks pick-pack-ship state with its own lifecycle. "Order" in billing is the financial entity — references both but cares about totals, taxes, and revenue recognition with its own concerns (refunds, charge-backs).
>
> Force-fitting these into one model produces a service with three sets of fields, three responsible teams, three independent change cadences, and a schema that's a compromise none of them wanted.
>
> **How to decide.** Test with three questions:
> 1. Does the term have different meanings in different conversations? (Yes → multiple contexts.)
> 2. Do different teams modify the underlying data on different cadences? (Yes → multiple contexts.)
> 3. Does the lifecycle differ — when each "order" is created, updated, archived? (Yes → multiple contexts.)
>
> If all three are yes, you have separate bounded contexts.
>
> **What's shared across the contexts**: a stable identifier (`orderId`). What's *not* shared: schema, ownership, or lifecycle. Each context has its own projection of the order with the fields it actually cares about. When customer-facing needs to know fulfillment status, it calls fulfillment's API or subscribes to fulfillment's events — no shared table.
>
> **At the boundary**: anti-corruption layer. The customer-facing service exposes events with its own schema; the fulfillment service consumes them and translates into its model. The translation is explicit and lives in code, not in implicit shared assumptions.

## Notes

Catches the classic anti-pattern of one mega-aggregate. The "ubiquitous language" framing is the DDD canonical answer; not engaging with it suggests the LLM is doing surface-level pattern matching.
