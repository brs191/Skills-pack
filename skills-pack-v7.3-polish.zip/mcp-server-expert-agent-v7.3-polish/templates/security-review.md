# MCP Security Review Template

## Scope
Server/tool/resource/prompt reviewed.

## Data Access
What systems and data can be accessed?

## Action Surface
What systems can be changed?

## Identity and Tenant Context
How user, tenant, role, and environment are established.

## Authorization
Per-tool permission checks.

## Approval Flows
High-risk actions and required approvals.

## Input Validation
Schema, bounds, enums, and sanitization.

## Output Redaction
Secrets, PII, and sensitive fields.

## Prompt Injection Defenses
How untrusted tool/resource content is handled.

## Auditability
Events, actor, tenant, tool, result, correlation ID.

## Findings
| Severity | Finding | Risk | Fix |
|---|---|---|---|
