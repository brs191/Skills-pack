# Data Consistency Checklist

Use this checklist when reviewing a microservices design that spans multiple services, databases, or asynchronous workflows.

## Ownership

- [ ] Every service has a clearly defined data owner.
- [ ] No database is directly shared by multiple services.
- [ ] Read models are explicitly separated from write ownership.
- [ ] Reporting needs do not force transactional coupling.

## Consistency model

- [ ] Strong consistency requirements are explicitly identified.
- [ ] Eventual consistency areas are explicitly accepted by business/product stakeholders.
- [ ] User-visible stale-data behavior is documented.
- [ ] Conflict resolution rules are defined.

## Distributed workflow

- [ ] Saga or workflow boundary is documented where multiple services participate.
- [ ] Compensating actions are defined for failed business steps.
- [ ] Timeouts are defined for long-running transactions.
- [ ] Dead-letter handling is operationally owned.

## Event reliability

- [ ] Transactional Outbox is considered for critical events.
- [ ] Consumers are idempotent.
- [ ] Event IDs and correlation IDs are mandatory.
- [ ] Event versioning is defined.
- [ ] Replay and retention policy are documented.

## Validation questions

1. What happens if the message broker is unavailable?
2. What happens if a consumer processes the same event twice?
3. What happens if compensation fails?
4. How does support know the current state of a business workflow?
5. Which consistency gaps are acceptable, and which are not?
