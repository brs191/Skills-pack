# Skill — MCP-Go Transport Selection

## Purpose

Choose the right mcp-go transport for local, IDE, web, or enterprise deployment.

## Decision Matrix

| Transport | Best For | Avoid When |
|---|---|---|
| stdio | Local tools, desktop apps, IDE integrations, single-user workflows | Multi-user cloud deployment |
| SSE | Web apps, real-time push, dashboard-like clients | Simple local CLI usage |
| Streamable HTTP | Enterprise APIs, load-balanced services, Kubernetes, API gateways | Full local process behavior is required |
| In-process | Testing, embedded agent runtime | Separate deployable server is required |

## Default Recommendations

- Local developer MCP server: stdio
- VS Code / desktop local workflow: stdio
- Enterprise remote MCP server: Streamable HTTP behind API gateway
- Web dashboard or real-time interface: SSE
- Automated tests: in-process transport where practical

## Multi-Transport Pattern

```go
switch os.Getenv("MCP_TRANSPORT") {
case "sse":
	sseServer := server.NewSSEServer(s)
	return sseServer.Start(":8080")
case "streamablehttp":
	httpServer := server.NewStreamableHTTPServer(s)
	return httpServer.Start(":8080")
default:
	return server.ServeStdio(s)
}
```

## Enterprise Guidance

```text
MCP Client / Agent
    ↓
Azure API Management
    ↓
MCP Streamable HTTP Server
    ↓
Policy + Auth Layer
    ↓
Tool Execution Services
    ↓
Enterprise Systems
```
