# MCP Tools

## `get_pipeline_status`

Read-only domain tool. Risk: Low. Approval: No.

## `summarize_failed_build`

Read-only domain tool. Risk: Low. Approval: No.

## `get_recent_deployments`

Read-only domain tool. Risk: Low. Approval: No.

## `analyze_deployment_failure`

Read-only domain tool. Risk: Low. Approval: No.


## High-risk future tools

Triggering a pipeline or deploying to production must require approval.
