package mcpserver

import (
	"github.com/example/devops-mcp-server/internal/audit"
	"github.com/example/devops-mcp-server/internal/policy"
	devopssvc "github.com/example/devops-mcp-server/internal/services/devops"
	domaintools "github.com/example/devops-mcp-server/internal/tools/devops"
	"github.com/example/devops-mcp-server/internal/tools/health"
	"github.com/mark3labs/mcp-go/server"
)

func NewServer() *server.MCPServer {
	s := server.NewMCPServer("devops-mcp-server", "1.0.0", server.WithToolCapabilities(true), server.WithRecovery())
	svc := devopssvc.NewService(devopssvc.NewMockClient())
	pol := policy.NewEngine()
	aud := audit.NewStdoutAuditor()
	health.Register(s)
	domaintools.Register(s, svc, pol, aud)
	return s
}
