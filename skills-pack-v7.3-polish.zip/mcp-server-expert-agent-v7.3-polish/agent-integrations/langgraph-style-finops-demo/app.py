from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class State:
    question: str
    subscription_id: str
    from_date: str
    to_date: str
    intent: str = ""
    tool_results: Dict[str, Any] = field(default_factory=dict)
    final_answer: str = ""


class MockMCPClient:
    """Replace this with a real MCP client transport in production."""

    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if name == "get_cost_summary":
            return {
                "total_cost": 18420.75,
                "currency": "USD",
                "top_services": ["Virtual Machines", "Azure SQL", "Storage"],
            }
        if name == "detect_cost_anomalies":
            return {
                "anomalies": [
                    {"service": "Azure SQL", "delta_percent": 38.4, "impact": 920.20}
                ]
            }
        if name == "find_idle_resources":
            return {
                "idle_candidates": [
                    {"type": "Virtual Machine", "resource_group": "rg-dev", "estimated_monthly_run": 310.50},
                    {"type": "Public IP", "resource_group": "rg-test", "estimated_monthly_run": 18.00},
                ]
            }
        raise ValueError(f"Unsupported tool: {name}")


def classify_intent(state: State) -> State:
    state.intent = "finops_cost_investigation"
    return state


def get_cost_summary(state: State, client: MockMCPClient) -> State:
    state.tool_results["cost_summary"] = client.call_tool("get_cost_summary", {
        "subscription_id": state.subscription_id,
        "from_date": state.from_date,
        "to_date": state.to_date,
        "granularity": "daily",
    })
    return state


def detect_anomalies(state: State, client: MockMCPClient) -> State:
    state.tool_results["anomalies"] = client.call_tool("detect_cost_anomalies", {
        "subscription_id": state.subscription_id,
        "from_date": state.from_date,
        "to_date": state.to_date,
    })
    return state


def find_idle_resources(state: State, client: MockMCPClient) -> State:
    state.tool_results["idle_resources"] = client.call_tool("find_idle_resources", {
        "subscription_id": state.subscription_id,
        "lookback_days": "30",
    })
    return state


def generate_answer(state: State) -> State:
    summary = state.tool_results["cost_summary"]
    anomalies = state.tool_results["anomalies"]["anomalies"]
    idle = state.tool_results["idle_resources"]["idle_candidates"]

    state.final_answer = (
        f"Cost for the period is {summary['currency']} {summary['total_cost']}. "
        f"The strongest anomaly is {anomalies[0]['service']} with a {anomalies[0]['delta_percent']}% increase. "
        f"There are {len(idle)} idle-resource candidates. No action has been taken; cleanup or resizing requires human approval."
    )
    return state


def run() -> None:
    client = MockMCPClient()
    state = State(
        question="Why did Azure cost increase this week?",
        subscription_id="sub-example",
        from_date="2026-05-01",
        to_date="2026-05-07",
    )

    for step in [
        classify_intent,
        lambda s: get_cost_summary(s, client),
        lambda s: detect_anomalies(s, client),
        lambda s: find_idle_resources(s, client),
        generate_answer,
    ]:
        state = step(state)

    print(state.final_answer)


if __name__ == "__main__":
    run()
