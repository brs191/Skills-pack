# MCP Tool Contract Template

## Tool Name
`<tool_name>`

## Version
`v1`

## Purpose
One sentence describing the business intent.

## When To Use
When an agent should call this tool.

## When Not To Use
When this tool would be unsafe or incorrect.

## Input Schema

| Field | Type | Required | Validation | Description |
|---|---|---:|---|---|
| `<field>` | string | yes | non-empty | `<description>` |

## Output Schema

```json
{
  "status": "success",
  "data": {}
}
```

## Risk Level
Low / Medium / High / Critical

## Permissions
Required roles/scopes.

## Approval Required
No / Yes / Conditional.

## Audit Event
`mcp.tool.<tool_name>.called`

## Failure Modes
- invalid_input
- unauthorized
- backend_unavailable
- timeout

## Example Call

```json
{}
```

## Example Response

```json
{}
```
