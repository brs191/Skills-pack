package policy

import "context"

type RiskLevel string

const (
	RiskLow      RiskLevel = "low"
	RiskMedium   RiskLevel = "medium"
	RiskHigh     RiskLevel = "high"
	RiskCritical RiskLevel = "critical"
)

type Request struct {
	UserID           string
	TenantID         string
	Tool             string
	Risk             RiskLevel
	ApprovalProvided bool
	Scopes           []string
}

type Decision struct {
	Allowed bool
	Reason  string
}

type Evaluator interface {
	Evaluate(ctx context.Context, req Request) Decision
}

type DefaultEvaluator struct{}

func (DefaultEvaluator) Evaluate(ctx context.Context, req Request) Decision {
	if req.UserID == "" || req.TenantID == "" {
		return Decision{Allowed: false, Reason: "missing identity or tenant context"}
	}
	if req.Risk == RiskHigh || req.Risk == RiskCritical {
		if !req.ApprovalProvided {
			return Decision{Allowed: false, Reason: "approval required for high-risk tool"}
		}
	}
	return Decision{Allowed: true, Reason: "allowed"}
}
