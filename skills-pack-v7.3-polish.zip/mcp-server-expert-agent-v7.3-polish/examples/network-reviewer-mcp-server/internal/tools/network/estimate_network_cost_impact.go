package network

import (
	"context"
	"encoding/json"

	"github.com/example/network-reviewer-mcp-server/internal/audit"
	"github.com/example/network-reviewer-mcp-server/internal/policy"
	networksvc "github.com/example/network-reviewer-mcp-server/internal/services/network"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerEstimateNetworkCostImpact(s *server.MCPServer, svc *networksvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	tool := mcp.NewTool("estimate_network_cost_impact",
		mcp.WithDescription("Execute read-only estimate_network_cost_impact capability"),
		mcp.WithString("tenant_id", mcp.Description("Tenant ID; defaults to tenant-example")),
	)
	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		tenantID := req.GetString("tenant_id", "tenant-example")
		decision := policyEngine.Authorize(policy.Request{Tool: "estimate_network_cost_impact", TenantID: tenantID, Risk: policy.RiskLow})
		if !decision.Allowed {
			return mcp.NewToolResultError(decision.Reason), nil
		}
		out, err := svc.Execute(ctx, "estimate_network_cost_impact")
		if err != nil {
			return mcp.NewToolResultError(err.Error()), nil
		}
		auditor.Record(ctx, audit.Event{Tool: "estimate_network_cost_impact", Status: "success", Risk: "low", TenantID: tenantID})
		b, _ := json.MarshalIndent(out, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})
}
