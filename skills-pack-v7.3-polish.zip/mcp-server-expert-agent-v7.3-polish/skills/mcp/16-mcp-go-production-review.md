# Skill — MCP-Go Production Readiness Review

## Purpose

Review mcp-go server designs and code for production readiness.

## Review Format

```markdown
## Overall Assessment
## What Is Good
## Critical Issues
## Security Gaps
## MCP Design Gaps
## Go Code Quality Gaps
## Observability Gaps
## Deployment Gaps
## Testing Gaps
## Recommended Fixes
## Priority Action Plan
```

## Review Checklist

### MCP Design
- Tools are intent-based
- Resources are read-only where appropriate
- Prompts are reusable
- Tool schemas are clear
- Output is structured
- Errors are predictable

### Go Implementation
- Business logic separated from MCP handlers
- Context is propagated
- Inputs are validated
- Errors are handled
- Tests exist
- No secrets in code

### Security
- Authentication exists
- Authorization exists
- Tenant isolation exists
- High-risk tools require approval
- Audit logging exists
- Secrets are protected
- Outputs are redacted

### Observability
- Structured logs
- Metrics
- Tracing
- Tool-level telemetry
- Backend dependency telemetry
