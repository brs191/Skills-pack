# Example Repo Status

| Repo | Purpose | Current status | Build notes | Best use |
|---|---|---|---|---|
| `examples/azure-finops-mcp-server/` | Azure cost, idle resource, and FinOps reporting MCP starter | Starter repo | Run `go mod tidy` before full MCP build | Copy as the base for Azure cost intelligence tools |
| `examples/devops-mcp-server/` | Pipeline, deployment, and DevOps automation MCP starter | Starter repo | Run `go mod tidy` before full MCP build | Copy for GitHub/Azure DevOps integrations |
| `examples/observability-mcp-server/` | Logs, metrics, incidents, and observability MCP starter | Starter repo | Run `go mod tidy` before full MCP build | Copy for Grafana/Azure Monitor style integrations |
| `examples/network-reviewer-mcp-server/` | Azure network topology and risk review MCP starter | Starter repo | Run `go mod tidy` before full MCP build | Copy for network architecture review use cases |
| `examples/microservices-system-design-mcp-server/` | Architecture review and Well-Architected scoring MCP starter | Architecture intelligence starter | Service-layer tests are local; full MCP build requires dependencies | Use for architecture review tool implementation |

## Status terms

- **Starter repo**: structured implementation base with MCP wiring, service layers, policy/audit/security examples, CI/Docker/Kubernetes samples, and docs.
- **Architecture intelligence starter**: a specialized MCP starter focused on architecture review and scoring tools.
- **Full MCP build requires dependencies**: run `go mod tidy` with network access to resolve `github.com/mark3labs/mcp-go`.
