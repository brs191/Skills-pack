# Example: E-Commerce Order Platform on Azure

## Services
- Order Service
- Payment Service
- Inventory Service
- Shipping Service
- Notification Service

## Patterns
- API Gateway with APIM
- Saga for order workflow
- Transactional Outbox for events
- Idempotent Consumer for payment and inventory commands
- CQRS for order query views
- Distributed tracing with OpenTelemetry

## Azure Mapping
- APIM for API gateway
- AKS or Container Apps for services
- Service Bus for workflow commands/events
- Cosmos DB or Azure SQL per service
- Redis for hot reads
- Key Vault + Managed Identity for secrets
- Azure Monitor + App Insights for observability
