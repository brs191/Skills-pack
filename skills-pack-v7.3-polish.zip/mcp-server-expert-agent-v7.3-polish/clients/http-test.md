# HTTP Test Notes

This file gives practical notes for testing HTTP-based MCP server deployments.

## Scope

The example MCP servers are primarily starter repos. Full HTTP testing requires dependency resolution, server startup, and a compatible MCP client.

## Suggested checks

| Check | Purpose |
|---|---|
| Health endpoint | Confirm container/server is reachable |
| Auth middleware | Confirm unauthorized requests are denied |
| Tool call path | Confirm MCP requests reach the intended handler |
| CORS policy | Confirm only approved origins are allowed |
| Rate limits | Confirm abusive calls are throttled |
| Trace ID propagation | Confirm requests can be followed across services |

## Example workflow

```bash
# 1. Resolve dependencies
cd examples/microservices-system-design-mcp-server
go mod tidy

# 2. Start server using Streamable HTTP when implemented
MCP_TRANSPORT=streamablehttp PORT=8080 go run ./cmd/server

# 3. Use an MCP-compatible client or integration test harness
```

## Important note

The offline architecture review demo under `demo/architecture-review-demo/` does not use HTTP. It validates generated architecture outputs against golden files.
