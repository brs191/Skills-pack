# draw.io Prompt — E-Commerce Microservices on Azure

Create a clean enterprise architecture diagram with white background.

Sections:
1. Client Layer: Web, Mobile, Admin Portal
2. Edge Layer: Azure Front Door + WAF, Azure API Management
3. Runtime Layer: AKS or Azure Container Apps with Catalog, Cart, Order, Inventory, Payment, Shipping, Notification services
4. Messaging Layer: Azure Service Bus Topics/Queues with DLQ
5. Data Layer: Cosmos DB, Azure SQL, Redis
6. Security Layer: Entra ID, Managed Identity, Key Vault
7. Observability Layer: Azure Monitor, Application Insights, OpenTelemetry

Show arrows for request flow and event flow. Use different line styles for sync API calls and async events. Keep labels short and readable.
