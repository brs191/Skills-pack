# Roadmap — v9.0 onward

## Current release

**v9.0 — May 2026 — Quality 9.0+ with evidence**

v9.0 is the consolidated, standalone release. Everything the pack offers is in one tree; there are no required dependencies on prior packs.

### What v9.0 ships

| Area | Count | Notes |
|---|---|---|
| MCP-server-building skills | 22 | All operationally substantive (~150–320 lines each), with decision frameworks, anti-patterns, code |
| Microservices-design skills | 12 | DDD, boundaries, data, resilience, async, API, Azure, observability, security, cost |
| Microservices pattern cards | 21 | Pattern-specific guidance throughout; no boilerplate |
| Example MCP server | 1 (13 tools) | Builds clean, tests pass under `-race`, multi-stage distroless Dockerfile |
| End-to-end demo | 1 | Real MCP-driven, 3 architectures, byte-reproducible goldens |
| Validation prompts | 12 | Across MCP-server-building, microservices-design, architecture-review, cross-cutting |
| Per-skill evals | 34 | One per uplifted skill (12 microservices + 22 MCP) |
| Governance docs | 2 | Freshness cadence with ownership; pre-release checklist |
| **Total pack content** | **~21,700 lines** | |

### What every file passes (quality bar)

- Decision frameworks, not just bullet lists.
- Anti-patterns named with code-review-visible detection signals.
- Worked examples (code, configurations, or scenarios) at the right depth.
- Verification questions at the end of each skill.
- Cross-references between skills and pattern cards that resolve.
- No "stub" content: minimum useful depth is enforced.

### Verifiable evidence shipped

- **Example server**: builds with `go build ./...`, passes `go test -race -count=1 ./...`, image scanner clean.
- **Demo**: `make demo && make validate` returns "Validation passed: 3 architectures × 5 tools all match golden fixtures."
- **Pattern-card boilerplate check**: `grep -r "The problem exists in a real workflow" patterns/microservices/ | wc -l` returns `0`.
- **Skill evals**: 34 evals, parseable format, ready for LLM-driven scoring.

## Forward path

### Annual content review

Once per year, do an open review of the pack as a whole — exactly the cadence captured in [validation/governance/freshness-cadence.md](validation/governance/freshness-cadence.md). Questions to ask:

- Are the skills still the right shape? Should anything be split, merged, or retired?
- Are the validation prompts still discriminating? Replace any that no longer catch real failures.
- Have any pattern cards drifted from current best practice (e.g., new Azure capabilities that change the recommendation)?
- Is the example server's `go.mod` still on a supported Go version?
- Are the SDK versions in [versions.md](versions.md) still current?

### Quarterly ecosystem refresh

Every quarter, refresh the dated claims in [skills/mcp/00-ecosystem-facts.md](skills/mcp/00-ecosystem-facts.md):

- Go version (stable + recent minor).
- `mark3labs/mcp-go` and `modelcontextprotocol/go-sdk` versions.
- MCP spec version.
- Azure service capabilities and pricing claims in `09-azure-mapping.md` and `12-cost-and-tradeoffs.md`.

### Per-release validation

Before tagging any release of a fork or downstream pack derived from v9.0, walk [validation/governance/release-checklist.md](validation/governance/release-checklist.md): example server build/test, boilerplate grep, demo + validate, eval pass rate ≥ 90%, freshness currency, docs hygiene, release plumbing.

## Future scope (optional)

The pack is feature-complete for its declared scope (MCP server building + microservices design on Azure). Genuine extensions worth considering for a future v10 would be:

| Direction | What it would add | Effort |
|---|---|---|
| Multi-language SDK coverage | Python and TypeScript MCP-server skills and example servers | Substantial (separate scope) |
| Domain repos | Additional example servers for security review, FinOps, infrastructure review | One repo per domain |
| LLM-augmented variants | Tools that combine the rule engine with LLM reasoning over unstructured input | Per-tool; mixed determinism |
| Conformance test suite | Validate the example server against the MCP `conformance` spec repo | One-off |
| Hosted reference deployment | Live deployed instance of the example server with public docs | Operational; ongoing cost |

None of these are required for v9.0 to be complete; they're directions a future pack could take.

## Stability commitment

v9.0 is intended as a **stable, reusable release**. Adopters can:

- Pin to v9.0 indefinitely and run the validation pack themselves if they want continued evidence.
- Fork it, evolve it, and merge updates back upstream selectively.
- Treat the skills as documentation that ages gracefully — re-verify ecosystem facts quarterly, but the patterns and decision frameworks remain valid for years.

Breaking changes would only justify a v10 release; minor corrections or additions are appropriate as v9.x.

## Notes for adopters

- The pack is self-contained: nothing here requires consulting an earlier version.
- The example server's Go module path (`github.com/example/microservices-system-design-mcp-server`) is a placeholder; rename it to your own path when forking.
- The demo runner uses stdlib Python only; it runs anywhere Python 3.8+ is available.
- The validation pack is artifact-only; the team supplies the LLM runtime that scores the rubrics. The format is parseable for automation.
