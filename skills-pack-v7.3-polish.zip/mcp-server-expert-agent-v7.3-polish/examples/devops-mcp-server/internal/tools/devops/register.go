package devops

import (
	"github.com/example/devops-mcp-server/internal/audit"
	"github.com/example/devops-mcp-server/internal/policy"
	devopssvc "github.com/example/devops-mcp-server/internal/services/devops"
	"github.com/mark3labs/mcp-go/server"
)

func Register(s *server.MCPServer, svc *devopssvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	registerGetPipelineStatus(s, svc, policyEngine, auditor)
	registerSummarizeFailedBuild(s, svc, policyEngine, auditor)
	registerGetRecentDeployments(s, svc, policyEngine, auditor)
	registerAnalyzeDeploymentFailure(s, svc, policyEngine, auditor)
}
