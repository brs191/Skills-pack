# Microservices System Design Review Rubric

## Scoring
| Area | Weight |
|---|---:|
| Service boundaries | 15 |
| Data ownership | 15 |
| Communication design | 12 |
| Resilience | 12 |
| Security | 12 |
| Observability | 10 |
| Deployment topology | 8 |
| Scalability | 8 |
| Cost awareness | 5 |
| Operational simplicity | 3 |

## Rating Bands
| Score | Rating |
|---:|---|
| 90–100 | Production-ready with minor refinements |
| 75–89 | Strong design, needs targeted hardening |
| 60–74 | Viable, but several production gaps |
| 40–59 | High-risk design |
| <40 | Not ready for cloud microservices |

## Review Principle
A design with unclear service boundaries or shared database ownership cannot score above 74 without explicit mitigation.
