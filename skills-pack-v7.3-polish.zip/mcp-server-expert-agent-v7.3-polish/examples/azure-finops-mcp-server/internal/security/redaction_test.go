package security

import "testing"

func TestRedactsSecrets(t *testing.T) {
	cases := []string{"password=abc", "token:xyz", "api_key=123", "Authorization: Bearer abc"}
	for _, c := range cases {
		if Redact(c) != "[REDACTED]" {
			t.Fatalf("expected redaction for %q", c)
		}
	}
}

func TestAllowsNormalText(t *testing.T) {
	got := Redact("Azure SQL cost increased")
	if got != "Azure SQL cost increased" {
		t.Fatalf("unexpected redaction: %s", got)
	}
}
