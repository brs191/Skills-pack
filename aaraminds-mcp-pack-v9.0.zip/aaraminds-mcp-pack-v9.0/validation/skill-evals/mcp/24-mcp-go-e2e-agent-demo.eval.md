---
skill: skills/mcp/24-mcp-go-e2e-agent-demo.md
exercises_section: Authentic vs. theatrical demos
pass_threshold: 3/5
last_run: never
last_result: never run
---

# Eval: MCP Go end-to-end agent demo

## Prompt

A previous team shipped a "demo" that's a Python script returning a hardcoded JSON regardless of input. What's wrong with that, and what does an authentic end-to-end demo look like?

## Rubric

A response passes if it covers at least 3 of the following 5 points:

- [ ] **Theatrical demo named** — explicitly identifies the hardcoded-output demo as theatrical, not authentic
- [ ] **Authentic = real protocol** — names that an authentic demo speaks the MCP wire to a running server, not a wrapper
- [ ] **Outputs vary by input** — names that different inputs produce materially different outputs as the proof of authenticity
- [ ] **Multiple architectures** — recommends 3+ deliberately distinct architectures so the demo exercises variation
- [ ] **Goldens with refresh procedure** — outputs captured, validator compares canonically, refresh is deliberate

## Reference output

> The hardcoded-output script is the textbook theatrical demo: it looks impressive in screencasts and proves nothing. The output is the same whether the server works, doesn't work, has a bug, or hasn't even been compiled. The demo isn't a verification artifact; it's marketing.
>
> **What an authentic demo looks like**
>
> 1. **Real protocol exchange.** The demo client spawns the actual server, performs the MCP handshake, and calls `tools/call` over the wire. No imports of the service package, no wrappers — the same path a real agent would take.
>
> 2. **Realistic, distinct inputs.** Three or more architectures that differ meaningfully. The pack's reference uses e-commerce (PCI-DSS), retail banking (event-sourced ledger), and HIPAA patient platform (PHI, audit). Different services, different constraints, different patterns.
>
> 3. **Outputs that vary.** Because the server is deterministic, the same input always produces the same output. But different inputs *must* produce different outputs — boundary scores, risk counts, Azure mappings should diverge. If three architectures produce near-identical outputs, either the inputs aren't distinct or the server isn't reading them.
>
> 4. **Per-(architecture, tool) goldens.** Capture the output of each tool for each architecture once; check it into `golden/`. Future runs compare against goldens via canonical JSON (sort keys, fixed indent) so formatting drift doesn't cause false alarms.
>
> 5. **One-command refresh.** When goldens drift intentionally (a rule changed), `make refresh` promotes the new outputs. The drift must be reviewed and rationalised in the PR; never silently absorbed.
>
> 6. **Wired into CI nightly or pre-release.** The demo is the smoke test that catches end-to-end regressions. Don't run it on every PR (slow); do run it on a schedule that catches drift before it ships.
>
> The pack's reference demo at `demo/architecture-review-demo/` is the working example. A future team can build their own demo by mirroring its shape: master inputs in `input/`, demo runner in Python or another language, goldens in `golden/`, validator with canonical comparison, Makefile for orchestration.

## Notes

Catches LLMs that defend hardcoded demos as "useful for presentations" without grappling with their verification emptiness.
