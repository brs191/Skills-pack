package security

import "strings"

func Redact(value string) string {
	lower := strings.ToLower(value)
	markers := []string{"password", "secret", "token", "api_key", "authorization", "connectionstring"}
	for _, marker := range markers {
		if strings.Contains(lower, marker) {
			return "[REDACTED]"
		}
	}
	return value
}
