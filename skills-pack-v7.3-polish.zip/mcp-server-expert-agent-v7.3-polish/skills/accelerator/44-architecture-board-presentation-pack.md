# Skill — Architecture Board Presentation Pack

## Purpose

Create review-ready materials for architecture boards, engineering leadership, and delivery teams.

## Use When

The user asks for a presentation pack, architecture review summary, executive view, or technical review document.

## Output Package

```text
presentation/executive-summary.md
presentation/technical-review.md
presentation/architecture-board-review.md
presentation/leadership-one-pager.md
presentation/diagram-index.md
```

## Required Sections

1. Decision requested
2. Business context
3. Proposed architecture
4. Service boundaries
5. Key patterns and why
6. Azure service mapping
7. Top risks
8. Mitigation plan
9. Well-Architected score
10. Open decisions
11. Approval recommendation

## Tone

Clear, calm, practical, and senior. Avoid hype. Focus on decision clarity.
