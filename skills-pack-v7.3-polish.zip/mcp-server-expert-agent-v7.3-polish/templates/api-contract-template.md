# API Contract Template

## API Name

## Owning Service

## Business Capability

## Consumers

| Consumer | Internal/External | Auth model | Rate limit |
|---|---|---|---|

## Endpoint Summary

| Method | Path | Purpose | Risk | Version |
|---|---|---|---|---|

## Request Contract

```json
{
  "example": "request payload"
}
```

## Response Contract

```json
{
  "example": "response payload"
}
```

## Error Contract

| HTTP status | Error code | Meaning | Retryable |
|---:|---|---|---|
| 400 | INVALID_REQUEST | Input failed validation | No |
| 401 | UNAUTHENTICATED | Identity missing or invalid | No |
| 403 | FORBIDDEN | User lacks required permission | No |
| 409 | CONFLICT | Business conflict or idempotency conflict | Conditional |
| 429 | RATE_LIMITED | Too many requests | Yes |
| 500 | INTERNAL_ERROR | Unexpected failure | Yes |

## Idempotency

- Required: Yes / No
- Idempotency key header:
- Duplicate handling:

## Security

- Authentication:
- Authorization:
- Data classification:
- PII present:
- Audit event:

## Observability

- Log fields:
- Metrics:
- Trace spans:
- SLO/SLA impact:

## Azure Implementation Notes

- API gateway:
- Compute:
- Network boundary:
- Monitoring:
