# Microservice Design Review

## Executive Summary

## Service Boundary Assessment

## Data Ownership Assessment

## Communication Model

## Recommended Patterns

## Azure Mapping

## Risks and Mitigations

## Production Readiness Score

## Priority Actions
