# Reference Architecture — Container Apps Microservices Reference

## When to Use
Use when this architecture style directly fits the workload constraints.

## When Not to Use
Avoid when the operational complexity is not justified.

## Architecture Diagram
```text
Client
  ↓
Edge / Gateway
  ↓
Microservices Runtime
  ↓
Messaging + Data Stores
  ↓
Observability + Security + CI/CD
```

## Azure Services
- Azure API Management
- AKS or Azure Container Apps
- Azure Service Bus / Event Grid
- Cosmos DB / Azure SQL
- Key Vault + Managed Identity
- Azure Monitor + OpenTelemetry

## MCP Tools Involved
- review_microservice_design
- recommend_microservice_patterns
- map_patterns_to_azure_services
- generate_architecture_decision_record

## Security Model
Identity, least privilege, private networking, and per-service authorization.

## Observability Model
Logs, metrics, traces, dashboards, alerts, and business KPIs.

## Failure Modes
Dependency failure, message duplication, partial workflow failure, release rollback, and data projection lag.

## Cost Considerations
Right-size runtime, use autoscaling, watch messaging and database throughput, and set budgets/alerts.

## Implementation Steps
1. Define boundaries.
2. Select runtime.
3. Define contracts.
4. Implement data ownership.
5. Add messaging/resilience.
6. Add security and observability.
7. Automate deployment.
