# ADR-001 — Use Azure API Management as the API Gateway

## Status

Accepted

## Context

The e-commerce order platform exposes APIs to web, mobile, partner, and internal clients. The platform needs stable API contracts, centralized authentication, throttling, versioning, request validation, observability, and a clear boundary between public clients and private backend services.

Without an API gateway, each service would need to repeat gateway concerns independently, increasing security risk and operational inconsistency.

## Decision

Use **Azure API Management** as the external API gateway in front of public-facing microservice APIs.

Backend services remain private and are reached through controlled routing from the gateway layer.

## Options Considered

| Option | Pros | Cons |
|---|---|---|
| Direct service exposure | Simple early implementation | Weak governance, duplicated auth/policy logic, hard to version safely |
| Azure API Management | Strong API policies, throttling, products, versioning, developer portal, Entra ID integration | Additional operational component and cost |
| Application Gateway only | Good L7 ingress and WAF capability | Not enough API product/version/policy management |
| Front Door only | Strong global entry and edge routing | Not sufficient as an API governance layer by itself |

## Decision Drivers

- Centralized API security and policy enforcement
- External contract stability
- API versioning and lifecycle management
- Throttling and quota support
- Better partner/developer onboarding
- Backend service privacy
- Architecture-board reviewability

## Consequences

### Positive

- Consistent authentication and authorization policies
- Centralized rate limiting, request validation, and API versioning
- Easier API documentation and consumer onboarding
- Backend services are not directly exposed
- Better audit and observability at the API boundary

### Negative

- Adds cost and operational responsibility
- Requires API product governance
- Requires CI/CD discipline for API definitions and policies
- Gateway misconfiguration can become a platform-wide risk

## Failure Modes

- Incorrect policy allows unauthorized access
- Gateway outage impacts external traffic
- Backend routing drift between environments
- API versions remain active without ownership
- Large response payloads increase latency and cost

## Operational Impact

- APIM policies must be stored as code.
- API definitions should be version-controlled.
- Gateway metrics and logs must be monitored.
- High-risk APIs should have stricter quotas and alerting.

## Cost Impact

APIM introduces a standing platform cost. The cost is justified when API governance, external consumption, throttling, and lifecycle management are required. For very small internal-only systems, a lighter ingress pattern may be more practical.

## Azure Services Involved

- Azure API Management
- Microsoft Entra ID
- Azure Front Door or Application Gateway where needed
- Azure Monitor / Application Insights
- Azure Key Vault

## MCP Tools / Resources Impacted

- `review_microservice_design`
- `map_patterns_to_azure_services` planned
- `generate_api_contract` planned
- `score_well_architected_readiness`

## Review Date

Review during each major external API expansion or before adding new partner-facing API products.
