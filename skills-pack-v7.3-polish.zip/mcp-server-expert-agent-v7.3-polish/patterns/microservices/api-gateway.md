# Pattern: API Gateway

## Problem
Centralize external API access, security policy, rate limiting, versioning, and routing.

## Use When
- The problem exists in a real workflow.
- The pattern reduces coupling, improves reliability, or clarifies ownership.
- The team can operate the added complexity.

## Avoid When
Avoid using the gateway as a business logic layer.

## Azure Implementation Options
Use Azure API Management for external APIs; pair with Front Door/App Gateway when global edge or WAF is required.

## Implementation Steps
1. Define the business capability and boundary.
2. Define API/event/data contracts.
3. Implement least-privilege identity and network access.
4. Add validation, idempotency, retry/timeout behavior where applicable.
5. Add logs, metrics, traces, and alerts.
6. Add tests and deployment automation.
7. Document an ADR for the decision.

## Common Failure Modes
- Over-engineering
- Missing ownership
- Missing observability
- Missing rollback or compensation
- Security boundary unclear

## MCP Tool Opportunities
- `recommend_microservice_patterns`
- `detect_architecture_risks`
- `generate_architecture_decision_record`
- `map_patterns_to_azure_services`
