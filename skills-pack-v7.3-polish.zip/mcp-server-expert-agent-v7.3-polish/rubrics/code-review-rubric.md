# MCP-Go Code Review Rubric

| Area | 0 | 1 | 2 |
|---|---|---|---|
| MCP primitive choice | Incorrect | Mixed | Correct |
| Tool schema clarity | Missing | Partial | Clear |
| Input validation | None | Basic | Strong |
| Auth/RBAC | None | Coarse | Per-tool |
| Tenant isolation | None | Partial | Enforced |
| Output redaction | None | Partial | Strong |
| Audit logging | None | Partial | Complete |
| Observability | None | Basic | Logs + metrics + traces |
| Go structure | Tangled | Some separation | Clean boundaries |
| Testing | None | Unit only | Unit + contract + security |

## Rating
- 0-8: Not production ready
- 9-14: MVP only
- 15-18: Production candidate
- 19-20: Strong enterprise baseline
