# Azure Implementation Map — Cost Optimization Patterns

## Purpose
Cost controls include right sizing, autoscaling, reserved capacity, budgets, tagging, and workload-specific scaling profiles.

## Use When
- The architectural concern is present in the system.
- Azure-native implementation reduces operational burden.
- Security, reliability, cost, and observability are explicitly addressed.

## Implementation Checklist
- [ ] Identity model defined
- [ ] Network boundary defined
- [ ] Data ownership clear
- [ ] Failure handling defined
- [ ] Observability enabled
- [ ] Cost and scaling model defined
- [ ] CI/CD and rollback defined

## MCP Review Guidance
Use this map when generating Azure service recommendations, ADRs, risk reviews, and deployment topology.
