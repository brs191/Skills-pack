# API Contract — Inventory Service

## POST /inventory/reservations

Reserve inventory for an order.

### Request

```json
{
  "orderId": "ord-1001",
  "items": [
    {"sku": "SKU-1", "quantity": 2}
  ]
}
```

### Response

```json
{
  "reservationId": "res-1001",
  "status": "RESERVED"
}
```
