# Network Reviewer MCP Tool Backlog

| Tool | Purpose | Risk | Approval | Status | Test cases |
|---|---|---|---|---|---|
| `get_network_topology` | Read Azure network topology | Low | No | Implemented starter | empty subscription, no VNets, unauthorized scope |
| `detect_nsg_risks` | Identify risky NSG exposure | Low | No | Implemented starter | public SSH/RDP, broad inbound, no issues |
| `review_firewall_policy` | Review firewall and routing rules | Medium | No | Planned | conflicting rules, missing logging, high-risk outbound |
| `estimate_network_cost_impact` | Estimate cost impact of topology choices | Low | No | Planned | peering, firewall, NAT gateway, egress |
| `update_nsg_rule` | Modify NSG rule | Critical | Mandatory | Planned | dry-run, approval missing, rollback metadata |

## Implementation rules

- Keep MVP read-only.
- Require approval for route, NSG, firewall, or DNS changes.
- Always include subscription, resource group, actor, and environment in audit logs.
- Provide dry-run and rollback guidance for all write actions.
