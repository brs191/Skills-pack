# Architecture Accelerator Acceptance Gates

## Green Gate Requirements

- One-command demo runs successfully.
- Golden outputs exist for review, pattern map, scorecard, ADR, and diagram.
- Architecture-board summary is generated.
- Service boundaries are business-capability aligned.
- Azure service mapping is explicit.
- Well-Architected score is present.
- Top risks and mitigations are documented.
- ADR contains alternatives and consequences.
- Diagram output is renderable.

## Amber Gate

Proceed only if missing items are documented and assigned.

## Red Gate

Do not proceed if:

- data ownership is unclear
- destructive MCP tools lack approval
- high-risk architecture decisions lack ADRs
- observability is deferred
- security is treated as a later task
