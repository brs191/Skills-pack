# Skill — Microservices Security Patterns

## Purpose
Design secure Azure-hosted microservices.

## Security Principles
- Zero trust between services
- Managed Identity over secrets
- Least privilege per service
- Private networking where appropriate
- Central API policy for external APIs
- Workload identity for AKS
- Key Vault for secrets
- Per-service authorization, not only gateway auth

## Azure Mapping
| Concern | Azure Service/Pattern |
|---|---|
| User identity | Microsoft Entra ID |
| Service identity | Managed Identity / Workload Identity |
| API policies | Azure API Management |
| Secrets | Azure Key Vault |
| Network isolation | Private Endpoints, VNets, NSGs |
| Container security | ACR scanning, Defender for Cloud |
| Policy | Azure Policy / OPA/Gatekeeper |

## Review Questions
- Can one compromised service access all data?
- Are service identities scoped?
- Is authorization enforced at each service boundary?
- Are secrets rotated and isolated?
- Are admin operations audited?
