---
skill: skills/mcp/04-mcp-go-prompts.md
exercises_section: Prompt vs. tool; template determinism
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go prompts

## Prompt

A teammate proposes an MCP prompt called `do-deployment` that takes a service name, fetches the current Kubernetes manifest from the cluster, computes the diff against the desired state, and deploys it. Critique this design.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Prompts don't act** — names that fetching manifests, computing diffs, and deploying are *actions* and belong in tools, not prompts
- [ ] **Prompt-as-tool anti-pattern** — explicitly names that this is the most common prompt misuse
- [ ] **Prompts are deterministic** — names that pulling live cluster state into the prompt rendering breaks reproducibility
- [ ] **Recommends a tool for the action** — proposes a `deploy_service` tool with appropriate risk tier and dry-run support
- [ ] **Optional accompanying prompt** — a prompt could *guide the agent through* the deployment review (templated review checklist), but doesn't execute it
- [ ] **Clear boundary** — articulates the rule: prompts produce text from arguments; tools execute and have side effects

## Reference output

> The design conflates prompts and tools. Fetching, computing, and deploying are *actions*; the prompt is meant to be a templated text expansion, not a pipeline.
>
> **Why this is wrong**
> - **Prompts don't act.** A prompt's job is to expand a template using arguments into a deterministic text body. The moment it reaches into the cluster, the prompt has side effects (read state, possibly write state), an audit story (who called it, with what arguments), and a failure mode (cluster unavailable). All of that is tool territory.
> - **Prompt-as-tool is the most common misuse.** It feels expedient — "we just want a slash command to deploy" — but the prompt and tool layers serve different concerns. Conflating them hides the action behind the discoverability surface.
> - **Determinism breaks.** A prompt that pulls live state produces different output every call. The same `do-deployment service=payment` invocation yields different prompts at 10:00 AM and 10:05 AM. That's not a prompt; it's a workflow.
>
> **The right shape**
>
> Split into a tool and (optionally) a prompt:
>
> - **Tool: `deploy_service`** with risk tier high. Takes service name, target environment, optional `dry_run`. Returns a structured plan or executes the deploy. Audit-logged per call. Possibly two-step: a `plan_deployment` tool produces a plan ID, a `apply_deployment` tool executes by plan ID.
> - **Prompt: `review-deployment`** (optional). A discoverable command that expands into "review the deployment posture of {service} in {environment}" with template guidance to use `detect_architecture_risks` and `generate_observability_plan` as tools. The prompt is text; the tools do the work.
>
> The boundary: prompts produce text from arguments and have no side effects; tools execute, log, and may have side effects. Prompts make recurring tasks discoverable; tools make actions safe and auditable.

## Notes

Catches the prompt-as-pipeline misuse. The split is in the skill explicitly.
