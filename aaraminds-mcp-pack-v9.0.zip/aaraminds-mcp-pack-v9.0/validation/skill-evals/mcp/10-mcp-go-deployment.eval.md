---
skill: skills/mcp/10-mcp-go-deployment.md
exercises_section: Image, manifest, rollout
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go deployment

## Prompt

We're shipping our first production MCP server to Azure Container Apps. What's the minimum the Dockerfile, the deployment manifest, and the rollout plan must each do to be production-grade?

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Multi-stage Dockerfile with distroless runtime** — separate build stage, distroless static, non-root, stripped, no CGO
- [ ] **Health probes on `/healthz`, not on `/`** — calls out that the MCP wire is not a health endpoint
- [ ] **Secrets via Key Vault + Managed Identity** — no plaintext secrets in env vars or config maps
- [ ] **Resource limits based on measurement** — limits set realistically (e.g., 0.5 vCPU, 1 GiB), not arbitrary
- [ ] **Blue-green / canary rollout** — multi-revision Container Apps with traffic weights, soak period at each step
- [ ] **Documented rollback** — previous revision retained for a window, scripted rollback to instant-switch traffic back

## Reference output

> **Dockerfile (minimum bar)**
>
> Multi-stage. Build stage: `golang:1.26-alpine`, `CGO_ENABLED=0`, `-ldflags="-s -w" -trimpath`. Runtime stage: `gcr.io/distroless/static-debian12:nonroot`. Resulting image under 20 MB, non-root, no shell, no package manager.
>
> ```dockerfile
> FROM golang:1.26-alpine AS build
> WORKDIR /src
> COPY go.mod go.sum* ./
> RUN go mod download
> COPY . .
> RUN CGO_ENABLED=0 GOOS=linux go build -ldflags="-s -w" -trimpath -o /out/mcp-server ./cmd/server
>
> FROM gcr.io/distroless/static-debian12:nonroot
> COPY --from=build /out/mcp-server /usr/local/bin/mcp-server
> USER nonroot:nonroot
> EXPOSE 8080
> ENTRYPOINT ["/usr/local/bin/mcp-server"]
> ```
>
> **Deployment manifest (Container Apps)**
>
> Required:
> - `activeRevisionsMode: Multiple` so canary is possible.
> - Ingress on the streamable-HTTP port (e.g., 8080); the MCP wire is *not* the health endpoint.
> - Health probes — readiness and liveness — on `/healthz`, with periods that catch failures quickly (5–10 s).
> - Resource limits: 0.5 vCPU and 1 GiB are realistic for most MCP servers; tune based on profiling. Don't over-provision out of caution.
> - System-assigned managed identity; secrets reference Key Vault entries via the platform's secret integration.
> - Scale rules: minReplicas 1 (or 0 if scale-to-zero is acceptable), maxReplicas set to anticipated peak plus headroom.
>
> **Rollout plan**
>
> 1. Deploy `rev2` with 0% traffic.
> 2. Run smoke tests against the revision-specific URL.
> 3. Shift 10% traffic. Watch error rate, P99 latency, tool-call success-per-minute for 15–30 minutes.
> 4. Shift 50% if green. Watch again.
> 5. Shift 100% if green.
> 6. Keep `rev1` deployed for 24–72 hours as a rollback target.
> 7. Retire `rev1` only after the soak window passes.
>
> **Rollback**: a single `az containerapp ingress traffic set` command flips weights back to the previous revision. Scripted; on-call doesn't need to think.
>
> **What must not happen**
> - No secrets in env vars or config files; everything via Key Vault.
> - Health probe is not `/`; it's `/healthz` and exercises a meaningful readiness check.
> - No "fix forward only"; a rollback path is required.

## Notes

Catches LLMs that propose generic deployment without engaging with MCP-specific concerns (health endpoint vs. MCP wire, Multi revisions for rollback).
