# DevOps MCP Server

Go MCP server starter repo using `github.com/mark3labs/mcp-go`.

## Tools

- `get_pipeline_status`
- `summarize_failed_build`
- `get_recent_deployments`
- `analyze_deployment_failure`


## Run locally

```bash
go mod tidy
go run ./cmd/server
```

## Run HTTP

```bash
MCP_TRANSPORT=streamablehttp PORT=8080 go run ./cmd/server
```

## Test

```bash
go test ./...
```

## Production note

This starter uses mock connectors. Replace them with real enterprise connectors and keep policy, audit, redaction, and approval gates in place.
