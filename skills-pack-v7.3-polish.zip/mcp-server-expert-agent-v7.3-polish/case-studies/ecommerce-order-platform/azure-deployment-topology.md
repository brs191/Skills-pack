# Azure Deployment Topology

```text
Users / Mobile / Web
   ↓
Azure Front Door + WAF
   ↓
Azure API Management
   ↓
AKS or Azure Container Apps
   ├── Catalog Service → Cosmos DB
   ├── Cart Service → Redis + Cosmos DB
   ├── Order Service → Azure SQL / Cosmos DB
   ├── Inventory Service → Azure SQL / Cosmos DB
   ├── Payment Service → External PSP + Key Vault
   ├── Shipping Service → Carrier APIs
   └── Notification Service → Communication provider
   ↓
Azure Service Bus Topics / Queues
   ↓
Event Consumers + Dead Letter Queues
   ↓
Azure Monitor + Application Insights + OpenTelemetry
```

## Deployment Recommendation

- Use Azure Container Apps for a lean MVP.
- Use AKS when service mesh, advanced networking, custom autoscaling, or platform engineering maturity is required.
