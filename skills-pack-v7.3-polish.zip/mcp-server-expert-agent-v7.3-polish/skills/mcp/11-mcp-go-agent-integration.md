# Skill — MCP-Go Agent Integration

## Purpose

Integrate mcp-go servers with AI agents, LangGraph, LangChain, Copilot-like systems, and IDE clients.

## Integration Pattern

```text
User Request
  ↓
Agent Intent Understanding
  ↓
Tool Selection
  ↓
MCP Tool Call
  ↓
MCP Server Validation
  ↓
Backend Execution
  ↓
Structured Result
  ↓
Agent Reasoning
  ↓
Final Response
```

## Responsibility Split

| Layer | Responsibility |
|---|---|
| Agent | Reasoning, planning, summarization |
| MCP Server | Safe capability exposure |
| Policy Layer | Authorization and approval |
| Connector Layer | Backend API access |
| Backend System | Source of truth |

## Agent Rules

The agent should prefer read-only tools first, explain assumptions, ask for approval before high-risk actions, not invent tool results, not bypass MCP, and summarize tool output clearly.
