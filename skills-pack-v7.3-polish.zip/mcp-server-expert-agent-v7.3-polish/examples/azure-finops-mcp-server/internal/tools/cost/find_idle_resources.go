package cost

import (
	"context"
	"encoding/json"

	"github.com/example/azure-finops-mcp-server/internal/audit"
	"github.com/example/azure-finops-mcp-server/internal/policy"
	costservice "github.com/example/azure-finops-mcp-server/internal/services/cost"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func registerFindIdleResources(s *server.MCPServer, svc *costservice.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	tool := mcp.NewTool("find_idle_resources",
		mcp.WithDescription("Find potentially idle Azure resources for FinOps review"),
		mcp.WithString("subscription_id", mcp.Required(), mcp.Description("Azure subscription ID")),
		mcp.WithString("lookback_days", mcp.Description("Lookback window in days; default 30")),
	)

	s.AddTool(tool, func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		subscriptionID, err := req.RequireString("subscription_id")
		if err != nil {
			return mcp.NewToolResultError("subscription_id is required"), nil
		}
		lookbackDays := req.GetString("lookback_days", "30")

		decision := policyEngine.Authorize(policy.Request{Tool: "find_idle_resources", SubscriptionID: subscriptionID, Risk: policy.RiskLow})
		if !decision.Allowed {
			return mcp.NewToolResultError(decision.Reason), nil
		}

		out, err := svc.FindIdleResources(ctx, subscriptionID, lookbackDays)
		if err != nil {
			return mcp.NewToolResultError(err.Error()), nil
		}
		auditor.Record(ctx, audit.Event{Tool: "find_idle_resources", SubscriptionID: subscriptionID, Status: "success", Risk: "low"})
		b, _ := json.MarshalIndent(out, "", "  ")
		return mcp.NewToolResultText(string(b)), nil
	})
}
