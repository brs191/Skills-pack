# Security Model

## Identity

- Customer identity through Entra External ID or existing identity provider.
- Service-to-service access through Managed Identity or workload identity.

## API Security

- Azure Front Door WAF for edge protection.
- Azure API Management for API authentication, quotas, throttling, and versioning.
- Private ingress for internal services.

## Secrets

- Store secrets in Azure Key Vault.
- Do not store payment provider secrets in config files or prompts.

## Authorization

- Customer APIs scoped to customer identity.
- Admin APIs separated from public APIs.
- Payment and refund operations require stronger authorization and audit.

## MCP Security Note

Any MCP tool that triggers order cancellation, refund, inventory release, or deployment must require explicit approval and audit.
