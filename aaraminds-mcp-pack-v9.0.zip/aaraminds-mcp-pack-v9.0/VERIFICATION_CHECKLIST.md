# Verification Checklist — v9.0

This is the step-by-step recipe to confirm v9.0 works end-to-end in your environment. Run it once when first adopting the pack; re-run before any forked release.

The pack ships at quality 9.0+ with evidence. Verification is what makes that claim auditable: anyone can run these steps and get a deterministic pass/fail.

## Prerequisites

- Go 1.25.x or 1.26.x installed (`go version` to confirm). If your local Go is older, use the Docker recipe in Step 2.
- Python 3.8+ for the demo and validation tooling (stdlib only; no pip install).
- Docker (optional but recommended) for reproducible builds.
- Internet access for `go mod tidy` to fetch dependencies.

## Step 1 — Module initialization

```bash
cd examples/microservices-system-design-mcp-server
go mod tidy
```

**Expected:** Downloads `github.com/mark3labs/mcp-go` and transitive dependencies. No errors. `go.sum` is updated.

**If it fails:** Most likely network access to `proxy.golang.org`, or you renamed the module path. Fix the module path or restore network connectivity.

## Step 2 — Compile

```bash
go build ./...
```

**Expected:** Silent success. Every package compiles.

**Fallback for older Go:**

```bash
docker run --rm --network=host \
  -v "$(pwd):/src" -w /src \
  golang:1.26 sh -c \
  "go mod tidy && CGO_ENABLED=0 go build -o ./mcp-server ./cmd/server"
```

This produces a static binary at `./mcp-server` you can use for the demo.

## Step 3 — Run unit tests

```bash
go test ./...
```

**Expected:** All 11 service packages pass. Total runtime under 5 seconds.

```bash
go test -race -count=1 ./...
```

**Expected:** Same packages pass under the race detector. Requires cgo (use `golang:1.26` Docker image, not alpine).

## Step 4 — Static checks

```bash
go vet ./...
gofmt -l .
```

**Expected:** No output from either command.

## Step 5 — Server starts in stdio mode

```bash
go run ./cmd/server
```

**Expected:** Structured log line on stderr:

```json
{"time":"...","level":"INFO","msg":"starting MCP server","transport":"stdio"}
```

Press Ctrl+C to exit. Verifies the server binary works and stdio transport initializes.

## Step 6 — Tool catalog is complete

Start the server and send an MCP `tools/list` request. The tool catalog should return **13 tools**:

- `review_microservice_design`
- `recommend_microservice_patterns`
- `score_well_architected_readiness`
- `generate_service_boundary_canvas`
- `generate_api_contract`
- `detect_architecture_risks`
- `map_patterns_to_azure_services`
- `generate_observability_plan`
- `generate_architecture_decision_record`
- `generate_deployment_topology`
- `generate_event_contract`
- `generate_resilience_plan`
- `generate_diagram_assets`

If you have the MCP Inspector or any MCP client, point it at `./mcp-server` with stdio transport. Otherwise, the demo runner in the next step exercises a representative subset.

## Step 7 — End-to-end demo passes

```bash
# From the pack root:
cd examples/microservices-system-design-mcp-server
go build -o ./mcp-server ./cmd/server

cd ../../demo/architecture-review-demo
export MCP_SERVER_BIN=../../examples/microservices-system-design-mcp-server/mcp-server
make demo
make validate
```

**Expected:**

```
Generated outputs in out for 3 architecture(s).
Validation passed: 3 architecture(s) × 5 tool(s) all match golden fixtures.
```

This is the strongest single signal that the pack works as intended: the example server, the demo runner, the per-tool inputs, and the captured goldens are all internally consistent.

If `make validate` reports mismatches, either the server code changed (intentional → run `make refresh`) or something drifted (investigate before refreshing).

## Step 8 — Pattern-card boilerplate check

```bash
# From the pack root:
grep -r "The problem exists in a real workflow" patterns/microservices/ | wc -l
grep -r "Define the business capability and boundary" patterns/microservices/ | wc -l
```

**Expected:** Both return `0`.

This confirms the pattern cards are pattern-specific, not boilerplate. Any non-zero result means a regression to stub content.

## Step 9 — Validation evals are runnable

Open any eval file under `validation/skill-evals/mcp/` or `validation/skill-evals/microservices/`. Check:

- Front-matter is valid (skill path, exercises_section, pass_threshold).
- Prompt section is present and concise (1–3 sentences typical).
- Rubric has named criteria with checkboxes.
- Reference output is a hand-curated exemplar at the right depth.

Pick one eval; paste the prompt + linked skill file into your LLM of choice; score the response against the rubric. If ≥ the declared pass threshold, the skill is producing the guidance the eval expects.

Repeat for a sample of 5–10 evals. Track results in each eval's `last_run` / `last_result` front-matter.

## Step 10 — Governance docs reflect your team

Open `validation/governance/freshness-cadence.md`. The "Ownership slots" table has placeholder entries like `[Owner: __________]`. Fill them in with real names before adopting the pack operationally.

Open `validation/governance/release-checklist.md`. Confirm the 7 sections describe your release plumbing. Adapt as needed.

## Reporting failures

When verification fails:

1. **Note which step**.
2. **Copy the exact error output** verbatim — don't summarize.
3. **Note your environment** (`go version`, OS, Docker version).
4. **Note any local changes** that might explain it.

For changes you intend to make to the pack: run the full checklist on your fork before tagging a release.

## When this checklist passes

You have a working, verified v9.0 install. The skills are usable with your LLM; the example server is buildable and deployable; the demo proves the server's output is content-distinct across inputs; the validation pack gives you a way to track regressions.

The pack is now yours to use, adapt, and evolve. Re-run this checklist before any release of your fork.
