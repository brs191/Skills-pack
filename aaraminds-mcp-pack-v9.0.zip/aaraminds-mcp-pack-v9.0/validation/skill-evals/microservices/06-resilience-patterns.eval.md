---
skill: skills/microservices/06-resilience-patterns.md
exercises_section: Timeout, retry, circuit breaker composition
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: resilience patterns

## Prompt

A service calls a flaky third-party payment API. The team adds retries (5 attempts with exponential backoff). Production gets worse, not better. Explain what's going wrong and how to fix it.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Retry storm** — names that retries amplify load on an already-struggling downstream
- [ ] **Jitter** — points out that synchronized retries multiply the problem; jitter (randomized delay) spreads them out
- [ ] **Retry budget vs. caller's SLA** — flags that 5 attempts with exponential backoff may exceed the caller's deadline
- [ ] **Idempotency precondition** — calls out that retrying a charge requires an idempotency key; without it, retries can double-charge
- [ ] **Add circuit breaker** — proposes a breaker so persistent failure causes fail-fast instead of more retries
- [ ] **Classify errors before retrying** — retries should only fire on transient errors (5xx, timeouts), not permanent ones (400/401/403/409)

## Reference output

> Retries are amplifying the problem rather than helping. Three things are likely going wrong simultaneously:
>
> **1. Retry storm.** When the payment API gets slow, every caller's client retries 5 times. The downstream sees 5x the load at the worst possible moment. The API gets even slower; retries take longer; more requests pile up. This pattern alone can turn a transient blip into an extended incident.
>
> **2. No jitter.** If 1,000 clients all decide to back off 1s, 2s, 4s, 8s..., they retry in waves — each wave hits the downstream simultaneously. Adding random jitter (e.g., backoff ± 30%) spreads them, reducing the wave amplitude. This is non-negotiable for retries at scale.
>
> **3. Retry budget exceeds caller's SLA.** Exponential backoff for 5 attempts (1s, 2s, 4s, 8s, 16s) is a 31-second tail. If the caller's API contract is "respond in 5 seconds", the retries themselves cause timeouts upstream. The caller's caller sees failures it could have surfaced as a clean 503 thirty seconds earlier.
>
> **Fix**
>
> 1. **Cut retries.** 5 attempts is too many. 3 with jitter is usually correct for transient-fault tolerance without amplification.
> 2. **Add jitter.** `delay = base * 2^attempt * (0.7 + random()*0.6)` or use Polly / `cenkalti/backoff` with built-in jitter.
> 3. **Cap retry budget.** Total retry time should be ≤ caller's deadline minus a safety margin (e.g., if the caller's SLA is 5 s, retry budget is ≤ 4 s).
> 4. **Add a circuit breaker.** When error rate to the payment API exceeds 50% over a 30 s window, trip the breaker. Calls fail fast for 30 s before a half-open probe. This kills the retry storm during incidents; downstream gets quiet and can recover.
> 5. **Classify errors.** 4xx errors (especially 400, 401, 422) are not transient — retrying makes no sense. Only 5xx / timeout / connection-reset should trigger a retry.
> 6. **Idempotency keys on the charge.** Every retry must carry the same Idempotency-Key header. The payment API can then dedupe; a customer is charged exactly once even if our client retries. Without this, retries can double-charge.
>
> The composition matters: retries (capped + jittered) inside a circuit breaker, with idempotency keys, classified by error type, within the caller's deadline budget.

## Notes

Catches LLMs that treat retries as a magic wand without engaging with their failure modes. The retry-storm framing is in the skill explicitly.
