# Per-Skill Evals

One eval per skill file. Each eval is a small, narrowly-targeted prompt that exercises the *specific* guidance in its skill and a rubric for scoring the response.

## Why this exists

The capability-area validation prompts (under `../prompts/`) test the pack at the workflow level. Per-skill evals test the pack at the *guidance* level: if a skill file is rewritten, does it still produce the behavior it claims to produce?

This is the regression-testing layer. When you change a skill, run its eval before merging.

## Format

Every eval follows the same shape so it can be parsed mechanically or skimmed by hand. Use [template.md](template.md) as the starting point.

```markdown
---
skill: <path/to/skill.md>
exercises_section: <heading from the skill that this eval stresses>
pass_threshold: <N>/<M>
last_run: <YYYY-MM-DD or "never">
last_result: <pass | fail | "never run">
---

# Eval: <skill name>

## Prompt

<Small, targeted prompt — 1–3 sentences typical. Should not require reading
five skill files; should require reading *this* one.>

## Rubric

A response passes if it covers at least <N> of the following <M> points:

- [ ] **<label>** — <specific point the skill teaches that the response must hit>
...

## Reference output

<Short exemplar — 5–20 lines typical. Shows the shape and density a
quality response at this skill level looks like.>

## Notes (optional)

<What this eval is meant to catch.>
```

## How to use

### Manual run (one skill)

```
1. Open eval file.
2. Paste the Prompt into Claude Code (or any LLM) with the skill file attached as context.
3. Score the response against the rubric, point by point.
4. Update the front-matter: last_run = today's date, last_result = pass / fail.
5. If it failed, file an issue against the skill or the eval (whichever drifted).
```

### Batch run (all evals)

A future script could iterate every eval, call your LLM with the prompt + linked skill, parse the response for rubric points, and emit a report. The format is stable; the script is not provided in v9.0 because the right shape depends on which LLM and CI you use.

## Coverage

The pack ships 34 per-skill evals: 12 covering all microservices skills, 22 covering all uplifted MCP skills.

### Microservices skills (12 evals)

All 12 files under `skills/microservices/` have an eval:

| Skill | Eval |
|---|---|
| 01-design-router | [microservices/01-design-router.eval.md](microservices/01-design-router.eval.md) |
| 02-system-design-process | [microservices/02-system-design-process.eval.md](microservices/02-system-design-process.eval.md) |
| 03-domain-decomposition | [microservices/03-domain-decomposition.eval.md](microservices/03-domain-decomposition.eval.md) |
| 04-service-boundaries | [microservices/04-service-boundaries.eval.md](microservices/04-service-boundaries.eval.md) |
| 05-data-architecture | [microservices/05-data-architecture.eval.md](microservices/05-data-architecture.eval.md) |
| 06-resilience-patterns | [microservices/06-resilience-patterns.eval.md](microservices/06-resilience-patterns.eval.md) |
| 07-async-messaging | [microservices/07-async-messaging.eval.md](microservices/07-async-messaging.eval.md) |
| 08-api-design | [microservices/08-api-design.eval.md](microservices/08-api-design.eval.md) |
| 09-azure-mapping | [microservices/09-azure-mapping.eval.md](microservices/09-azure-mapping.eval.md) |
| 10-observability-design | [microservices/10-observability-design.eval.md](microservices/10-observability-design.eval.md) |
| 11-security-design | [microservices/11-security-design.eval.md](microservices/11-security-design.eval.md) |
| 12-cost-and-tradeoffs | [microservices/12-cost-and-tradeoffs.eval.md](microservices/12-cost-and-tradeoffs.eval.md) |

### MCP skills (22 evals)

All 22 uplifted MCP skills have evals:

| Skill | Eval |
|---|---|
| 00-ecosystem-facts | [mcp/00-ecosystem-facts.eval.md](mcp/00-ecosystem-facts.eval.md) |
| 01-mcp-go-server-basics | [mcp/01-mcp-go-server-basics.eval.md](mcp/01-mcp-go-server-basics.eval.md) |
| 02-mcp-go-tool-design | [mcp/02-mcp-go-tool-design.eval.md](mcp/02-mcp-go-tool-design.eval.md) |
| 03-mcp-go-resources | [mcp/03-mcp-go-resources.eval.md](mcp/03-mcp-go-resources.eval.md) |
| 04-mcp-go-prompts | [mcp/04-mcp-go-prompts.eval.md](mcp/04-mcp-go-prompts.eval.md) |
| 05-mcp-go-transport-selection | [mcp/05-mcp-go-transport-selection.eval.md](mcp/05-mcp-go-transport-selection.eval.md) |
| 06-mcp-go-project-structure | [mcp/06-mcp-go-project-structure.eval.md](mcp/06-mcp-go-project-structure.eval.md) |
| 07-mcp-go-enterprise-security | [mcp/07-mcp-go-enterprise-security.eval.md](mcp/07-mcp-go-enterprise-security.eval.md) |
| 08-mcp-go-observability | [mcp/08-mcp-go-observability.eval.md](mcp/08-mcp-go-observability.eval.md) |
| 09-mcp-go-testing | [mcp/09-mcp-go-testing.eval.md](mcp/09-mcp-go-testing.eval.md) |
| 10-mcp-go-deployment | [mcp/10-mcp-go-deployment.eval.md](mcp/10-mcp-go-deployment.eval.md) |
| 11-mcp-go-agent-integration | [mcp/11-mcp-go-agent-integration.eval.md](mcp/11-mcp-go-agent-integration.eval.md) |
| 16-mcp-go-production-review | [mcp/16-mcp-go-production-review.eval.md](mcp/16-mcp-go-production-review.eval.md) |
| 17-mcp-go-code-generation | [mcp/17-mcp-go-code-generation.eval.md](mcp/17-mcp-go-code-generation.eval.md) |
| 18-mcp-go-anti-patterns | [mcp/18-mcp-go-anti-patterns.eval.md](mcp/18-mcp-go-anti-patterns.eval.md) |
| 19-mcp-go-reference-implementation | [mcp/19-mcp-go-reference-implementation.eval.md](mcp/19-mcp-go-reference-implementation.eval.md) |
| 20-mcp-go-threat-modeling | [mcp/20-mcp-go-threat-modeling.eval.md](mcp/20-mcp-go-threat-modeling.eval.md) |
| 21-mcp-go-client-integration | [mcp/21-mcp-go-client-integration.eval.md](mcp/21-mcp-go-client-integration.eval.md) |
| 22-mcp-go-cicd-quality-gates | [mcp/22-mcp-go-cicd-quality-gates.eval.md](mcp/22-mcp-go-cicd-quality-gates.eval.md) |
| 24-mcp-go-e2e-agent-demo | [mcp/24-mcp-go-e2e-agent-demo.eval.md](mcp/24-mcp-go-e2e-agent-demo.eval.md) |
| 25-mcp-go-security-test-generation | [mcp/25-mcp-go-security-test-generation.eval.md](mcp/25-mcp-go-security-test-generation.eval.md) |
| 26-mcp-go-runnable-domain-repos | [mcp/26-mcp-go-runnable-domain-repos.eval.md](mcp/26-mcp-go-runnable-domain-repos.eval.md) |

### Not covered at v9.0

- The 21 microservices pattern cards. They follow a uniform structure validated by the Phase B boilerplate-grep tests, and the cross-cutting validation prompt (`prompts/cross-cutting/02-pattern-card-cross-reference.md`) exercises the cluster as a whole. Add per-card evals only if cards begin to drift.
