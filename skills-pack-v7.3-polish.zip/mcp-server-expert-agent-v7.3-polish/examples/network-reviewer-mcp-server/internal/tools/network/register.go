package network

import (
	"github.com/example/network-reviewer-mcp-server/internal/audit"
	"github.com/example/network-reviewer-mcp-server/internal/policy"
	networksvc "github.com/example/network-reviewer-mcp-server/internal/services/network"
	"github.com/mark3labs/mcp-go/server"
)

func Register(s *server.MCPServer, svc *networksvc.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	registerGetNetworkTopology(s, svc, policyEngine, auditor)
	registerDetectNsgRisks(s, svc, policyEngine, auditor)
	registerAnalyzeRouteTables(s, svc, policyEngine, auditor)
	registerEstimateNetworkCostImpact(s, svc, policyEngine, auditor)
}
