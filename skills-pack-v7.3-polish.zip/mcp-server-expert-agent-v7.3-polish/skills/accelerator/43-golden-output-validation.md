# Skill — Golden Output Validation

## Purpose

Use golden outputs to keep architecture-review behavior consistent, reviewable, and testable.

## Use When

The user asks to validate the pack, compare generated outputs, create acceptance tests, or improve reliability of architecture recommendations.

## Golden Output Types

```text
testdata/golden/ecommerce-review-output.json
testdata/golden/ecommerce-pattern-map.json
testdata/golden/ecommerce-scorecard.json
testdata/golden/ecommerce-adr-output.md
testdata/golden/ecommerce-diagram-output.mmd
```

## Validation Rules

Generated outputs should be checked for:

- required sections present
- score fields present
- no empty critical recommendation fields
- no destructive action without approval
- Azure mappings are explicit
- service boundaries are business-capability aligned
- ADR contains context, decision, alternatives, and consequences
- diagrams contain main services and integration paths

## Agent Behavior

When reviewing architecture output quality, compare against the golden structure rather than relying on subjective judgment.
