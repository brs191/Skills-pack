---
skill: skills/mcp/02-mcp-go-tool-design.md
exercises_section: Intent-based design and risk tiers
pass_threshold: 4/6
last_run: never
last_result: never run
---

# Eval: MCP Go tool design

## Prompt

Someone proposes a tool: `manage_orders` that, depending on its `action` argument, can create orders, read orders, cancel orders, or run a report. Critique this and propose a redesign.

## Rubric

A response passes if it covers at least 4 of the following 6 points:

- [ ] **Kitchen-sink anti-pattern** — explicitly names that one tool doing multiple unrelated operations is the wrong shape
- [ ] **Split by intent** — proposes one tool per intent: `create_order`, `get_order`, `cancel_order`, `generate_order_report`
- [ ] **Risk tier per tool** — creation and cancellation are state-changing (high tier); read and report are informational (low tier); different audit, dry-run, logging needs
- [ ] **Action-verb names** — tool names are imperative verbs, not nouns ("manage_orders" is wrong; "create_order" is right)
- [ ] **Typed input per tool** — each tool has its own typed input struct, not a polymorphic `manage_orders(action, params)`
- [ ] **Discoverability** — split tools give the LLM client a clear catalog of capabilities; one mega-tool hides what's available

## Reference output

> `manage_orders` is the kitchen-sink anti-pattern. The skill names this specifically: a tool that does multiple unrelated operations based on a string argument is harder to use, harder to audit, harder to test, and impossible to apply risk-tier policy to.
>
> **What's wrong**
>
> - **Polymorphic input** — the input schema has to be a union of every action's input. `action="create"` needs different fields than `action="report"`. JSON schema becomes vague (most fields optional) and validation gets pushed into the handler.
> - **Polymorphic output** — same problem on the way out. The result of `create` is an order ID; the result of `report` is a summary. A consumer has to inspect the action to know what shape the output is.
> - **One risk tier for all** — `cancel` is state-changing and high-risk; `report` is read-only and low-risk. With one tool, you have one policy, which means everything ends up at the highest risk tier or the lowest. Both are wrong.
> - **No discoverability** — the LLM client sees one tool. It doesn't know that you can run a report. It guesses based on the description; guesses go wrong.
>
> **Redesign**
>
> Split into one tool per intent, named with an imperative verb:
>
> | Tool | Risk tier | Input | Output |
> |---|---|---|---|
> | `create_order` | High (mutates state, has side effects) | typed `CreateOrderInput` (customer, items, shipping) | `OrderCreated` (id, status) |
> | `get_order` | Low (read-only) | typed `GetOrderInput` (order_id) | `Order` (full record) |
> | `cancel_order` | High (mutates state, can affect revenue) | typed `CancelOrderInput` (order_id, reason) | `OrderCancelled` (id, refund_status) |
> | `generate_order_report` | Low (read-only, may be expensive) | typed `ReportInput` (date_range, dimensions) | `Report` (rows, metadata) |
>
> Each tool has:
> - **Typed input struct** — `json.Unmarshal` validates the schema; missing fields surface at the boundary, not deep in business logic.
> - **Risk tier** — `create_order` and `cancel_order` log every call to audit, may support `dry_run`, require stronger callee auth checks; `get_order` and `generate_order_report` log normally and don't need dry-run.
> - **Action-verb name** — the name *is* the intent; the LLM client can read the catalog and know what's possible.
> - **Single output shape** — the result schema is one thing, not a union.
>
> Splitting also makes testing trivial: each service has its own `service_test.go` exercising one shape, not a polymorphic-action matrix.
>
> **Trade-off**
> You end up with N tools instead of 1. That's fine. The MCP server is meant to expose capabilities; the cost of a tool is registration boilerplate (small) and a contract file (which you should be writing anyway). The cost of *not* splitting is everything above.

## Notes

The kitchen-sink anti-pattern is named explicitly in the skill. Catches LLMs that accept polymorphic tool designs as "flexible."
