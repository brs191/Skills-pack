# Demo Flow — Azure Cost Spike Investigation

## User request

"Why did Azure cost increase this week, and what should we do next?"

## Agent flow

```text
1. Classify intent: FinOps investigation.
2. Call MCP tool: get_cost_summary.
3. Call MCP tool: detect_cost_anomalies.
4. Call MCP tool: find_idle_resources.
5. Generate recommendation summary.
6. Ask for human approval before any cost-impacting action.
```

## MCP tools used

- `get_cost_summary`
- `detect_cost_anomalies`
- `find_idle_resources`
- `generate_finops_report`

## Approval boundary

Allowed without approval:
- read cost data
- summarize anomalies
- identify idle candidates
- recommend next steps

Requires approval:
- delete resource
- resize VM
- change SKU
- change reservation commitment
- modify budget alerts

## Example final answer shape

```text
Cost increased mainly in Azure SQL and Virtual Machines.
The highest-confidence anomaly is Azure SQL in rg-prod-data.
Two idle resources are candidates for cleanup after owner validation.
No action has been taken. Recommended next step: validate owners and create a FinOps review ticket.
```
