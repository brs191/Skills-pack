# Skill — MCP-Go Client Integration

## Purpose

Help integrate MCP servers with local MCP clients, VS Code style agents, Claude Desktop style clients, LangGraph, LangChain, and remote HTTP clients.

## Use When

The user asks:

- How do I connect the MCP server to an agent?
- How do I configure a local MCP server?
- How do I call the HTTP transport?
- How do I test MCP client/server integration?

## Local stdio pattern

Use stdio for local IDE/desktop agents.

```json
{
  "mcpServers": {
    "azure-finops": {
      "command": "go",
      "args": ["run", "./cmd/server"],
      "env": {
        "MCP_TRANSPORT": "stdio"
      }
    }
  }
}
```

## Remote HTTP pattern

Use Streamable HTTP behind an API gateway for enterprise agent platforms.

```text
Agent Runtime
  ↓
MCP HTTP Client
  ↓
Azure API Management / Gateway
  ↓
MCP Streamable HTTP Server
  ↓
Policy + Audit + Tool Execution
```

## Integration rules

- Keep local development on stdio.
- Use Streamable HTTP for shared environments.
- Require authentication for remote access.
- Keep destructive tools disabled by default.
- Use mock connectors for local tests.
- Use environment profiles for local/dev/stage/prod.
