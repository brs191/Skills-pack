# Service Boundary Canvas

## Service Name

## Business Capability

## Owner Team

## Responsibilities

## What This Service Owns
- Data:
- APIs:
- Events:
- Workflows:

## What This Service Does Not Own

## Upstream Dependencies

## Downstream Dependencies

## Database Ownership

## API Contracts

## Events Published

## Events Consumed

## Scaling Characteristics

## Security Boundary

## Failure Impact

## Observability Requirements

## Deployment Unit

## Azure Service Mapping
