# Demo Flow — DevOps Failed Pipeline Investigation

## User request

"Why did the production deployment pipeline fail?"

## Agent flow

```text
1. Classify intent: DevOps failure analysis.
2. Call MCP tool: get_pipeline_status.
3. Call MCP tool: summarize_failed_build.
4. Call MCP tool: get_recent_deployments.
5. Produce root-cause hypothesis and next checks.
```

## Approval boundary

Read-only analysis does not require approval.
Retrying a pipeline or deploying to production requires explicit human approval.
