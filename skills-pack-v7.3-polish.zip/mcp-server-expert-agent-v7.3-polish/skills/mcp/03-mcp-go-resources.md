# Skill — MCP-Go Resources

## Purpose

Design MCP resources for exposing read-only context to agents.

## Principle

Use resources for context. Use tools for actions. Resources should normally be read-only.

## Examples

```text
docs://architecture/platform-overview
catalog://services/payment-api
cost://reports/monthly-summary
network://topology/subscription/{subscription_id}
runbook://incident/high-cpu
k8s://cluster/{cluster_name}/namespaces
```

## Resource Template

```markdown
## Resource URI
`resource://path`

## Purpose
What context this resource exposes.

## Data Source
Where the data comes from.

## MIME Type
application/json, text/markdown, text/plain, etc.

## Access Control
Who can read this resource.

## Refresh Strategy
Static / cached / live / scheduled.

## Security Notes
Sensitive fields to redact.
```

## Safety Rules

- Do not expose secrets, raw tokens, or unrestricted logs.
- Redact PII where required.
- Prefer summarized data for large datasets.
- Use resource URIs that represent business context.
