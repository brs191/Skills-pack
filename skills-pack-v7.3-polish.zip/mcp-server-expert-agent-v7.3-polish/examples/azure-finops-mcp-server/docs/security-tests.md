# Security Test Coverage

The Azure FinOps starter includes policy and redaction tests.

Recommended test cases:

- wrong tenant denied
- high-risk action without approval denied
- approved high-risk action allowed
- secret-like strings redacted
- invalid date range rejected at tool boundary
- read-only MVP has no mutation tools

Run:

```bash
go test ./...
```
