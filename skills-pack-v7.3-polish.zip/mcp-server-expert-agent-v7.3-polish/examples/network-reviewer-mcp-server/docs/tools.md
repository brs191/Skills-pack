# MCP Tools

## `get_network_topology`

Read-only domain tool. Risk: Low. Approval: No.

## `detect_nsg_risks`

Read-only domain tool. Risk: Low. Approval: No.

## `analyze_route_tables`

Read-only domain tool. Risk: Low. Approval: No.

## `estimate_network_cost_impact`

Read-only domain tool. Risk: Low. Approval: No.


## Mutation controls

Updating NSG, firewall, route table, or peering requires mandatory approval and a change record.
