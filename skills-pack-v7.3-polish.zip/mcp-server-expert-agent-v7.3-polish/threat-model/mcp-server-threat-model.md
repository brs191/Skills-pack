# MCP Server Threat Model

## Assets
- User identity
- Tenant data
- Tool permissions
- Backend credentials
- Business systems
- Audit records
- Prompt and resource content

## Trust Boundaries

```text
LLM/Agent
  | untrusted reasoning boundary
MCP Client
  | protocol boundary
MCP Server
  | policy + execution boundary
Backend Connectors
  | enterprise system boundary
Azure/GitHub/Grafana/etc.
```

## Primary Risks

1. Prompt injection from resource/tool output
2. Tool misuse by agent
3. Cross-tenant data exposure
4. Over-privileged connectors
5. Unbounded API cost
6. Lack of auditability
7. Destructive production changes
8. Secret leakage

## Required Controls

- Per-tool authorization
- Tenant context checks
- Output redaction
- High-risk approval workflow
- Dry-run for mutating actions
- Structured audit events
- Rate limits
- Result size limits
- Dependency timeouts
