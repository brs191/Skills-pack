# MCP Server Expert Skills Pack — v7.3 Polish Release

This pack is a reusable agent workspace for designing, implementing, reviewing, and communicating enterprise MCP servers and Azure-hosted microservices architectures.

v7.3 is a polish release. It does not add new capability areas. It reduces adoption friction by improving navigation, status clarity, root quality commands, contract indexes, loading guidance, and demo truthfulness.

## Capability areas

1. **MCP Server Expert** — Go-first MCP server design using `mark3labs/mcp-go`.
2. **Domain MCP Starters** — Azure FinOps, DevOps, Observability, and Network Reviewer starter repos.
3. **Microservices System Design** — pattern cards, Azure implementation maps, playbooks, rubrics, and architecture templates.
4. **Architecture Intelligence MCP Server** — starter server for reviewing microservices designs and scoring readiness.
5. **Architecture Accelerator** — offline demo workflow, golden outputs, diagrams, ADRs, scorecards, and architecture-board presentation assets.

## Quick start

### Use as an agent knowledge pack

Load these files first:

```text
instructions.md
context.md
memory.md
skills/00-skill-router.md
skills/README.md
MANIFEST.md
```

Then load supporting files only when needed from:

```text
skills/mcp/
skills/domain/
skills/microservices/
skills/accelerator/
patterns/
azure-implementation-maps/
playbooks/
templates/
contracts/
rubrics/
examples/
```

See:

```text
docs/status/agent-loading-guide.md
```

### Run the offline architecture review demo

From the root:

```bash
make demo
```

Or directly:

```bash
cd demo/architecture-review-demo
make clean
make demo
make validate
```

The demo generates outputs into:

```text
demo/architecture-review-demo/out/
```

The validation compares generated outputs against:

```text
testdata/golden/
```

## Demo vs MCP execution

The architecture-review demo is an **offline deterministic demo**. It validates the architecture review package, output shape, and golden-output discipline.

It does **not** start a live MCP server or perform live MCP client-to-server tool calls.

The MCP server example is here:

```text
examples/microservices-system-design-mcp-server/
```

It contains MCP server wiring and service-layer logic for architecture review and scoring. Treat it as a starter implementation, not a finished product.

## Root commands

```bash
make demo                # run offline architecture-review demo and validation
make validate            # validate generated demo outputs against golden outputs
make test-system-design  # run local service-layer tests for the architecture MCP example
make tidy-examples       # run go mod tidy in all Go example repos; requires internet access
make clean-demo          # remove generated demo outputs
make status              # print pack status
```

## Folder guide

| Folder | Purpose |
|---|---|
| `skills/` | Agent skills grouped into MCP, domain, microservices, and accelerator modes |
| `patterns/microservices/` | Pattern cards with when-to-use, when-not-to-use, Azure mapping, risks, and implementation guidance |
| `azure-implementation-maps/` | Azure service mappings for microservices concerns |
| `playbooks/` | Step-by-step implementation guides |
| `reference-architectures/` | Reusable cloud-native architecture combinations |
| `templates/` | ADRs, service boundary canvas, scorecards, review outputs, and implementation backlog templates |
| `templates/go/` | Shared Go utility templates for audit, policy, redaction, CI, Docker, and MCP layout |
| `contracts/` | MCP tool, resource, prompt, and architecture tool contracts |
| `examples/` | Standalone Go/mcp-go starter repos |
| `case-studies/` | Applied architecture examples |
| `diagram-prompts/` | Mermaid, PlantUML, and draw.io-ready diagram assets |
| `presentation/` | Executive, architecture-board, and engineering review templates |
| `testdata/golden/` | Golden outputs used by validation scripts |
| `demo/` | Offline demo workflow |
| `docs/status/` | Status indexes and adoption guidance |

For a full file map, see:

```text
MANIFEST.md
```

## What is implemented vs planned

Architecture tool contracts are separated by status:

```text
contracts/architecture-tools/implemented/
contracts/architecture-tools/planned/
```

Implemented means the starter `examples/microservices-system-design-mcp-server/` has a corresponding service path or tool handler. Planned means the contract is retained as a deliberate expansion backlog.

See:

```text
contracts/architecture-tools/README.md
docs/status/architecture-tool-contract-status.md
docs/status/dependency-readiness.md
```

## Example repo status

| Example repo | Status | Notes |
|---|---|---|
| `examples/azure-finops-mcp-server/` | Starter repo | Service layers and tests included. Full MCP build requires dependency download. |
| `examples/devops-mcp-server/` | Starter repo | Standalone skeleton with policy, audit, security, tools, CI, Docker, and Kubernetes samples. |
| `examples/observability-mcp-server/` | Starter repo | Observability-focused MCP tool structure with security and redaction examples. |
| `examples/network-reviewer-mcp-server/` | Starter repo | Network review tool structure with risk/approval examples. |
| `examples/microservices-system-design-mcp-server/` | Architecture intelligence starter | Includes design review and scoring service-layer tests. |

Before building a full Go example repo:

```bash
go mod tidy
go test ./...
```

This ZIP does not include `go.sum` files because dependency resolution requires network access. The service-layer tests are designed to remain locally testable where external dependencies are not required.

## Standalone example policy

The example repos intentionally duplicate small utility patterns such as policy, audit, redaction, Dockerfile, and CI workflow so each repo can be copied independently.

Shared reusable templates are also available under:

```text
templates/go/
```

## Recommended usage modes

### MCP implementation mode

Use when creating or reviewing Go-based MCP servers, tools, resources, prompts, transports, CI, Docker, Kubernetes, and security controls.

### Microservices architecture mode

Use when reviewing service boundaries, data ownership, communication patterns, Azure service mappings, resilience, security, observability, and deployment topology.

### Architecture-board mode

Use when producing executive summaries, ADRs, diagrams, scorecards, decision records, and board-ready review packs.

## Quality rules

The agent using this pack should always:

- identify business capabilities before proposing services;
- avoid microservices when a modular monolith is more practical;
- define service boundaries, data ownership, APIs, events, failure modes, and operational ownership;
- map architecture patterns to Azure services with trade-offs;
- require ADRs for major architecture decisions;
- require approval gates for high-risk MCP tools;
- distinguish implemented tool contracts from planned contracts;
- generate outputs that can be reviewed by both engineering and leadership stakeholders;
- avoid claiming full production readiness for starter repos.
