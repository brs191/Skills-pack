package cost

import (
	"github.com/example/azure-finops-mcp-server/internal/audit"
	"github.com/example/azure-finops-mcp-server/internal/policy"
	costservice "github.com/example/azure-finops-mcp-server/internal/services/cost"
	"github.com/mark3labs/mcp-go/server"
)

func Register(s *server.MCPServer, svc *costservice.Service, policyEngine *policy.Engine, auditor audit.Auditor) {
	registerGetCostSummary(s, svc, policyEngine, auditor)
	registerFindIdleResources(s, svc, policyEngine, auditor)
	registerDetectCostAnomalies(s, svc, policyEngine, auditor)
	registerGenerateFinOpsReport(s, svc, policyEngine, auditor)
}
