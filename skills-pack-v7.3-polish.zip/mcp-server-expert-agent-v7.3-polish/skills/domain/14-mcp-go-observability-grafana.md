# Skill — Observability and Grafana MCP Server Using mcp-go

## Purpose

Design MCP tools for Grafana, metrics, logs, traces, and incident analysis.

## MCP Tools

```text
query_logs
query_metrics
detect_error_spike
correlate_logs_metrics
summarize_incident
generate_runbook_recommendation
get_dashboard_snapshot
find_slo_breach
```

## MCP Resources

```text
grafana://dashboards/{dashboard_id}
logs://applications/{app_name}/recent-errors
metrics://services/{service_name}/slo
runbook://incident/{incident_type}
```

## Safety Rules

Redact tokens, headers, customer identifiers, and PII. Limit log query time range and result size. Prevent arbitrary unbounded queries. Return summaries for large data.
