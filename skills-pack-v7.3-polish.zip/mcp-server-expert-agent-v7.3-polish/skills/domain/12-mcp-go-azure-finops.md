# Skill — Azure FinOps MCP Server Using mcp-go

## Purpose

Design and implement an Azure FinOps MCP server using mark3labs/mcp-go.

## MCP Tools

```text
get_cost_summary
detect_cost_anomalies
find_idle_resources
recommend_reserved_instances
forecast_monthly_spend
analyze_resource_group_spend
get_budget_status
generate_finops_report
```

## MCP Resources

```text
cost://subscriptions/{subscription_id}/monthly-summary
cost://budgets/{subscription_id}
cost://recommendations/{subscription_id}
finops://policy/savings-rules
```

## Architecture

```text
FinOps Agent
  ↓
MCP Server using mcp-go
  ↓
Policy + Tenant Context
  ↓
Azure Cost Management Connector
  ↓
Azure Resource Graph Connector
  ↓
Budget / Pricing / Recommendation APIs
  ↓
Cost Summary + Optimization Recommendations
```

## MVP Scope

Start with `get_cost_summary`, `find_idle_resources`, `detect_cost_anomalies`, and `generate_finops_report`. Avoid automatic cost-changing actions in MVP.
