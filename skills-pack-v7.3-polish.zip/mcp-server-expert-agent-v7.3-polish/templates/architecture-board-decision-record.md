# Architecture Board Decision Record

## Decision ID

## System / Platform

## Decision Requested

## Architecture Summary

## Options Considered

| Option | Pros | Cons | Recommendation |
|---|---|---|---|

## Key Risks

## Required Controls

## Approval Conditions

## Decision
Approved / Approved with Conditions / Rejected / Deferred

## Follow-up Date
