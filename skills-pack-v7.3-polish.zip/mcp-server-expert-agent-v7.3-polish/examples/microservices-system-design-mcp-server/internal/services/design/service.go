package design

import "strings"

type ReviewInput struct {
	SystemName         string
	BusinessCapability string
	DeploymentTarget   string
	Services           []string
	Constraints        []string
}

type ReviewResult struct {
	Summary             string   `json:"summary"`
	RecommendedPatterns []string `json:"recommended_patterns"`
	AzureMapping        []string `json:"azure_mapping"`
	Risks               []string `json:"risks"`
	Score               int      `json:"score"`
	NextSteps           []string `json:"next_steps"`
}

type PillarScore struct {
	Score    int      `json:"score"`
	Evidence []string `json:"evidence"`
	Risks    []string `json:"risks"`
}

type Scorecard struct {
	Reliability           PillarScore `json:"reliability"`
	Security              PillarScore `json:"security"`
	OperationalExcellence PillarScore `json:"operational_excellence"`
	PerformanceEfficiency PillarScore `json:"performance_efficiency"`
	CostOptimization      PillarScore `json:"cost_optimization"`
	OverallScore          int         `json:"overall_score"`
	Rating                string      `json:"rating"`
}

type Service struct{}

func NewService() *Service { return &Service{} }

func (s *Service) Review(in ReviewInput) ReviewResult {
	patterns := []string{"API Gateway", "Database per Service", "Distributed Tracing"}
	mapping := []string{"Azure API Management", "AKS or Azure Container Apps", "Azure Monitor + OpenTelemetry", "Key Vault + Managed Identity"}
	risks := []string{}
	if len(in.Services) == 0 {
		risks = append(risks, "Service boundaries are not defined")
	}
	if strings.EqualFold(in.DeploymentTarget, "") {
		risks = append(risks, "Deployment target is not selected")
	}
	score := 82
	if len(risks) > 0 {
		score = 68
	}
	return ReviewResult{
		Summary:             "Architecture review generated for " + in.SystemName,
		RecommendedPatterns: patterns,
		AzureMapping:        mapping,
		Risks:               risks,
		Score:               score,
		NextSteps:           []string{"Create service boundary canvas", "Generate ADRs", "Define API and event contracts", "Add resilience and observability plan"},
	}
}

func (s *Service) RecommendPatterns(problem string) []string {
	p := strings.ToLower(problem)
	out := []string{"API Gateway", "Distributed Tracing"}
	if strings.Contains(p, "transaction") || strings.Contains(p, "workflow") {
		out = append(out, "Saga", "Transactional Outbox", "Idempotent Consumer")
	}
	if strings.Contains(p, "read") || strings.Contains(p, "scale") {
		out = append(out, "CQRS", "Cache Aside")
	}
	if strings.Contains(p, "monolith") {
		out = append(out, "Strangler Fig")
	}
	return out
}

func (s *Service) ScoreWellArchitected() Scorecard {
	return Scorecard{
		Reliability:           PillarScore{Score: 86, Evidence: []string{"Saga", "Outbox", "DLQ"}, Risks: []string{"Multi-region strategy missing"}},
		Security:              PillarScore{Score: 88, Evidence: []string{"APIM", "Managed Identity", "Key Vault"}, Risks: []string{"Admin API model needs detail"}},
		OperationalExcellence: PillarScore{Score: 84, Evidence: []string{"OpenTelemetry", "CI/CD", "ADRs"}, Risks: []string{"Runbook ownership missing"}},
		PerformanceEfficiency: PillarScore{Score: 82, Evidence: []string{"Autoscaling", "Redis", "Async messaging"}, Risks: []string{"Load targets incomplete"}},
		CostOptimization:      PillarScore{Score: 78, Evidence: []string{"Container Apps option", "autoscaling"}, Risks: []string{"Cost guardrails need automation"}},
		OverallScore:          84,
		Rating:                "Strong design, targeted hardening required",
	}
}
