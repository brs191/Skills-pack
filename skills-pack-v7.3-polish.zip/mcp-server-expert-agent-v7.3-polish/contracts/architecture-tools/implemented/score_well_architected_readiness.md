## Status

implemented

# Tool Contract: score_well_architected_readiness

## Purpose

Score a microservices design against reliability, security, operational excellence, performance efficiency, and cost optimization.

## Inputs

| Field | Type | Required | Description |
|---|---|---:|---|
| system_name | string | yes | Name of the system |
| evidence | object | no | Architecture evidence including service boundaries, security, resilience, observability, deployment |

## Output

```json
{
  "overall_score": 84,
  "rating": "Strong design, targeted hardening required",
  "pillars": {
    "reliability": {"score": 86, "risks": [], "remediations": []},
    "security": {"score": 88, "risks": [], "remediations": []}
  },
  "top_risks": [],
  "priority_actions": []
}
```

## Risk Level

Low

## Approval Required

No
