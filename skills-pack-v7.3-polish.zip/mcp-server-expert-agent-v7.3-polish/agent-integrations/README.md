# Agent Integrations

This folder contains lightweight integration examples that show how an agent can consume the outputs produced by the MCP Server Expert pack.

## What this folder is

- Demo guidance for agent-driven workflows.
- Flow examples for FinOps, DevOps, Observability, and Network Review scenarios.
- A LangGraph-style example that demonstrates orchestration thinking.

## What this folder is not

- It is not a full production LangGraph application.
- It is not a live MCP client integration.
- It does not replace the Go MCP server examples under `examples/`.

## Recommended usage

Use these examples when you want to explain how an AI agent would sequence MCP tool calls and convert technical findings into recommendations.

For production implementation, add:

- real MCP client calls;
- identity and tenant context propagation;
- retries and tool-call failure handling;
- audit logging for agent decisions;
- human approval before high-risk actions.
