# Skill — Diagram-Ready Architecture Output

## Purpose

Produce architecture outputs that can be directly converted into Mermaid, PlantUML, draw.io, or presentation diagrams.

## Use When

The user asks for architecture diagrams, flow diagrams, technical views, leadership views, or visual assets.

## Output Modes

- C4 context view
- Container view
- Azure deployment topology
- Event flow diagram
- Sequence diagram
- Service boundary map
- MCP tool execution flow

## Diagram Rules

- Keep business and technical diagrams separate when the audience differs.
- Do not overload diagrams with every minor component.
- Show identity, security, observability, and messaging explicitly.
- Use Azure service names when the implementation target is Azure.
